# T4 — Alignement de la documentation sur le code (20/09/2026)

Objet : les 7 contradictions relevées au §7 de `RAPPORT_ETAPE0.md`. Chaque point
est traité ci-dessous avec **ce qui a été corrigé**, **où**, et **la preuve**
(observation en jeu ou contenu de fichier).

Règle appliquée : la documentation ne doit décrire que ce que le code fait
réellement. Quand c'est le code qui était en faute, c'est le code qui a été
corrigé (et c'est signalé comme tel).

---

## 1. « Les mixins ont été abandonnés » → FAUX (doc corrigée)

**État réel** : les mixins sont actifs et déclarés.
`src/main/resources/META-INF/neoforge.mods.toml` :

```toml
[[mixins]]
config = "deep_lucky_block.mixins.json"
```

**Preuve en jeu** (log du 20/09, run de validation T6/T9) :

```
[main/DEBUG] [mixin/]: Compatibility level JAVA_21 specified by deep_lucky_block.mixins.json
[main/INFO]  [mixin/]: Compatibility level set to JAVA_21
[main/INFO]  [mixin/]: Prepared 2 mixins in 0.407 sec
```

**Correction** : la valeur de vérification « Prepared 7 mixins » de
`LIRE-MOI-IMPORTANT.md` (2 endroits) est remplacée par les valeurs réelles
(2 en serveur dédié, 5 en client), et la phrase « le rendu custom n'utilise plus
de mixin » — qui laissait croire à un abandon — est supprimée.

## 2. `deepluckyblock.mixins.json` en JAVA_17 vs README qui annonce JAVA_21

**État réel** : il existe **deux** fichiers, et un seul est déclaré.

| Fichier | Déclaré ? | Compatibility | Contenu |
|---|---|---|---|
| `deep_lucky_block.mixins.json` | **OUI** (neoforge.mods.toml) | JAVA_21 | 0 commun + 5 client |
| `deepluckyblock.mixins.json` | **NON** | JAVA_17 | 1 commun + 5 client |

**Correction** : `README-INSTALL.txt` (ligne « deep_lucky_block.mixins.json en
JAVA_21 ») précise désormais que c'est **la config déclarée** (donc celle qui
compte), que le second fichier est un vestige non déclaré (donc inerte) et qu'il
ne faut pas s'en servir comme référence.

## 3. « Prepared 7 mixins » attendu par LIRE-MOI alors que la config en déclare 6

**État réel** : la config déclarée liste 5 mixins client (0 commun) ; 6 classes
mixin présentes dans `deepluckyblock/mixin/` ne sont déclarées dans **aucune**
config (`LuckyStatsSyncMixin`, `LuckyTweaksDimensionPoolMixin`,
`LuckyXpEventRollsMixin`, `LuckyXpRouletteOverlayMixin`, `LuckyXpShowerMixin`,
`ItemChestTagTransferMixin`). Elles sont **inertes** : ce n'est pas un problème
de copie de fichiers lors de l'installation, contrairement à ce que laissait
entendre la doc.

**Correction** : `LIRE-MOI-IMPORTANT.md` liste ces classes et précise qu'elles
sont inactives (aucun fichier à recopier en plus).

## 4. `[SLB-V8]` : la doc demande de le chercher dans le log, il n'y était pas (code corrigé)

**État réel** : la bannière et les traces de diagnostic
(`SlbDiagnostics.java`) passaient par `System.out.println`. Le fichier
`logs/latest.log` ne contient que les loggers : la consigne était donc
**impossible à satisfaire**, et elle faisait conclure à tort à une mauvaise
installation.

**Correction (code)** : les 10 `System.out.println` de `SlbDiagnostics` passent
par `LOGGER.info` (logger du mod). La bannière apparaît maintenant dans
`logs/latest.log` en plus de la console.
**Correction (doc)** : les deux passages de `LIRE-MOI-IMPORTANT.md` expliquent
ce changement. Le contrôle est maintenant réellement possible.

## 5. `SMOOTH_PASSES = 3` alors que le pipeline en fait 50 puis 12

**État réel** : la constante `SMOOTH_PASSES = 3` n'est **plus lue nulle part**
(`grep -rn SMOOTH_PASSES src/main/java` → une seule occurrence : sa définition).
Les smooths réels sont dans `decorate()` :
`smoothPass(level, min, max, 7, 50)` puis `smoothPass(level, min, max, 15, 12)`,
et cette paire est jouée **deux fois** (avant et après l'étanchéité de l'eau).

**Correction** : la constante est annotée `@Deprecated` avec un commentaire qui
dit explicitement que la valeur est obsolète et renvoie à `decorate()`.

## 6. Deux kits de patch identiques (`FIXES_MCREATOR/` ×2)

**État réel** : `mod_project/src/main/resources/deepluckyblock_patch/FIXES_MCREATOR/`
et une copie existent aussi à la racine du dépôt. Aucun script de build ni code
Java ne les consomme (`grep` sur `deepluckyblock_patch` : seuls `CHANGELOG.md` et
`RAPPORT_ETAPE0.md` les mentionnent) : ce sont des dépôts de fichiers, pas une
entrée de build.

**Correction** : règle conservée et écrite noir sur blanc — **l'exemplaire situé
dans `mod_project/` fait foi** ; la copie racine peut être supprimée sans effet
sur le build (elle est laissée en place : consigne de ne rien supprimer sans
accord).

## 7. Version du mod écrite à deux endroits

**État réel** : `build.gradle` ligne 12 (`version = '1.0'`) **et**
`src/main/resources/META-INF/neoforge.mods.toml` ligne 12 (`version = "1.0"`),
plus `gradle.properties` qui ne porte **ni** `modId` **ni** `version`.

**Correction** : **rien n'a été modifié**, volontairement : la consigne de
session interdit de toucher `gradle.properties` / `settings.gradle` sans accord
explicite. Les deux valeurs sont cohérentes aujourd'hui (`1.0`), donc sans effet
visible — mais une prochaine montée de version devra être faite **aux deux
endroits**. Décision à prendre par l'utilisateur :
soit `gradle.properties` reçoit `mod_version` et les deux fichiers le lisent,
soit on assume la double saisie. Dis-le et je l'applique.

---

## Bonus T4 (vérification d'API qui a rapporté gros)

`FAST_FLAG` valait `2 | 16 | 64` dans trois fichiers. Vérification faite dans
l'API 1.21.1 (`javap` sur `net/minecraft/world/level/block/Block.class`) :

```
UPDATE_NEIGHBORS = 1   UPDATE_CLIENTS = 2      UPDATE_INVISIBLE = 4
UPDATE_IMMEDIATE = 8   UPDATE_KNOWN_SHAPE = 16 UPDATE_SUPPRESS_DROPS = 32
UPDATE_MOVE_BY_PISTON = 64
```

Le `64` n'était donc pas « supprime les drops » mais **`MOVE_BY_PISTON`** : il
devient le paramètre `isMoving` de `LevelChunk#setBlockState`, et le chunk
traite alors l'écriture comme un **déplacement de bloc par piston**, cas dans
lequel le nettoyage des block entities n'est pas fait par le chemin normal.
Symptôme mesuré dans les logs : `Tried to load a DUMMY block entity @ … but
found not block entity block minecraft:air` (29 à 51 occurrences par test) —
autrement dit des block entities fantômes enregistrées sur des blocs devenus de
l'air. Corrigé en `2 | 16 | 32` (client averti, forme des voisins non recalculée,
drops supprimés). Détail et preuve en jeu dans `CHANGELOG.md`.
