═══════════════════════════════════════════════════════════════════
  DEEP LUCKY BLOCK — 1.21.1 NEOFORGE — v8  (armures + coffres + traces)
═══════════════════════════════════════════════════════════════════

POURQUOI UNE v8 ?
─────────────────
Ton dernier log de test (celui que tu m'as renvoyé) prouve que le jeu
tournait avec le code v6, PAS la v7 :
  • "Prepared 7 mixins" — FAUX depuis le T4 (20/09) : la config réellement
    déclarée (deep_lucky_block.mixins.json, JAVA_21) contient 0 mixin commun +
    5 mixins client, et un serveur dédié en prépare 2 (les mixins client sont
    ignorés hors client). Le chiffre "7" ne correspond à rien. Six classes
    mixin existent dans deepluckyblock/mixin/ mais ne sont déclarées NULLE
    PART (LuckyStatsSyncMixin, LuckyTweaksDimensionPoolMixin,
    LuckyXpEventRollsMixin, LuckyXpRouletteOverlayMixin, LuckyXpShowerMixin,
    ItemChestTagTransferMixin) : elles sont INERTES, ce n'est pas un bug de
    copie de fichiers ;
  • le mixin HumanoidArmorLayerEnchantMixin apparaît avec seulement 2
    injections (capture/clear de l'aura) — la v7 en a 3 ;
  • aucune ligne [SLB-V7] dans tout le log ;
  • en revanche "Samouss-DEBUG: positions armure corrigees" EST présent
    (c'est du code d'origine de MCreator, pas le mien).
Autrement dit : les fichiers v7 n'ont pas été recopiés dans ton
workspace MCreator. La v8 corrige ça par deux moyens :
  1. une bannière de version dans le log — la 1re ligne après "Prepared"
     doit être "[SLB-V8] Deep Lucky Block v8 (2026-09-05) charge" ;
     SI TU NE VERRAS PAS [SLB-V8], c'est que les fichiers ne sont pas
     les bons, et il faut relire la procédure ci-dessous.
     (T4 20/09 : la bannière passait par System.out, elle n'était donc écrite
     dans AUCUN fichier de log — la consigne "chercher dans le log" était
     impossible à satisfaire. Elle passe maintenant par le logger du mod :
     elle apparaît bien dans logs/latest.log, en plus de la console.)
  2. des diagnostics [SLB-V8] qui tracent tout le flux (pose, casse,
     infusion, coffre) même si MCreator régénère des fichiers.

CE QUI CHANGE EN v8
────────────────────
ARMURES (fix définitif, par le mécanisme OFFICIEL de NeoForge) :
  • J'ai relus les sources de NeoForge 1.21.1 : le hook getHumanoidArmorModel
    des items EST appelé par HumanoidArmorLayer (c'est pour ça que ton log
    montre "Samouss-DEBUG: positions armure corrigees"). MAIS la boucle de
    rendu de NeoForge ne s'exécute que s'il y a au moins UN "layer" dans le
    material de l'armure — les tiens en avaient ZÉRO (List.of()) → 0 rendu
    → invisible. Le workaround de rendu que j'avais mis en v7 (CustomArmorRender
    + injection mixin) n'était pas nécessaire : je l'ai retiré.
  • Fix : SAMOUSS_MATERIAL et LUNETTES_MATERIAL ont maintenant un
    ArmorMaterial.Layer (init/DeepLuckyBlockModItems.java). Résultat :
    NeoForge rend le modèle Blockbench custom (hook item) avec la texture du
    mod, le glint d'enchante s'applique sur le modèle custom, et c'est du
    code 100 % officiel (plus fragile = jamais).
  • À vérifier : équiper le Samouss / les Lunettes du Patron et les regarder
    de face + F5.

COFFRES (fix v7 conservé) :
  • Lucky Chests : le drapeau passe par NeoForgeData + BLOCK_ENTITY_DATA au
    chargement (survit aux rechargements /data sync), + filet de transfert
    à la pose du coffre, + force de chargement de la procédure.
  • Diagnostic [SLB-V8] COFFRE : clic droit sur un coffre → le log dit
    s'il porte les drapeaux slb_* et son rank.

LUCK (diagnostics pour localiser, le flux a été audité sans bug) :
  • Nouveau fichier manuel SlbDiagnostics.java (MCreator ne peut pas le
    régénérer) qui trace, avec [SLB-V8] :
      POSE      : item dans la main au clic droit → "luck=10" attendu.
                  (la luck vient de l'infusion — POSE=10 prouve que
                  l'infusion a fonctionné ; la recette trace aussi
                  [SLB-DEBUG] infusion: ... luckFinale=10) ;
      CASSE     : blockentity au moment de la casse → "beLuck=10" attendu.
  • En jeu, un bloc +10 cassé DOIT afficher le holo flottant
    "⚡ +10% Luck Bonus!" au-dessus de la roue. Si le holo s'affiche mais
    que les drops semblent identiques, le problème est dans la roue elle-
    même (les logs [SLB-DEBUG] de TestProcedure, si tes fichiers sont les
    miens, donneront la valeur effectiveLuck).
  • SI les traces disent luck=10 partout et que c'est encore KO →
    renvoie-moi ces lignes [SLB-V8], j'attaque la roue.

CONSOLE (invariable)
────────────────────
  ./gradlew runClient        (le client intégré, pas le jar)

INSTALLATION — LIRE AVANT TOUT (c'est ici que ça a cassé la dernière fois)
──────────────────────────────────────────────────────────────────────────
Ton workspace MCreator est :
  C:\Users\Nazario Delucci\MCreatorWorkspaces\deep_lucky_block-neoforge-1.21.1

La v7 a échoué parce que seuls certains fichiers avaient été remplacés.
Cette fois, REMPLACEMENT COMPLET :

  Étape 1 — Ferme MCreator (totalement, vérifier la barre des tâches).
  Étape 2 — Renomme ton dossier actuel :
            deep_lucky_block-neoforge-1.21.1  →  deep_lucky_block-NEO-backup
            (ne le supprime PAS, on aura besoin de tes fichiers MCreator)
  Étape 3 — Dézippe CE zip v8 dans C:\Users\Nazario Delucci\MCreatorWorkspaces\
            → il crée le dossier  deep_lucky_block_1.21.1\  ... ce NOM EST
            DIFFÉRENT, on va le corriger à l'étape 4.
  Étape 4 — De ton dossier de backup, copie dans deep_lucky_block_1.21.1\
            TOUT ce qui n'y est PAS encore (ou écraser) :
              •  MCreatorWorkspace.json
              •  les dossiers  elements\  et  procedures\  (si présents
                 dans le zip, sinon garde les tiens du backup)
              •  le dossier  .mcreator\  (si présent)
            En résumé : le zip v8 = base du projet ; tout fichier de
            MCreator (workspace.json, elements, procedures, .mcreator)
            provient du backup et doit être présent à la fin.
            Les fichiers Java/src/resources du zip v8 ne sont JAMAIS
            remplacés par ceux du backup.
  Étape 5 — Renomme  deep_lucky_block_1.21.1  →  deep_lucky_block-neoforge-1.21.1
            (exactement ce nom, pour que MCreator le trouve).
  Étape 6 — Dans MCreator : File → Open, ouvre le workspace.
  Étape 7 — Avant de lancer : vérifie 2 fichiers dans ton workspace
            (double-clic → Notepad) :
            a) src\main\java\deepluckyblock\init\DeepLuckyBlockModItems.java
               → doit contenir la ligne  "ARMOR_LAYER_TEXTURE"
                 (sinon = mauvais fichier → recommence l'étape 4).
            b) src\main\java\deepluckyblock\SlbDiagnostics.java
               → le fichier doit EXISTER (sinon = mauvais dossier).
  Étape 8 — runClient.

VÉRIFICATION DU BON CODE (dans le log, tout en haut) :
  ✔  "[SLB-V8] Deep Lucky Block v8 (2026-09-05) charge"
  ✔  "Compatibility level set to JAVA_21"  (vérifie la config de mixins déclarée)
  ✔  "Prepared 2 mixins"  (serveur dédié ; sur client : "Prepared 5 mixins")
     — la valeur "Prepared 7 mixins" des anciennes versions n'existe plus.
  ✘  si tu vois "patch v7" ou pas de [SLB-V8] → mauvais fichiers,
     recommence l'installation.

TESTS À FAIRE (dans l'ordre)
────────────────────────────
  1. ARMURES : ouvre l'onglet créatif Deep's Lucky Block, prends le Samouss
     (tête, poitrine, jambes) et les Lunettes du Patron, équipe-toi,
     regarde-toi + F5. → DOIT être visible (cochon en armure, lunettes).
  2. LUCK : craft un Deep Lucky Block + 1 carotte dorée (recette d'infusion)
     → log [SLB-DEBUG] infusion doit dire luckFinale=10. Pose-le →
     [SLB-V8] POSE luck=10. Casse-le → [SLB-V8] CASSE beLuck=10 + holo
     "⚡ +10% Luck Bonus!" en jeu.
  3. COFFRES : pose 2 Lucky Chests + 1 Deep Lucky Block entre/autour,
     clic droit → le coffre se remplit (log [SLB-V8] COFFRE + [SLB-CHEST]
     si le filet de transfert a dû jouer).
  4. GLINT : un bloc enchante + une armure enchantée → aura dorée (déjà
     corrigé, juste une ré-vérification).

RENVOIE-MOI SI KO :
  • le log COMPLET (dès "Prepared ..." jusqu'à tes actions) ;
  • les lignes [SLB-V8] exactement ;
  • ce que tu vois en jeu pour l'armure (rien / noir / partielle) et le
     holo de la roue (affiché ou non, avec quel texte).

═══════════════════════════════════════════════════════════════════


═══════════════════════════════════════════════════════════════════
  JOURNAL DES VERSIONS — MISE À JOUR 21/09/2026 (soir)
═══════════════════════════════════════════════════════════════════

Dernier build de référence : build/libs/deep_lucky_block-1.0.jar
  = 8 844 137 octets (21/09 23:04) — copie dans jar/deep_lucky_block-1.0.jar

Ce qui a changé depuis la v8 (pipeline de structures uniquement, aucun import
manuel de ta part n'est nécessaire : remplace le jar et c'est tout) :

  T26  le terrain est rendu DÉFINITIF AVANT la pose de la structure
       (les deux lissages qui tournaient après le paste sont supprimés :
       ils recreusaient le pourtour du bâtiment)
  T27  une structure ne se pose plus JAMAIS dans une autre
       (registre d'emprises ; déplacement automatique, ex. 32/48 blocs)
  T28  l'everest S'ENFONCE de 10 blocs dans le terrain (valeur fixée par toi le 22/09 ;
       modifiable d'une seule ligne : EVEREST_SINK_BLOCKS dans Structures4Procedure)
  T29  la position libre est cherchée AVANT la lecture de hauteur (déplacement
       automatique si l'emplacement est déjà pris par une autre structure)
  T30  everest : pré-chargement de l'emprise finale -> 15,6 s -> 4,3 s,
       plus aucun tick de 10 s
  T31  « Incassable » ajouté à la description du Bo Cube De Bois (fr + en)
  T32  everest : pré-chargement de TOUTE son emprise (88 -> 164 blocs) :
       plus aucun gel pendant la pose

Mesures de la dernière passe en jeu (monde neuf / monde déjà modifié) :
  · observatoire : 34,0 s -> 14,0 s ; écart au terrain naturel 2,08 blocs
  · everest      : 4,33 s (52 979 blocs), pire tick 243 ms
  · 0 watchdog, 0 OutOfMemory, 0 « Can't keep up »

Documents mis à jour : CHANGELOG.md (T26 → T31), COMMITS_A_APPLIQUER_2026-09-20.md,
CAHIER_DEV_16_REMARQUES_2026-09-21.md, AUDIT_EXHAUSTIF_DEV_T0_T32_2026-09-22.md,
TEST_T26_T31_2026-09-21.log (log de la passe finale, complet).

---

## T33 / T34 (22/09) — retour de ton test en jeu

1. **Le gel est réglé à la racine.** La pose de l'everest appelait une **génération de chunk
   synchrone avant chaque bloc** : 644 demandes de chargement dans le même tick, d'où les 36 824 ms.
   Le bloc attend maintenant son chunk (demande en tâche de fond) et il est reposé au tick suivant.
   Mesuré : **everest 61 s → 15,754 s**, aucune génération synchrone, **0 tick > 1 s pendant la pose**.
   Toutes les boucles de pose ont en plus un **budget de temps de 40 ms par tick**.
2. **Le sélecteur de zone plate n'était pas cassé, mais il jetait ses meilleurs candidats** : chaque
   chevauchement d'emprise (`REJETE : emprise 'everest'`) supprimait une zone réellement plate, et il
   finissait sur le repli « le moins pentu ». Il **décale** désormais le candidat au lieu de le jeter
   et vérifie 24 candidats (au lieu de 12). Log : `Zone choisie ... (candidat #1/24)`.
3. **Berges d'eau** : elles sont remontées de **1 à 2 blocs** et prennent une **forme de sphère
   (losange type axium)** au lieu d'un mur d'un bloc ; après la pose, le jeu **vérifie que l'eau ne
   peut plus partir** et renforce jusqu'à 2 fois si besoin. Log : `267 blocs de berge places`.
4. **Passe finale de terrain** : vue de haut **chunk par chunk puis globale**, sur le **terrain sol
   uniquement**, elle **comble les creux** et **rabote les petites lignes / blocs singuliers trop
   hauts** (écart maximal 2 blocs, rayon 6 autour du bâti), et c'est bien la **dernière** opération
   sur le terrain. Log : `61 colonnes retouchees (39 cuvettes comblees, 22 saillies rabotees)`.
5. `fixWater` : `fixWaterNearStructure` (rayon 20, 4 passes) tourne bien après les smooths, et les
   creux de futurs lacs sont re-remplis par la passe finale (cuvettes) — à confirmer à l'œil.

**À tester de ton côté** : relance `runClient`, fais sortir un **everest** et un **observatory/dragon**,
et regarde (a) qu'il n'y a plus de gel joueur, (b) les berges de lac (remontées + forme arrondie),
(c) les abords de structure (plus de petites lignes ni de blocs isolés trop hauts).

---

## T35 / T36 / T37 (22/09, suite) — creux, structures « brutes », gel résiduel

1. **Trous profonds** : les creux de plus de 2 blocs étaient **hors de portée** de la passe finale
   (elle ne traitait que les écarts ≤ 2 blocs). Un trou **isolé** (7 voisines sur 8 plus hautes) est
   maintenant **rebouché jusqu'à la médiane des voisines** — jamais plus haut, donc jamais de tour —
   et jamais un ravin, une vallée ou une mine (profondeur bornée à 48 blocs).
2. **Everest et circus n'avaient AUCUN travail de terrain** : ils sont posés « brut » (l'everest
   s'enfonce de 10 blocs) alors que tout le reste passe par `prepZone`/`decorate`. C'est pour ça que
   les creux et les berges trop basses se voyaient surtout autour d'eux. Ils reçoivent maintenant la
   **passe finale de terrain**, en dernier, exactement comme les autres structures.
3. **Gel résiduel supprimé** : la boîte de pré-chargement de l'everest était centrée sur un point
   alors que la montagne occupe 191×295 blocs → **435 demandes de chargement pendant la pose**
   (tick de 9 s). Elle pré-charge maintenant **exactement son emprise**.
   Résultat : **everest 61 s → 14,6 s**, plus aucune demande de chargement pendant la pose.
4. **La passe finale ne se limite plus à un bout de la zone** : elle était coupée par un budget de
   120 ms (14 chunks sur 187×291...). Elle travaille maintenant **par tranches de 40 ms réparties sur
   plusieurs ticks** : aucun gel, et la zone entière est traitée.

**À tester de ton côté** : everest (gel + creux autour), circus (creux dans/autour du cirque),
et une structure au bord d'un lac (berges).


---

## T39 → T45 (retour en jeu du 23/09) — à lire avant de tester

### 1. Nouvel ordre du pipeline : le terrain d'abord, la structure EN DERNIER

```
prepZone (11 étapes)
   ↓
decorateTerrainOnly :  failles/marches → smooths → eau + berges → hole filler
                       → balayage des lianes → PASSE FINALE → /fixwater+/fixlava
   ↓
PASTE de la structure            ← plus rien ne la retouche ensuite
   ↓
carve (dégagement + motte)  →  decorateFinish : décors, arbres, naturalisation
```

Contrôle en jeu : dans le log, la ligne
`decorate TERRAIN TERMINÉ : terrain figé, la structure peut être posée (T39)`
doit toujours être **juste avant** l'annonce de pose de la structure
(`[STRUCT5] <nom> en Xms`), et `decorate TERMINÉ (… structure posée en DERNIER, T39)`
**après** les décors.

### 2. `/fixwater 1000` + `/fixlava` (T38)

À la fin de la phase terrain, toutes les eaux/laves *flowing* des chunks **chargés**
dans un rayon de 1000 blocs autour de la structure sont converties en **sources**
stationnaires, puis le niveau du plus haut bloc d'eau/lave est **propagé** pour
re-remplir les cuvettes vides reliées au fleuve/lac (c'est le « re remplir » du
fleuve gelé). Tout est découpé en tranches (40 ms/tick) : aucun gel. Ligne à
chercher : `fixLiquids TERMINÉ : X bloc(s) flowing -> source, …`.

### 3. Hole filler (T40)

Les tunnels, galeries et cavités encadrés par de la matière sont rebouchés avec le
matériau du sol (jusqu'à 250 000 blocs par structure, 64 blocs de profondeur).
Ligne : `hole filler TERMINÉ : N poche(s) rebouchée(s), M bloc(s)`.

### 4. Lianes et naturels flottants (T41/T45)

Balayage sur **tout l'anneau** (plus seulement 8 blocs) et sur **les deux** chemins
(y compris everest/circus). Un arbre vivant est conservé (les canopées en
porte-à-faux aussi) ; une liane accrochée à rien, un îlot d'herbe ou un reste de
l'ancien terrain partent. Ligne : `balayage étendu TERMINÉ : N bloc(s) …`.

### 5. Mini-structures décoratives (T42)

Elles sont ancrées sur leur plus bas bloc réel et plaquées au sol après pose.
Ligne : `scatter [thème] : T42 -- N colonne(s) de décors plaquées au sol`.

### 6. À vérifier de ton côté (le plus utile)

1. **everest** : le paste doit arriver APRÈS « terrain figé » ; plus aucun smooth
   ne doit passer sur la montagne ; vérifier qu'aucune liane ne vole autour.
2. une structure **au bord d'un lac/fleuve** : `/fixwater 1000` doit re-remplir la
   zone vidée (voir la ligne `fixLiquids TERMINÉ`) et la lave doit être traitée aussi.
3. **tunnels/failles** visibles dans le terrain modifié : ils doivent être rebouchés
   (ligne `hole filler TERMINÉ`).
4. **mini-décors** : plus aucune mini-structure 1-2 blocs au-dessus du sol.

═══════════════════════════════════════════════════════════════════
  T46 — LE CHARGEMENT DES STRUCTURES N'EST PLUS UNE ATTENTE SANS FIN
═══════════════════════════════════════════════════════════════════

CE QUI ÉTAIT CASSÉ (ton log du 23/09 au soir)
─────────────────────────────────────────────
Le pré-chargement des chunks du lac (406x444 = 783 chunks) a tourné **24 minutes
sans finir** (~2 chunks toutes les 30 s) alors que tu demandes « max 1 minute
total ». Trois causes cumulées : le ChunkKeeper ne demandait que les 4 premiers
chunks de sa liste (donc aucune génération en parallèle), le compteur de
progression n'avançait que sur des chunks consécutifs (un seul chunk lent gelait
tout), et il n'y avait aucune borne de temps : le pipeline attendait 100 % de la
zone, ce qui est impossible sur un monde neuf.

CE QUE ÇA DONNE MAINTENANT
──────────────────────────
1. Les chunks sont demandés sur TOUTE la zone, par lots, en tâche de fond
   (`getChunkFuture`) : c'est la génération du moteur qui travaille en parallèle.
2. Le pipeline attend au maximum **25 s** : 20 s pour le CŒUR (emprise + 48 blocs),
   8 s de plus pour l'anneau de terrain. Passé ce délai il démarre quand même,
   avec les chunks disponibles ; les passes sautent les colonnes absentes.
3. Le repli synchrone est limité au cœur et à **1 chunk par tick** (avant :
   jusqu'à 20 s dans un seul tick → watchdog).
4. **Crimson Lake** : la zone est demandée dès l'annonce « la construction démarre
   dans 60 s ». Les 60 s servent maintenant à générer le terrain, donc à l'heure du
   build il n'y a plus rien à attendre (sans épingler 750 chunks en RAM : le
   pré-chauffage demande la génération sans maintien).

TES LIGNES À SURVEILLER DANS LE LOG
───────────────────────────────────
```
[DLB-STRUCTURE] pre-chauffage : 783 chunks demandes des maintenant (...) -- ils se generent
                pendant l'annonce au lieu de bloquer le debut du pipeline
[DLB-STRUCTURE] pre-chargement : 419/783 chunks en 15 s (coeur 240/240) -- demandes en tache
                de fond, tick libre
[DLB-STRUCTURE] pre-chargement : coeur complet (240/240) -- l'anneau continue en tache de fond,
                demarrage du pipeline
[DLB-STRUCTURE] pre-chargement TERMINE en 20.4 s : coeur 240/240, zone 419/783 -- 364 chunk(s)
                non charges (colonnes sautees, ...)
```

Selon les cas tu verras « BUDGET DE TEMPS ATTEINT (25 s) -- demarrage du pipeline avec N/M
chunks » : **c'est normal et voulu**. Sur un monde neuf, 783 chunks vierges ne peuvent pas
être générés en 25 s ; ils continuent de se charger pour la suite, et la structure est posée
sur des chunks garantis chargés (T43).

TEMPS ATTENDUS
──────────────
| Étape | Avant (23/09) | Maintenant |
|---|---|---|
| annonce 60 s | chunks pas encore demandés | génération en cours |
| pré-chargement zone lac (783 chunks) | 24 min, jamais fini | ≤ 25 s |
| pipeline complet du lac | jamais atteint | ~40 à 60 s au total |

À VÉRIFIER DE TON CÔTÉ
──────────────────────
1. En jeu : le lac doit se poser **dans la minute** qui suit l'annonce.
2. Plus de `Can't keep up` de 20+ secondes pendant le pré-chargement (il peut en
   rester un de quelques secondes pendant la pose elle-même sur une petite machine).
3. Les autres structures (observatory, everest) doivent rester correctes : la
   validation de régression est dans `TEST_T46_2026-09-23.log`.

SI TU VOIS ENCORE UN BLOCAGE
────────────────────────────
Envoie-moi les lignes `pre-chargement`/`pre-chauffage` du log : elles donnent la
progression chiffrée seconde par seconde et suffisent à localiser un nouveau goulot.

═══════════════════════════════════════════════════════════════════
  T47/T48 — LA PASSE VITESSE : OU PASSENT LES SECONDES, ET POURQUOI
═══════════════════════════════════════════════════════════════════

CE QUE TON LOG A RÉVÉLÉ
───────────────────────
1. Les chunks SE CHARGEAIENT : `700/700 chunks épinglés` en 30 s. C'est le **compteur** du
   pré-chargement qui était faux (`0/783` alors que 700 chunks étaient en mémoire).
2. Le vrai tueur : le « repli forcé » appelait une génération **synchrone**
   (`getChunk(..., true)`) → ~15 s de blocage du serveur **par chunk**, 2 chunks toutes les
   30 s, d'où les `Can't keep up! Running 26381ms`. Un seul appel bloquant peut geler le jeu
   26 secondes : c'est ça, « les temps de fou ».
3. Aucune borne de temps : le pipeline attendait 100 % d'une zone de 783 chunks.

CE QUI CHANGE
─────────────
• **Pré-chauffage pendant l'annonce** (T46) : les 60 s de « Please step back! » servent
  maintenant à générer la zone en tâche de fond.
• **Budgets adaptatifs** (T47) : zone géante (> 512 chunks, le lac en fait 783) → 12 s de cœur
  + 4 s d'anneau, plafond **15 s**, et **aucun blocage synchrone** ; zone normale → 20/8/25 s.
• **Crimson Lake ne bloque plus** (T48) : un bloc dont le chunk n'est pas prêt est **différé**
  (reposé au tick suivant) au lieu de générer le chunk sur le thread principal.
• **Crimson Lake respecte enfin l'ordre T39** (T48) : terrain figé → pose → finitions seules.
  Avant, toute la chaine terrain (smooths, failles, eau, hole filler, passe finale) repassait
  APRÈS la pose, sur 783 chunks.

LA LIGNE À ME RENVOYER (nouvelle)
────────────────────────────────
En fin de construction, une seule ligne résume où sont passées les secondes :

```
[DLB-PERF] TACHE COMPLETE en 31.6 s -- ou est passe le temps : pre-chargement des chunks
23.2 s (73%) | balayage etendu des naturels flottants 1.4 s (4%) | hole filler 0.7 s (2%) |
fixLiquids 0.1 s (0%) | attente/tick system 6.2 s
```

TEMPS ATTENDUS
──────────────
| Étape | Avant | Maintenant |
|---|---|---|
| pré-chargement du lac (783 chunks) | 24 min, jamais fini | **≤ 15 s** grâce au pré-chauffage |
| pipeline complet du lac | jamais atteint | **1 à 3 min** (annonce 60 s incluse) |
| observatory / everest | 35 à 165 s | **15 à 30 s** sur ta machine |

À VÉRIFIER DE TON CÔTÉ
──────────────────────
1. Crimson Lake : chronomètre entre l'annonce et la fin de la pose (attendu ≤ 3-5 min).
2. Cherche `Can't keep up` : plus aucune valeur de plusieurs secondes pendant le pré-chargement.
3. L'ordre : `decorate TERRAIN TERMINÉ … terrain figé` AVANT la pose, puis
   `decorate TERMINÉ (… structure posée en DERNIER, T39)`.
4. Envoie-moi la ligne `[DLB-PERF]` : elle me dit exactement quoi optimiser ensuite.

═══════════════════════════════════════════════════════════════════
  T49 → T52 — POURQUOI ÇA PRENAIT UNE HEURE (ET CE QUI RESTE À VOIR)
═══════════════════════════════════════════════════════════════════

LA CAUSE, EN UNE LIGNE
──────────────────────
`getChunk(cx, cz, FULL, true)` = génération **synchrone sur le thread du serveur**.
Sur un monde neuf, une génération FULL attend la cascade de ses voisins : **~15 s de gel par
chunk**. C'est ce que montre ton log (`Can't keep up! Running 26381ms`, 2 chunks livrés toutes
les 30 s, `0/783 → 199/783` en 24 min).

CE QUI EST FAIT
───────────────
1. **T49** — plus aucune génération synchrone dans les chemins chauds : `primeChunk()` (appelé à
   **chaque colonne de terrain** !), `captureHeightmap()`, la vérification de pente du `findFlatArea`
   (~300 chunks × 12-24 candidats), la repose des blocs différés, `backfillVoidGap()`.
2. **T51** — le pré-chauffage est **borné en mémoire** : les N chunks les plus proches du centre,
   par vagues de 16, sans rien épingler (plafond adapté à ton tas de RAM ; `-Ddlb.preheat=N`).
3. **T52** — même les « secours » synchrones ont été retirés : plus aucun appel bloquant, pour
   aucune structure.
4. **T50b** — une commande de test : **`/dlbtest crimsonlake`** rejoue tout l'événement du lac
   (annonce de 60 s comprise) sans attendre le 1/500.

CE QUE TU DOIS FAIRE (2 mesures, 5 minutes)
───────────────────────────────────────────
```
/dlbtest crimsonlake          ← le lac
/dlbtest structure 5          ← everest (une structure normale, pour comparer)
```
Puis envoie-moi les lignes **`[DLB-PERF]`** (une par pipeline). Elles donnent la répartition
exacte des secondes :
`[DLB-PERF] TACHE COMPLETE en X s -- ou est passe le temps : pre-chargement 12,3 s (23%) | ...`

CE QUE TU DOIS VOIR DANS LE LOG
───────────────────────────────
* `pre-chauffage : 256 chunk(s) demandes des maintenant sur 754 (… plafond memoire 256)`
* `pre-chargement : … budget 15 s (zone geante : coeur 12 s + anneau 4 s) (T52 : aucun secours synchrone)`
* **plus aucun** `Can't keep up! Running 26xxx ms` : des micro-freezes de quelques centaines de ms
  sont normaux pendant la pose, des gels de 10 s ne le sont plus.
* avant la pose : `decorate TERRAIN TERMINE : terrain fige, la structure peut etre posee (T39)`
* après la pose : `decorate TERMINE (… structure posee en DERNIER, T39)`

RÉSULTATS MESURÉS (bac à sable 2 vCPU — ta machine fait mieux)
──────────────────────────────────────────────────────────────
| Test | Résultat |
|---|---|
| pipeline complet du lac (zone 754 chunks, petit NBT) | **52,1 s**, ordre T39 respecté, 0 exception |
| everest, monde neuf (484 chunks) | **73,2 s** dont 25 s de pré-chargement plafonné, 52 979 blocs |
| `/fixwater` rayon 1000 (15 876 chunks candidats) | 345 ms (seuls les chunks chargés sont traités) |

CE QUI RESTE (à arbitrer avec tes mesures)
──────────────────────────────────────────
Une fois les gels supprimés, le temps restant est du **travail réel** sur la zone : pour le lac,
**11 passes de terrain sur 146 292 colonnes** (balayage des naturels, hole filler, lissages,
vérification de l'herbe, nettoyage). Si le total reste au-dessus de tes 3-5 min, la ligne
`[DLB-PERF]` désignera directement la passe à alléger (réduction du rayon de la zone, ou une seule
passe au lieu de deux sur les mêmes colonnes) — envoie-la et je m'occupe du reste.


---

## Passe « OPTI ULTIME » (T53 → T66) — ce qui change pour toi

**Le gel avant la structure est mort.** Il ne venait pas des lectures de terrain (elles ont toujours
ete instantanees : 752 recherches de chunk = 3 ms), mais des **demandes de chargement** : la boucle
qui classait les zones demandait 600+ chunks dans un seul tick, soit 17 s de gel. Depuis T63 le
classement ne demande plus **rien** ; depuis T64 la verification des candidats non plus.

Mesure en jeu (bac a sable 2 vCPU, monde neuf, observatoire) : `run/logs/t66_run1.log`

* grille de scoring : **22 ms** (avant : 16 982 ms) ;
* scoring des 464 candidats : **2 ms** ;
* pre-chargement de la zone : **7,1 s**, 144/144 chunks ;
* **pipeline complet : 20,5 s**, structure posee en dernier (consigne T39), **0 exception**,
  1 seule alerte « Can't keep up » de 4,1 s (generation vanilla des chunks).

Lignes a chercher dans ton `run/logs/latest.log` :

* `[DLB-PERF] TACHE COMPLETE en ... s -- ou est passe le temps : ...` (bilan par phase) ;
* `[DLB-CHUNKS] N/N chunks epingles ... -- zone complete` ;
* `[STRUCT5-FLAT] grille de scoring : 47x47 cellules (N connues) en X ms -- T59/T62 (...)` ;
* `[STRUCT5-FLAT] scoring termine : N candidat(s) en X ms`.

**A re-tester de ton cote** : crimsonlake (critere « 3-5 min MAX »). Derniere mesure de mon cote :
52,1 s (`run/logs/t51_run3.log`) ; le bac a sable a 2 Go ne permet plus de le relancer (le processus
java s'y fait tuer par le noyau), donc la mesure du lac doit venir de ta machine.


---

## T67 — `/dlbtest` : une commande par structure, et le TAB propose tout

**Tape `/dlbtest` puis TAB** : tu obtiendras la liste complète. Il y a maintenant une entrée par
structure, avec son nom simple (le nom du fichier .nbt) :

```
/dlbtest citadel        (alias : citadelle)
/dlbtest observatory    (alias : obs, observatoire)
/dlbtest dragon
/dlbtest circus         (alias : cirque)
/dlbtest ship           (alias : shipdead, bateau)
/dlbtest everest
/dlbtest crimsonlake    (alias : lake, lac, crimson)
```

Outils de test :

```
/dlbtest list                 la table des structures (noms CLIQUABLES : un clic lance la structure)
/dlbtest tree                 l'arbre reellement enregistre (= ce que le tab te proposera)
/dlbtest structure <nom|id>   ancienne syntaxe conservee, avec suggestions ; accepte aussi 0, 5, 16...
/dlbtest water status|freeze [rayon]|thaw
/dlbtest probe <x> <z>
/dlbtest luckybreak [nombre]
```

**Ce qui a changé côté « ça ne marchait pas »** :

1. la racine exigeait la **permission 2** : en solo sans cheats, la commande n'est ni exécutable ni
   proposée → elle demande désormais **permission 0** (tout le monde) ;
2. il n'existait pas de `/dlbtest everest` (seulement `/dlbtest structure <id>`) → chaque structure a
   son nœud littéral, donc **proposé par le tab** ;
3. le paramètre était un **entier** → il accepte maintenant un **nom** (avec suggestions).

**Si la commande n'apparaît toujours pas** :

* vérifie dans le log la ligne de démarrage
  `[DLBTEST] commande prete : /dlbtest -> citadel, observatory, dragon, circus, ship, everest, crimsonlake`
  → absente = le jar du mod n'est pas chargé (mets bien le **nouveau**
  `deep_lucky_block-1.0.jar`, md5 `f51c7dc6e28026aa85c1ec8619bc292c`) ;
* en **solo** : active les cheats sur le monde (sinon Minecraft masque **toutes** les commandes,
  quelle que soit la permission) ;
* en jeu, `/dlbtest tree` doit lister **23 entrées**.


---

## T68 → T70 — les grosses structures (everest) ne font plus tomber le serveur

Trois correctifs issus d'un test « everest seul » (zone de 667 chunks) qui finissait
systématiquement par un **arrêt du serveur** (`Watchdog : A single server tick took 60 seconds`)
pendant le **balayage des naturels flottants** :

1. **T68 — budget vérifié à chaque colonne.** Il n'était testé qu'entre deux lots de 384 colonnes ;
   comme une colonne peut coûter très cher (58 lectures + exploration d'un amas), un lot défonçait le
   tick : **38 340 ms → plus de 60 s du tout**. Le mod te dit désormais quelles colonnes sont lentes
   (`N colonne(s) lente(s) (> 50 ms chacune, pire X ms)`).
2. **T69 — exploration d'amas bornée à 20 ms.** Au-delà, l'amas est considéré comme **ancré** :
   on **conserve** au lieu d'effacer un amas non vérifié.
3. **T70 — plus de colonnes perdues.** Quand un chunk n'était pas encore chargé, la colonne était
   jetée (`43 321 colonnes sautees` + `45 737` sur everest). Elle est maintenant **reprise
   automatiquement** dès que le chunk arrive.

**Résultat mesuré, everest, monde neuf** (`run/logs/t70_run1.log`) :

```
[DLBTEST] everest demandee a 0, 58, 0 (id=5, nbt=everest, joueur factice)
[DLB-CHUNKS] 667/667 chunks epingles (maintien en memoire) -- zone complete
balayage etendu … : 66750 bloc(s) naturel(s) flottant(s) retire(s) sur 147065 colonnes
hole filler TERMINE : 50970 poche(s) rebouchee(s), 250000 bloc(s)
[DLB-PERF] TACHE COMPLETE en 104.5 s
```

* **aucun** Watchdog, **aucune** colonne non traitée, serveur toujours vivant après la pose ;
* observatoire (structure normale) : pipeline complet en **17,9 s**.


---

## T71 → T72 — le rebouchage va plus vite et va au bout (plus de tunnels abandonnés)

Deux changements issus des mesures sur everest :

1. **Les blocs sont lus par sections de 16** (au lieu d'un par un) dans le **hole filler** et le
   **balayage des naturels flottants**. Une section entièrement pleine (pierre) ou entièrement vide
   (air) se règle d'un coup : ~30 % plus rapide à travail égal.
2. **Le plafond de rebouchage n'abandonne plus en silence.** Avant, la passe s'arrêtait à
   250 000 blocs sans le dire — c'est une partie des « tunnels encore présents » que tu avais
   signalés. Le plafond est passé à **400 000**, il est **réglable**
   (`-Ddlb.holeFillMax=N`) et son atteinte est **journalisée** :
   `hole filler TERMINE : … -- PLAFOND ATTEINT : N colonne(s) NON analysée(s)`.

**Mesures (everest, monde neuf)** : **71 238 poches** rebouchées / **333 798 blocs** (avant :
50 970 / 250 000, plafond bloquant), **0 colonne non traitée**, coût par bloc **-31 %**.
Total everest : **116,4 s** dont **40 % de génération de chunks** (partie qui ne dépend pas du mod
et qui ira bien plus vite sur ta machine). Structure normale (observatoire) : **22,0 s**.

**À vérifier de ton côté** : ouvre un lucky block en zone de collines et regarde s'il reste des
tunnels/faille non rebouchés autour de la structure. Si oui, relance avec
`-Ddlb.holeFillMax=800000` et envoie-moi la ligne `hole filler TERMINE`.


---

## T70b — l'outil n'attend plus jamais pour rien

Un dernier garde-fou : quand une passe avait des colonnes dont les chunks ne revenaient pas alors que
la zone était déjà complète, elle pouvait patienter jusqu'à 30 s pour rien. Elle se termine
maintenant proprement, avec un message honnête :
`N colonne(s) inaccessibles alors que la zone est complète -- passe terminée sans elles (aucune
attente inutile)`.

**Sur les chiffres** : ma machine de test a saturé en fin de session (charge 17-23, mémoire 2 Go) :
le **même jar** a donné 22,0 s puis 123,4 s puis 23,8 s sur la même structure. Les chiffres fiables
sont ceux des runs à charge normale : **observatoire 17,9-23,8 s**, **everest 104,5-120,3 s** (dont
**40 % de génération de chunks**, la partie qui ira bien plus vite sur ton PC), **grille de scoring
13-27 ms**. C'est **ta** machine qui doit trancher pour le critère « crimsonlake 3-5 min MAX ».

## T73 — l'air n'est plus un bloc (filtre NBT en flux)

Depuis T73, les structures ne sont plus lues comme avant : le fichier `.nbt` est filtre **en flux**
et l'air n'est **jamais materialise**. Concretement :

- **Ce que tu vois dans le journal** : `[STRUCT-CACHE] 'citadel' : 2 114 112 entree(s) au fichier ->
  105 276 bloc(s) a poser + 9 329 air interieur (1 999 507 air exterieur JAMAIS materialise(s) = 95 %,
  lecture en flux 1918 ms, 104x242x84) -- T73`, suivi de
  `positions lues X 0..103 Y 0..241 Z 0..83 (boite 104x242x84, 0 hors boite) -- T73b`.
- **Ce que ca change en jeu** : les grosses structures se chargent en 3-6 s en tache de fond (le
  serveur n'est jamais bloque) et se posent sans jamais parcourir des millions d'entrees d'air.
  Citadel, qui ne se chargeait pas du tout (memoire insuffisante), se pose desormais entierement.
- **Ce qui ne change pas** : l'air **interieur** (celui qui creuse l'interieur de la structure) est
  toujours pose, exactement comme avant ; les coffres et leurs donnees NBT sont conserves ; les
  structures sans air dans leur palette (everest, crimsonlake) sont lues comme avant.
- **Si tu veux desactiver le filtre** (pour comparer, ou en cas de doute) :
  `-Ddlb.nbtAirFilter=0` dans les arguments de lancement. Le seuil d'application est reglable :
  `-Ddlb.nbtAirFilterMinKb=32` (fichiers plus petits = lecture vanilla).
- **Point de vigilance** : `SafeSurface.request()` peut, sur un chunk system sature, attendre 60 s
  (watchdog) parce qu'elle utilise une demande de chunk bloquante. C'est ce qui a ete observe une
  fois pendant la mise au point (la cause etait une boite d'edition geante produite par un bug de
  decodage, corrige en T73b). Le traitement propre de cette API est identifie (T74) mais **pas
  applique** : dis-moi si tu veux que je le fasse.

### T75 — ce qui change en jeu (retour du 23/09 22:42)

* **Plus de structure dans le ciel** : l'ancrage se fait sur le sol solide (une cime d'arbre ou une
  surface d'eau ne comptent plus comme sol) et sur le **sol median de toute l'emprise**. Ligne a
  verifier dans `latest.log` : `[STRUCT5] <nom> : ancrage FINAL -- baseY=… et 1er bloc reel a Y=…
  (ecart au sol = …, deltaY=…)`. **Ecart <= 0 : la structure touche/s'enfonce dans le sol (normal :
  tes offsets oy sont negatifs). Ecart > +2 : structure suspendue, a signaler immediatement.**
* **Un lac n'est plus choisi comme zone de construction** : journal
  `[STRUCT5-FLAT] N candidat(s) ecarte(s) : surface en EAU`. Plus de `[STRUCT5-SAFETY] eau=100 %` et
  donc plus de relocalisation surprise.
* **Eau des chunks voisins** : `fixLiquids` charge a la demande l'anneau proche (emprise + 48 blocs)
  et retente (`1/2 : N chunks charges (M voisins charges a la demande, K jamais chargeables)`,
  `2/2 : X point(s) en attente d'un chunk voisin (tour i/6)`).
* **Temps** : les structures NBT sont rechauffees en tache de fond des le demarrage du monde
  (`[STRUCT-CACHE] rechauffage de fond '<nom>' demande au demarrage`), donc plus d'attente
  « toujours en cours de chargement (40 s) » quand tu casses le lucky block ; et le pipeline travaille
  70 % du tick au lieu de 24 % (`TASK_BUDGET_MS` 12 -> 35).
* **Decors** : `decorateFinish (POST-POSE, apres TOUS les fixwater)` ; aucun arbre/decor dans une
  colonne noyee.
* A surveiller dans TON log, et a m'envoyer si present : `sol de l'emprise tres irregulier`
  (structure posee sur un terrain en pente : dis-moi si tu la vois suspendue d'un cote) et le nouvel
  `[DLB-LAGPROBE] periode de tick de … ms` (> 1 s = un gel a localiser).

### T74 — la ligne a lire pour verifier qu'aucune structure ne vole

Chaque structure ecrit maintenant, juste avant sa pose :

```
[STRUCT5] <nom> : ancrage T75 -- sol median de l'emprise=67 (min=54, max=70, 184 colonnes mesurees)
[STRUCT5] <nom> : controle anti-vol OK -- bas de structure=33, sol reel median=65 (marge=32 bloc(s) d'enfoncement, T74)
[STRUCT5] <nom> : ancrage FINAL -- baseY=67 et 1er bloc reel a Y=33 (ecart au sol = -34, deltaY=4)
```

* **marge positive** = la structure s'enfonce dans le sol (normal : tes offsets `oy` sont negatifs :
  observatory -5, dragon -34, citadel -35) ;
* **`ecart au sol` positif au-dela de +2** = structure suspendue : dans ce cas le message
  `structure SUSPENDUE de N bloc(s) … ancrage corrige` apparait et la structure est **descendue
  automatiquement** sur le sol mesure.

### T76 — ce qui change en jeu (gel du 23/09 22:42)

* **Le gel est supprime** : plus de `[DLB-LAGPROBE] periode de tick de … ms` pendant le
  `pre-chargement` ni pendant `prepZone 1/11`. Les deux causes etaient un unique tick de 13 s
  (tempete d'application de chunks + `scanTrees`).
* **A verifier dans ton log** :
  * `prepZone 1/11 : scanTrees termine, N arbres sauves en X ms` -> **X doit etre de l'ordre de
    quelques dizaines de ms** (9 430 ms chez toi avant).
  * `replant : N arbres reels replantes` -> doit **augmenter** (4 -> 8 ici) : l'ancien algorithme
    perdait de vrais troncs. Le total « arbres sauves » peut baisser (19 -> 12) **sans** que ce soit
    une regression : il comptait des plantes de grottes (`big_dripleaf_stem`) comme des arbres.
  * `[DLB-CLAMP] fenetre fermee ... pire XXXX ms` -> la ligne qui resume le pire tick du pipeline.
* **Ce qui reste** : un seul tick long, `naturalize` (herbes/fleurs/champignons), environ 1,7 s ici
  (le LAGPROBE le nomme a tort `cleanupZone`). Deja identifie, ce sera la prochaine tache si tu le
  vois encore.
* **Outil de verification** (facultatif, pour verifier toi-meme les arbres) : lancer avec la variable
  d'environnement `DLB_TREE_CHECK=1` -> le mod rejoue l'ancien algorithme sur la meme zone dans le
  meme run et ecrit `VERIF ARBRES (T76) : nouveau=… ancien=… identiques=… OUBLIES=… EN_TROP=…`
  suivi de la trace des colonnes manquees. Sans cette variable, l'ancien code n'est jamais appele.

### T77 — ce qui change en jeu (dernier tick > 1 s)

* **`naturalize` ne gele plus** : elle etait la derniere passe monolithique (42 813 a 54 064 colonnes
  dans un seul tick) et **le LAGPROBE l'accusait a tort** : le log disait « periode de tick de
  1753 ms pendant la phase cleanupZone » alors que le travail etait dans naturalize. Les deux sont
  corriges : la passe est decoupee, et elle porte maintenant sa propre etiquette.
* **A verifier dans ton log** :
  * `naturalize (herbes, fleurs, champignons) X,Z : debut sur N colonnes (M tranches)` puis
    `fini (N colonnes, X ms)` -> la passe s'etalet, le jeu reste jouable.
  * `naturalize : N herbes, N fleurs, N champignons places (zone WxH)` -> le bilan de vegetation,
    inchange dans sa forme.
  * **Aucune ligne** `colonnes non traitees (chunk absent)` / `inaccessibles alors que la zone est
    complete` sur la passe naturalize : si tu en vois une, c'est que des colonnes n'ont pas ete
    vegetalisees (dis-le moi, le compteur est en place).
  * `[DLB-CLAMP] fenetre fermee ... pire XXXX ms` : le pire tick du pipeline. Ici : 12 979 ms dans
    ton log du 23/09 -> 1 257 ms.
  * Le detail du temps inclut maintenant `naturalize (herbes, fleurs, ...)` dans le
    `[DLB-PERF] TACHE COMPLETE` : tu vois sa part reelle (ici ~4,5 s etalees).
* **Ce qui reste** : quelques **colonnes isolees** lentes (`N colonne(s) lente(s) (> 50 ms chacune,
  pire XXX ms)`), qui sont atomiques (decodage/lumiere d'un chunk frais) et maintenant chiffrees.

---

## T78 -> T79 — l'eau est verifiee en 3 passes economisees, et plus aucun gel de 60 s

**Ce qui change pour toi, en jeu :**

- Les 4 passes de verification de l'eau (`fixWaterNearStructure`) s'arretent maintenant des que
  l'eau est **deja etalee** : au lieu de ~5 s par structure, c'est ~50 ms. Quand l'eau a
  vraiment besoin d'etre corrigee, les passes continuent de tourner normalement (rien ne change
  pour les cas difficiles) -- et le log te dit exactement ce qui a ete economise :
  `arret anticipe (3 passe(s) et 25 839 colonne(s) economisees, T78)`.
- **Tu ne verras plus le serveur mourir sur un blocage de 60 s.** Ce blocage (le watchdog
  `A single server tick took 60.02 seconds`, rencontre le 25/09 pendant le test) venait du
  **choix de zone** quand aucune zone plate valide n'est trouvee pres de toi (par exemple quand
  une structure vient d'etre posee sur toute la zone) : le programme mesurait alors des dizaines
  de milliers de colonnes dans des chunks qui n'etaient meme pas charges. Il ne mesure plus que
  les chunks deja charges, s'arrete au bout de 500 ms et te dit ce qu'il a fait :
  `[STRUCT5-FLAT] repli pente-minimale : 529 cellule(s) mesuree(s) en 0 ms, 1971 ignoree(s)
  (chunk non charge), 0 candidat(s)`.

**Resultat mesure (monde neuf, seed 1337, 25/09) :** observatory 24,6 s (pire tick 1322 ms),
dragon 33,1 s (**pire tick 621 ms, aucun tick > 1 s**), 0 exception. Les structures restent
**plantees dans le sol** (controle anti-vol : `dragon : controle anti-vol OK -- bas de
structure=37, sol reel median=72`).

**Ce qui reste a faire** (dit franchement) : le **/3 global** demande dans ton retour n'est pas
encore prouve. Le prochain poste identifie est la **repetition des memes passes lourdes** sur la
meme zone (`guardWaterEdges` 4x, `cleanupZone` 5x dans un seul pipeline) -- meme remede que T78 :
sortie anticipee quand la passe ne corrige plus rien. Le pre-chargement des chunks (29 a 41 % du
temps total) est non bloquant mais reste le plus gros poste.
