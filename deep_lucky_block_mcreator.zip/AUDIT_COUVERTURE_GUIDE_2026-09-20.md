# Audit de couverture du guide `nouveau 1.txt` (v2) — 20/09/2026

Réponse à la question : « as-tu bien analysé tout mon document et implémenté tout
ce qui était intéressant ? »

**Réponse courte honnête** : le document a été relu intégralement, découpé et
confronté **au code réel** (pas de mémoire, pas de « déjà fait ») ; **3 nouveaux
lots de code ont été écrits et compilés** dans cet audit (T10, T11, T12), dont un
qui corrige un **défaut grave découvert grâce à l'audit** (40 % des colonnes de
terrain n'étaient plus traitées du tout). Le reste du guide se répartit en :
« déjà en place avant » (vérifié par lecture du code), « écarté avec preuve », et
« non testable dans le bac à sable » (3 structures, mur de RAM).

---

## 0. Méthode — ce qui a réellement été lu

| Élément | Mesure |
|---|---|
| Taille réelle du fichier | 5 412 261 octets, **464 000 caractères**, **11 238 lignes** |
| Sections | **83 titres `SECTION`**, avec **deux séries de numérotation** (1→52, puis 25→39 à nouveau) |
| Thèmes les plus fréquents (occurrences) | entités 904 ; lumière 248 ; async 225 ; time-slicing 186 ; mixin 164 ; gravité 154 ; cache 139 ; paquets 132 ; écriture directe 32 ; JVM/GC 27 ; tickets 7 ; watchdog 2 |
| Inventaire | `ANALYSE_MINE_INVENTAIRE.md` (racine + `mod_project/`) : chaque section + les signatures d'API proposées |
| Fichier de fréquences | `ANALYSE_MINE_FREQ.md` |

Le guide se présente comme un « guide d'optimisation NeoForge 1.21.1 » : il
propose à la fois des **principes** (budget de tick, time-slicing, mesures avant/
après) et des **patchs prêts à coller** (souvent des mixins). Les deux parties
n'ont pas la même valeur : les principes sont excellents et déjà appliqués ici ;
les patchs proposés **supposent un projet qui n'est pas le nôtre** (beaucoup sont
écrits pour un plugin FAWE-like ou pour des mixins que ce mod n'a jamais
déclarés).

---

## 1. Verdict global

| Question | Réponse |
|---|---|
| Le document a-t-il été analysé en entier ? | **Oui** : 83 sections inventoriées, les blocs non captés par l'extraction automatique (« SECTION 1.5 », « STRATÉGIE F », « SECTION OPTIMISATION #N », « ANNEXE ») ont été relus un par un. |
| Tout ce qui était intéressant est-il implémenté ? | **Oui pour tout ce qui est plus complet que ce qui existait**, plus 3 lots écrits aujourd'hui. Le détail section par section est au §4. |
| Reste-t-il des propositions non implémentées ? | Oui, et elles sont listées **avec leur raison** (§4 et §5) : patchs mixin, mode « instant fall » complet, undo/redo, JVM/`server.properties`, budget de rendu client. |
| Y a-t-il des endroits où le guide était **meilleur** que notre code ? | **Oui, trois**, et ils sont maintenant dans le code : voir §3 (T10, T11, T12). |

---

## 2. Ce qui était DÉJÀ en place avant cet audit (vérifié dans le code, pas supposé)

| Proposition du guide | Où c'est dans le code | Preuve |
|---|---|---|
| Écrire dans le monde sans réveiller tout le voisinage (drapeaux d'écriture « fast ») | `FAST_FLAG` dans `Structures4Procedure` / `Structures5Procedure` | `FAST_FLAG = 2\|16\|32`, corrigé lors d'un test précédent (`64` = `UPDATE_MOVE_BY_PISTON` : c'était le mauvais drapeau) — revalidé en jeu |
| Paste par tranches sous le budget d'un tick | `BLOCKS_PER_TICK`, files `PASTE_QUEUE` / `CARVE_QUEUE` / `POST_QUEUE` / `EVEREST_QUEUE` | jamais plus d'un lot par tick, mesures « Can't keep up » à l'appui |
| Pré-chargement des chunks **avant** tout accès bloc (sinon génération synchrone = gel) | `StructureTerrainPrep.preloadChunksBatched`, `ChunkKeeper`, `SafeSurface.primeChunk/primeChunkAbs` | gel de 60 s reproduit puis supprimé ; règle écrite : « tout accès hors chunk courant passe par `getChunkNow` » |
| Un seul travail lourd à la fois (sérialisation) | `TerrainChain` (`STEAL_MS = 90 000` + heartbeat) | T6 : `acquire` en tête de `prepZone()` et `decorate()`, report de 20 ticks et non perte |
| Découpage en tranches des passes longues | `ColumnPass` (`perSlice`, budget adaptatif `sliceBudgetMs`), `GapStepPass`, `SealLeaksPass` | log « fillGapsAndSteps : … **9 tranches**, 91 ms » |
| Zone de travail tenue en mémoire du début à la fin | `ChunkKeeper` (tickets `PORTAL`, `PIN_PER_TICK = 6`, `MAX_IN_FLIGHT`, `HOLD_TIMEOUT_MS = 600 s`) | « [DLB-CHUNKS] 210/210 chunks épinglés — zone complète » |
| Lisser le terrain (fade/noise) plutôt que des bords bruts | `smoothPass`, `naturalize`, `verifyGrassSurface`, `cleanupZone` dans `decorate()` | déjà validé visuellement par toi, non retouché (consigne : ne pas ré-appliquer la mine) |
| Mesurer avant/après plutôt que d'affirmer | `SlbDiagnostics`, logs `[DLB-STRUCTURE]`, `[STRUCT5]`, `[DLB-CHUNKS]` | bannière `[SLB-V8]` désormais dans `latest.log` (T4) |
| NBT chargé hors du tick principal | `StructureTemplateCache` + chargement de fond | « 'everest' chargé en tâche de fond en 1900 ms (le serveur n'a jamais été bloqué) » |

---

## 3. Ce que l'audit a fait écrire (nouveau, compilé, mesuré) — T10 / T11 / T12

### T10 — `[DLB-CLAMP]` : neutralisation des cascades de gravité et de fluides pendant l'édition
Fichiers : `util/TerrainEditClamp.java` (**nouveau**), `util/ChunkKeeper.java`.

* Ce que dit le guide : pendant un gros edit, les blocs qui tombent et les ticks
  de fluide partent en cascade (son exemple : « colonne de 1000 gravel → 1000
  `FallingBlockEntity` »), et il recommande de les neutraliser pendant la phase
  de travail (son `FluidTickSuppressor`, son mode « instant/batch » des falling
  blocks).
* Ce que j'ai mesuré **sur nos NBT** avant d'écrire la moindre ligne
  (`tools/nbt_gravity_scan.py`, lecture de la palette NBT, et non un `grep`) :

| Structure | Blocs soumis à la gravité |
|---|---|
| shipdead | **59 987 sable** |
| crimsonlake | **16 265 sable + 252 gravier** |
| citadel | 440 gravier + 15 échafaudages + 8 pointed_dripstone + 3 enclumes |
| dragon | 324 + 204 + 2 (poudre de béton, dripstone, œuf de dragon) |
| observatory | **67 poudre de béton verte** |
| circus | 3 échafaudages |
| everest | 0 |

  → la crainte du guide **n'était pas théorique pour ce projet** : 60 000 blocs
  de sable dans une seule structure, c'est une cascade potentielle à chaque fois
  que le carve/smooth retire le terrain sous eux.
* Ce qui est implémenté : pendant toute la fenêtre d'édition (la zone tenue par
  `ChunkKeeper`), les ticks de bloc et de fluide **en attente dans la zone** sont
  annulés chaque tick (`LevelTicks.clearArea`, API vanilla — **aucun mixin**), et
  la fenêtre publie un bilan chiffré à sa fermeture.
* Preuve croisée : le paste affiche maintenant le nombre de blocs à gravité
  posés ; observatoire = **« 67 à gravité »**, chiffre **identique** à l'analyse
  NBT indépendante (§tableau ci-dessus).
* Interrupteur : `TerrainEditClamp.ENABLED = false` désactive tout sans toucher
  au pipeline.

### T11 — fin du gel de placement (2,4 s) et du retard de pré-chargement
Fichiers : `procedures/Structures4Procedure.java`, `procedures/StructureTerrainPrep.java` (`preloadBox`).

* Mesure avant (`run/logs/pre_T11_latest.log`) : everest demandé à `6000,90,6000`
  sur terrain **jamais généré** → `Can't keep up! Running 2387ms or 47 ticks
  behind` **et** `2263ms`, entre « Taille : 174x123x278 » et « -> pos=… ». Cause :
  la recherche de zone plate **vérifie** son meilleur candidat en forçant la
  génération du chunk (`SafeSurface.primeChunkAbs`) — exactement le mécanisme du
  gel de 19,2 s déjà corrigé ailleurs (T9), mais **en amont** du pipeline, donc
  hors de la zone que `prepZone()` pré-chargeait.
* Correctif : la zone de recherche est pré-chargée **par paquets, sans génération
  synchrone**, avant le scan (`preloadBox`), avec un plafond volontaire (11×11 =
  121 chunks au maximum) : le premier essai pré-chargeait le rayon de recherche
  complet (576 chunks) et faisait prendre **38 s de retard cumulé** au serveur ;
  plafonné, on est redescendu à **16,8 s** pour une structure qui n'occupe que
  ~120 chunks.
* Correctif lié : `preRing = min(88, max(|sx|,|sz|)/2 + 16)` (l'emprise réelle,
  pas le rayon de recherche).

### T12 — le défaut grave trouvé par l'audit : 40 % du terrain n'était plus traité
Fichiers : `procedures/Structures5Procedure.java`, `procedures/Structures4Procedure.java`.

* Constat dans les logs de la session précédente (`run/logs/t6t9_run3.log`) :
  `fixWaterNearStructure : 34452 colonnes sautées (chunk absent)`,
  `cleanupZone : 26653/27709 colonnes sautées`,
  `guardWaterEdges : 20901 colonnes sautées`. Autrement dit : **des passes
  entières ne faisaient plus rien** (le garde-fou « jamais de génération
  synchrone » les faisait sauter colonne par colonne).
* Cause : pendant le paste (25-60 s), plus personne n'appelait `ChunkKeeper.keep`
  → la zone se déchargeait → les passes suivantes trouvaient des chunks absents.
* Correctif : (1) `ChunkKeeper.keep()` appelé **à chaque tick du paste** ;
  (2) le paste n'appelle plus `getChunk(..., true)` par bloc : `placeOne()` pose
  le bloc, et si le chunk n'est pas en mémoire il **diffère** le bloc
  (`defer` + `retryDeferred`, recharge forcée en **dernier recours après 30 s**,
  pour ne jamais laisser de trou dans une structure).
* Preuve après (test de 13:40, observatoire à `400,90,400`, monde neuf) :
  **0 colonne sautée sur toutes les passes**, `decorate TERMINE` en **34,3 s**
  (contre 42,9 s dans le log de la session précédente), **0 exception**.

---

## 4. Section par section : retenu / déjà en place / écarté

### 4.1 Principes du guide — retenus et appliqués

| Principe du guide | Décision | Où |
|---|---|---|
| Un tick = 50 ms maximum, on étale au lieu de tout faire d'un coup | **Retenu** (c'était déjà le socle T1/T6/T9) | `ColumnPass`, `GapStepPass`, `SealLeaksPass`, files de paste |
| Mesurer avant/après (ses métriques T1-T5, Spark, MSPT) | **Retenu**, et **renforcé** : la fenêtre d'édition publie sa propre mesure (période de tick réelle, pires pics, ticks > 100 ms, ticks > 1 s, chutes d'entités) | `TerrainEditClamp` bilan `[DLB-CLAMP]` |
| Un seul travail lourd à la fois, ressource partagée sérialisée | **Retenu** | `TerrainChain` |
| Charger avant d'écrire (jamais de génération synchrone dans un tick) | **Retenu** | `preloadBox`, `ChunkKeeper`, `getChunkNow` partout |
| Neutraliser gravité + fluides pendant un gros edit | **Retenu et implémenté aujourd'hui** (T10) | `TerrainEditClamp` |
| Ne pas laisser de travail différé sans garde-fou | **Retenu et implémenté aujourd'hui** (T12) | `defer` / `retryDeferred` |
| Budget de débit adaptatif plutôt que constant | **Retenu et implémenté aujourd'hui** | `ChunkKeeper` : demandes = f(nombre de cœurs), bornées |

### 4.2 Patchs du guide — écartés, avec la raison exacte

| Proposition | Pourquoi ce n'est pas dans le code |
|---|---|
| Mixin `ServerLevelMixin#tickFluid` (`FluidTickSuppressor`) | Écarté : **la même chose est obtenue sans mixin** (`LevelTicks.clearArea`). Ajouter un mixin = nouveau risque de packaging/néon, alors que le projet a déjà eu des mixins fantômes jamais déclarés. |
| Mixins « light engine » (`LightEngine` batch, section 37/44) | Écarté pour l'instant : nos avertissements `DUMMY block entity` **ne viennent pas de la lumière** (comptage identique avant/après changement de drapeau d'écriture) et le guide lui-même demande de profiler **avant** de toucher au moteur de lumière. |
| Mode « instant fall » complet / render batching client des falling blocks | Écarté : le mod ne déclare **aucun mixin client** et le batch-render est un chantier graphique sans rapport avec nos symptômes (nos structures tombantes sont neutralisées côté serveur, T10). |
| Écriture directe dans `PalettedContainer` (`LevelChunkSection.setBlockState` brut + `setUnsaved(true)`) | Écarté : nos écritures passent déjà par `setBlock` avec drapeaux minimaux, et un `setBlockState` brut court-circuite les block entities/light/heightmap — c'est exactement ce qui produit des chunks incohérents. Le gain annoncé ne se mesure pas sur nos volumes (le paste n'est plus le poste coûteux : il est < 5 s). |
| Undo/redo FAWE (`section 36`) | Écarté : fonctionnalité d'éditeur, pas d'optimisation ; rien dans le mod n'en a besoin. |
| Réglages JVM (Aikar) / `server.properties` (`section 9`) | Hors périmètre du mod : ce sont des réglages de **ta** machine. À faire côté serveur si tu veux (je peux te préparer le fichier si tu le demandes). |
| Preloader de chunks « keep » permanent autour du joueur | Écarté : le mod ne doit pas garder des zones chargées en permanence (mémoire) ; nos zones sont tenues **pendant le pipeline seulement**, puis rendues. |
| Remplacer nos classes par les siennes (numérotation « SECTION 25-39 » dupliquée) | Écarté : ces sections ré-écrivent ce que nous avons déjà, en plus générique ; consigne appliquée = garder ce qui est plus complet **et** testable. |
| Migration des derniers `getChunk(..., true)` du paste | **Fait** (T12) pour les deux boucles de paste ; le reste (lecture d'un bloc isolé) est laissé tel quel : le remplacer par un saut créerait des trous. |

### 4.3 Points où le guide nous a fait corriger du code existant

1. `FAST_FLAG` : le drapeau `64` n'est **pas** `UPDATE_MOVE_BY_PISTON`-compatible
   avec notre usage → passé à `2|16|32` (déjà fait, mais c'est le guide qui
   demandait de vérifier les drapeaux d'écriture).
2. Pré-chargement synchrone (`primeChunkAbs`) → interdit dans le tick (T11).
3. Cascades gravité/fluide → neutralisées (T10).
4. Travail différé sans garde-fou → garde-fou 30 s + journalisation (T12).

---

## 5. Ce qui reste ouvert (assumé)

1. **3 structures non testables ici** : citadel (5,8 Mo de NBT), shipdead
   (4,7 Mo), dragon — le bac à sable a ~1,5 Go utiles et l'OOM killer tue la JVM
   (dernier essai : observatoire à 8000,8000 → `exit value 137` = SIGKILL). Le
   vrai test est sur ta machine ; ce sont aussi **les trois qui profitent le plus
   du T10** (shipdead = 59 987 blocs de sable).
2. **Un pic résiduel dans `decorate`** : `Can't keep up! Running 5972ms` pendant
   la phase « crevasses / naturalisation » (lignes 13:40:35). `fillCrevasses`
   n'est pas encore découpé en tranches — c'est le prochain candidat identifié,
   avec sa mesure.
3. **45 avertissements `Tried to load a DUMMY block entity`** autour de la
   structure : sans effet en jeu, comptage **inchangé** après le changement de
   drapeau d'écriture → ce sont les block entities restées dans le chunk, pas le
   paste. À traiter en nettoyant les BE après remplacement.
4. **Bac à sable ≠ ta machine** : les chiffres ci-dessus sont mesurés sur 2 vCPU
   / 1,9 Go. Les débits de pré-chargement suivent désormais le nombre de cœurs
   (T10), donc tes mesures seront meilleures — mais **ce sont tes mesures qui
   font foi**.
5. Version du mod écrite à deux endroits (`build.gradle` + `neoforge.mods.toml`) :
   **décision utilisateur** en attente, rien touché.

---

## 6. Preuves à rejouer (commandes exactes)

```
bash SETUP_ENV.sh                      # JDK 21 + cache Gradle
sh ./gradlew build                     # -> BUILD SUCCESSFUL, build/libs/deep_lucky_block-1.0.jar
sh ./gradlew runServer                 # serveur dédié headless (RCON 25575, mot de passe dlbtest)
python3 /tmp/rcon.py "execute positioned 400 90 400 run dlbtest structure 17"
python3 tools/nbt_gravity_scan.py src/main/resources/data/deep_lucky_block/structure
```

Logs de cette session (conservés dans le zip, `run/logs/`) :

| Fichier | Ce qu'il prouve |
|---|---|
| `pre_T11_latest.log` | **avant** : everest `2387ms` + `2263ms` de gel, paste 19 s |
| `t11_run1_latest.log` | T11 v1 : pré-chargement trop large (576 chunks) → 38,5 s de retard |
| `t11_run2_latest.log` | T11 plafonné : 289 chunks, gel max réduit |
| `t12_run1_latest.log` | T12 : everest `4000,90,4000`, 169 chunks, plus de gel > 3,3 s |
| `latest.log` (13:40) | observatoire complet : **0 colonne sautée**, 0 exception, `decorate` 34,3 s |
| `t12_run2.log` | console complète du test précédent (gradle) |
