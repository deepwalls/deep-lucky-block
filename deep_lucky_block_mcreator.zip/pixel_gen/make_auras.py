from PIL import Image
import os

OUT = "/home/user/mod_project/src/main/resources/assets/deep_lucky_block/textures/gui/hearts"

# 11x11 aura ring, drawn by hand at native pixel scale (1px border around the
# 9x9 heart). Not a gradient blur (would just be mush at this size) -- a
# clean pixelated "ring" of dots, like old JRPG status-icon auras.
SIZE = 11
RING = {
    (1,0),(3,0),(7,0),(9,0),
    (0,1),(10,1),
    (0,3),(10,3),
    (0,5),(10,5),
    (0,7),(10,7),
    (0,9),(10,9),
    (1,10),(3,10),(7,10),(9,10),
}

def build_ring(color):
    img = Image.new("RGBA", (SIZE, SIZE), (0,0,0,0))
    px = img.load()
    for (x,y) in RING:
        px[x,y] = color
    return img

# Cursed/unhealthy aura: sickly dark-green/purple flickering dots (reads as
# "wrong" / diseased at a glance, distinct from any positive glow).
build_ring((70, 20, 90, 230)).save(f"{OUT}/aura_cursed_a.png")
build_ring((40, 90, 40, 200)).save(f"{OUT}/aura_cursed_b.png")

# Radiant/positive aura for the Light heart: warm soft gold dots.
build_ring((255, 240, 190, 210)).save(f"{OUT}/aura_radiant_a.png")
build_ring((255, 210, 120, 180)).save(f"{OUT}/aura_radiant_b.png")

print("auras generated")
