import json, collections

CFG = "/home/user/mod_project/src/main/resources/config"

RARE_RANKS = ["RARE", "EPIC", "LEGENDARY", "MYTHIC", "RELIC", "MASTERWORK", "ETERNAL"]
VERY_RARE_RANKS = ["MYTHIC", "RELIC", "MASTERWORK", "ETERNAL"]

# (file, enchant id, ranks, category)
ENTRIES = [
    ("enchant_helmet.json", "ember_core", RARE_RANKS, "utility"),
    ("enchant_helmet.json", "radiant_ward", VERY_RARE_RANKS, "utility"),
    ("enchant_boots.json", "tidal_ward", RARE_RANKS, "utility"),
    ("enchant_boots.json", "gale_step", RARE_RANKS, "utility"),
    ("enchant_leggings.json", "stonebound_roots", RARE_RANKS, "utility"),
    ("enchant_leggings.json", "umbral_pact", VERY_RARE_RANKS, "utility"),
    ("enchant_chestplate.json", "heart_resonance", VERY_RARE_RANKS, "utility"),
    ("enchant_sword.json", "overcharge", RARE_RANKS, "offensive"),
    ("enchant_axe.json", "overcharge", RARE_RANKS, "offensive"),
]

by_file = collections.defaultdict(list)
for f, eid, ranks, cat in ENTRIES:
    by_file[f].append((eid, ranks, cat))

for fname, items in by_file.items():
    path = f"{CFG}/{fname}"
    d = json.load(open(path), object_pairs_hook=collections.OrderedDict)
    for eid, ranks, cat in items:
        full_id = f"deep_lucky_block:{eid}"
        for rank in ranks:
            pool = d['rank_pools'][rank]
            lst = pool.setdefault(cat, [])
            if full_id not in lst:
                lst.append(full_id)
    with open(path, 'w') as fh:
        json.dump(d, fh, indent=2, ensure_ascii=False)
        fh.write('\n')
    print("updated", fname)
