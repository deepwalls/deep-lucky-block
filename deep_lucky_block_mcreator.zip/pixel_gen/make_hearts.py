from PIL import Image
import os

OUT = "/home/user/mod_project/src/main/resources/assets/deep_lucky_block/textures/gui/hearts"
os.makedirs(OUT, exist_ok=True)

# 9x9 native vanilla-scale heart mask, hand-authored pixel by pixel (no AI
# upscale) to match real vanilla heart proportions exactly.
MASK = [
    "TKKTTTKKT",
    "KFFKTKFFK",
    "KFSFFFSFK",
    "KFFFFFFFK",
    "KFFFFFFFK",
    "TKFFFFFKT",
    "TTKFFFKTT",
    "TTTKFKTTT",
    "TTTTKTTTT",
]
W, H = 9, 9
assert len(MASK) == H and all(len(r) == W for r in MASK)

BLACK = (10, 10, 10, 255)
EMPTY_FILL = (58, 58, 58, 255)
EMPTY_SHADOW = (36, 36, 36, 255)

# Per-element palettes: (main fill, shadow accent). Only 2 flat tones + black
# outline on purpose: at 9px tall extra gradients just turn into mush, so
# every element must read as a clean silhouette from HUD distance.
# NOTE electric: purple accent swapped for a near-white "spark" so the bolt
# actually pops against the yellow instead of blending into a muddy crack.
PALETTES = {
    "fire":     ((255, 106, 0, 255),  (168, 32, 0, 255)),
    "water":    ((60, 150, 255, 255), (20, 70, 170, 255)),
    "earth":    ((104, 170, 64, 255), (66, 110, 40, 255)),
    "wind":     ((210, 250, 250, 255),(130, 200, 200, 255)),
    "electric": ((255, 214, 0, 255),  (255, 255, 255, 255)),
    "shadow":   ((150, 60, 200, 255), (35, 8, 55, 255)),
    "light":    ((255, 250, 210, 255),(255, 190, 60, 255)),
}

# HIT flash palettes: when the element heart takes damage it should NOT just
# reuse vanilla's plain white flash -- give every element its own "hit" tint
# so bonus hearts are readable as reacting distinctly (fire flashes white-hot,
# water flashes pale foam, electric flashes pure white/blue spark, shadow
# flashes a sickly green-white "pain" flare, etc.).
HIT_PALETTES = {
    "fire":     ((255, 255, 255, 255), (255, 220, 120, 255)),
    "water":    ((235, 250, 255, 255), (170, 220, 255, 255)),
    "earth":    ((235, 255, 210, 255), (180, 220, 140, 255)),
    "wind":     ((255, 255, 255, 255), (210, 245, 245, 255)),
    "electric": ((255, 255, 255, 255), (140, 200, 255, 255)),
    "shadow":   ((225, 255, 210, 255), (110, 200, 90, 255)),  # sickly cursed flash
    "light":    ((255, 255, 255, 255), (255, 240, 180, 255)),
}

def build(mask, main, shadow):
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    px = img.load()
    for y, row in enumerate(mask):
        for x, c in enumerate(row):
            if c == 'T':
                px[x, y] = (0, 0, 0, 0)
            elif c == 'K':
                px[x, y] = BLACK
            elif c == 'F':
                px[x, y] = main
            elif c == 'S':
                px[x, y] = shadow
    return img

def make_half(mask, main, shadow):
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    px = img.load()
    for y, row in enumerate(mask):
        for x, c in enumerate(row):
            if c == 'T':
                px[x, y] = (0, 0, 0, 0)
            elif c == 'K':
                px[x, y] = BLACK
            elif c in ('F', 'S'):
                if x <= 3:
                    px[x, y] = main if c == 'F' else shadow
                else:
                    px[x, y] = EMPTY_FILL if c == 'F' else EMPTY_SHADOW
    return img

empty_img = build(MASK, EMPTY_FILL, EMPTY_SHADOW)

for elem, (main, shadow) in PALETTES.items():
    build(MASK, main, shadow).save(f"{OUT}/heart_{elem}_full.png")
    make_half(MASK, main, shadow).save(f"{OUT}/heart_{elem}_half.png")
    empty_img.save(f"{OUT}/heart_{elem}_empty.png")
    hmain, hshadow = HIT_PALETTES[elem]
    build(MASK, hmain, hshadow).save(f"{OUT}/heart_{elem}_hit.png")

print("Generated", len(PALETTES) * 4, "heart textures at", W, "x", H)
