# À COMMITTER / À POUSSER — session du 20/09/2026 (T4 + T6 + T9)

## ⚠️ Le dépôt Git local a disparu

Le bac à sable a été réinitialisé entre deux messages et **`.git/` n'a pas
survécu** (`ls -la /home/user/projet` : aucun `.git`, `git status` →
« not a git repository »). Les commits précédents (`0546ef4`, `928cb68`,
`95e3310`, `922bb56`) sont donc introuvables **de mon côté** — s'ils ont été
poussés sur ton dépôt, ils sont évidemment toujours là chez toi.

Conséquence : **je ne peux pas créer de commit dans cet environnement**. À la
place, voici la liste exacte de ce qui a changé, avec le message de commit à
utiliser pour chaque tâche (un commit par tâche, comme convenu).

---

## Ce qui a changé (chemins depuis la racine du dépôt)

### 1) Cause racine du GEL — `mod_project/src/main/java/deepluckyblock/procedures/SanctuarySpawnerEquipProcedure.java`

- Les deux scans de spawners (`findNearestSpawner`, `onPlayerTick`) balayaient
  **29 791 positions** avec `getBlockState()`, qui **force la génération du
  chunk** s'il n'est pas en mémoire → génération synchrone sur le thread
  principal depuis un événement `EntityJoinLevelEvent` → **tick de 60 s et
  Watchdog** (prouvé par la pile d'appels du crash-report du 20/09).
- Remplacés par `forEachCandidate(...)` : chunks lus via `getChunkNow` (jamais
  de génération), sections 16³ vides sautées, compteur de contrôle dans le log.

**Message de commit :**
`T9: cause racine du freeze - scans de spawners sans generation de chunk forcee`

### 2) T9 — zone tenue en mémoire + pré-chargement non bloquant

- **Nouveau** `mod_project/src/main/java/deepluckyblock/util/ChunkKeeper.java`
  (tickets `TicketType.PORTAL` progressifs, maintien pendant tout le pipeline,
  renouvellement autonome, garde-fou 10 min, `zoneComplete`).
- **Nouveau** `mod_project/src/main/java/deepluckyblock/util/TerrainChain.java`
  (une seule chaîne terrain à la fois, reprise de force après 90 s).
- `StructureTerrainPrep.java` : `preloadStep` non bloquant (fin des
  `getChunk(..., requireChunk=true)`), budget de tranche adaptatif au MSPT,
  garde de zone avant les phases lourdes, `sliceBudgetMs()`.
- `Structures4Procedure.java` / `Structures5Procedure.java` +
  `StructureTerrainPrep.java` : `FAST_FLAG` `2|16|64` → `2|16|32`
  (`64` = `UPDATE_MOVE_BY_PISTON`, drapeau de déplacement par piston, et non
  « supprime les drops » : vérifié via `javap` sur `Block.class`).

**Message de commit :**
`T9: zone tenue en memoire, preload non bloquant, budget adaptatif, FAST_FLAG corrige`

### 3) T6 — passes terrain sérialisées et découpées

- `StructureTerrainPrep.java` : `fillGapsAndSteps` → `GapStepPass` (heightmap
  par bandes de 4096 colonnes, balayage par tranches de 8 ms),
  `sealWaterLeaks` → `SealLeaksPass` (repérage / barrage / vidange découpés,
  `fixWaterNearStructure` en continuation), `decorate()` rebranché sans changer
  l'ordre des opérations.

**Message de commit :**
`T6: passes terrain serielles et decoupees (fin des ticks geants)`

### 4) T4 — documentation alignée sur le code

- `LIRE-MOI-IMPORTANT.md` : « Prepared 7 mixins » remplacé par les valeurs
  réelles et vérifiables ; liste des 6 classes mixin non déclarées (inertes) ;
  note sur le bandeau `[SLB-V8]`.
- `README-INSTALL.txt` : config de mixins réellement déclarée (`JAVA_21`),
  fichier `deepluckyblock.mixins.json` (`JAVA_17`) **non déclaré donc inerte**.
- `SlbDiagnostics.java` : les 10 `System.out.println` passent par le logger du
  mod → `[SLB-V8]` apparaît **enfin dans `logs/latest.log`**.
- `StructureTerrainPrep.java` : `SMOOTH_PASSES` (morte) annotée `@Deprecated`
  avec renvoi vers `decorate()` (50 puis 12 passes, deux fois).
- **Nouveau** `DOC_ALIGNEMENT_T4_2026-09-20.md` : les 7 points du §7 de
  `RAPPORT_ETAPE0.md`, chacun avec état trouvé → correction → preuve.

**Message de commit :**
`T4: doc alignee sur le code (mixins, banniere, smooth, kits, version)`

### 5) Livrables / preuves

- `CHANGELOG.md` : sections **T6**, **T9** (dont la cause racine du gel et le
  tri retenu/écarté du guide externe), **T4**, et « Reste à faire » mis à jour
  (482 lignes au total ; copie racine synchronisée).
- **Nouveau** `TEST_T6_T9_T4_2026-09-20.log` : protocole + extraits de log du
  test en jeu (117 lignes).
- `deep_lucky_block_mcreator_project.zip` régénéré (18 139 179 octets, 1 631
  fichiers, `build/` et monde exclus, `run/logs` conservés comme traces).

---

## Contrôles à relancer chez toi (les miens sont dans le zip)

1. `sh ./gradlew build` → **BUILD SUCCESSFUL in 8s**, jar
   `build/libs/deep_lucky_block-1.0.jar` (8 810 043 octets, 1 490 entrées).
2. En jeu : casser des lucky blocks `luck=100` et vérifier le spawn. Ce que
   j'ai validé ici (serveur dédié headless, seed 1337, monde neuf) :
   - **everest** à `6000,90,6000` : « EVEREST TERMINÉ en 20.796s (52979 blocs) »,
     **plus de Watchdog** (ce scénario tuait le serveur avant).
   - **observatory** à `400,90,400` : `prepZone 9/11 TERMINE` (22,2 s),
     `decorate TERMINE` (33,6 s), `fillGapsAndSteps` en **9 tranches**,
     `sealWaterLeaks` en 1 itération, **0 colonne sautée**, 0 exception.
3. Ce que je n'ai **pas pu** tester ici : citadel, shipdead, dragon (mur RAM du
   bac à sable : ~1,19 Go utiles, l'OOM killer tue la JVM). Ces trois-là restent
   à valider sur ta machine — c'est le seul point de la liste « terminé » que je
   ne peux pas cocher moi-même.

## Points ouverts (assumés, documentés)

- **29 avertissements** `Tried to load a DUMMY block entity … minecraft:air`
  autour de la structure : comptage **identique avant/après** le changement de
  `FAST_FLAG`, donc ils ne viennent pas des drapeaux d'écriture. Sans effet en
  jeu (le bloc fantôme est ignoré), à traiter proprement plus tard.
- **Version du mod écrite à deux endroits** (`build.gradle` et
  `neoforge.mods.toml`, toutes deux `1.0`) : je n'ai **rien touché**
  (`gradle.properties` interdite sans ton accord). Dis-moi si tu veux que
  `gradle.properties` devienne la source unique.


---

# Ajout du 20/09 (2e vague) — T10 / T11 / T12

Le dépôt local de travail n'existe plus dans le bac à sable (`.git` absent :
`git status` → « not a git repository »). Les commits ci-dessous sont donc à
appliquer **depuis ta machine**, après avoir téléchargé le workspace (panneau
Workspace → Download) puis copié le contenu dans ton dépôt.

**1) `T10: neutralise les cascades (gravite + fluides) pendant l'edition + garde anti double-paste`**
- `procedures/StructureTerrainPrep.java`
- `procedures/Structures4Procedure.java`
- `procedures/Structures5Procedure.java`
- `util/ChunkKeeper.java`
- `util/TerrainEditClamp.java` *(nouveau)*
- `tools/nbt_gravity_scan.py` *(nouveau — analyse des blocs à gravité des NBT)*

**2) `T11: pre-charge la zone de recherche avant le scan (fin du gel de 2,4 s)`**
- `procedures/Structures4Procedure.java`
- `procedures/StructureTerrainPrep.java` *(méthode `preloadBox`)*

**3) `T12: garde la zone tenue pendant le paste (fin des colonnes sautees)`**
- `procedures/Structures5Procedure.java` *(`placeOne`, `retryDeferred`)*
- `procedures/Structures4Procedure.java` *(`placeOne`, `retryDeferred`)*
- `util/ChunkKeeper.java` *(débit adaptatif au nombre de cœurs)*
- `util/TerrainEditClamp.java` *(mesure honnête : période de tick réelle)*

**Documentation** (même commit ou commit séparé, au choix) :
- `CHANGELOG.md` (T10/T11/T12 + reste à faire)
- `AUDIT_COUVERTURE_GUIDE_2026-09-20.md` *(nouveau — réponse à « tout est-il implémenté ? »)*
- `COMMITS_A_APPLIQUER_2026-09-20.md` (ce fichier)

**Contrôle après application :**
```
sh ./gradlew build     # doit finir en BUILD SUCCESSFUL
```
Jar produit ici : `build/libs/deep_lucky_block-1.0.jar` (8 817 414 octets, 20/09 13:41).

---

# Lots T13 → T18 (revue étape par étape du guide) — 20/09/2026, à partir de 14:33

> Rappel : `.git` n'existe pas dans cet espace de travail (le dépôt est chez toi).
> Une tâche = un commit, message en français. Ordre conseillé : T13 → T18.
> Build de contrôle après CHAQUE commit :
> `sh ./gradlew build` (doit finir en `BUILD SUCCESSFUL`), jar attendu
> `build/libs/deep_lucky_block-1.0.jar` — **8 834 151 octets (20/09 14:33)**.

## Commit — T13 : water dam sans blocs (gel/dégel de l'eau, guide S.27)

**Fichiers**
- `src/main/java/deepluckyblock/util/WaterDam.java` *(nouveau : gel, dégel
  intelligent, `isFrozen`, `frozenCount`, compteurs restored/moved/dropped/skipped,
  tranches 192 colonnes / budget 8 ms, FAST_FLAG local)*
- `src/main/java/deepluckyblock/procedures/StructureTerrainPrep.java`
  *(gel au step 0/11 `prepZone`, après le pré-chargement, avant `scanTrees` ;
  dégel à la fin de `decorate`, après `cleanupZone`, avant les `release`)*

**Message de commit**
```
T13 : water dam sans blocs -- gel et degel intelligent de l'eau (guide S.27)

- retire l'eau de la zone avant tout acces terrain et memorise son etat exact
  (aucun bloc de barrage : les anciennes spheres de placeWaterDams rendaient mal
  et la fonction etait desactivee, donc plus rien ne traitait l'eau)
- degel en fin de decorate : source restituee comme source si elle l'etait,
  sinon descente au nouveau sol ; emprise de la structure exclue (eau du NBT)
- degel effectue fenetre DLB-CLAMP ouverte : aucune cascade possible
- preuve en jeu : 34842 blocs geles sur 30589 colonnes (1,06 s) puis
  13146 remis + 16420 deplaces + 10 abandonnes + 0 ignore ;
  test isole verifie par execute if block (eau -> air -> eau au meme endroit)
```

## Commit — T14 : paste ordonné par sections 16³ en spirale (guide S.42/S.43)

**Fichiers**
- `Structures4Procedure.java` *(`orderBySectionSpiral`, remplace `orderByY` dans
  `doPaste` ; `orderByY` conservé)*
- `Structures5Procedure.java` *(`orderBySectionSpiral` sur le filtre de pose)*
- les deux `PasteJob.placeOne()` *(cache de chunk par section : `lastCx/lastCz/lastLoaded`)*

**Message de commit**
```
T14 : paste ordonne par sections 16^3 en spirale + cache de chunk par section

- cle de tri : section 16^3 -> distance^2 au centre (spirale) -> Y intra-section
- le chunk n'est resolu qu'une fois par section (au lieu d'une fois par bloc)
- orderByY conserve dans le code (non appele) pour retour arriere en une ligne
- preuve en jeu : everest 52979 blocs en 32,071 s, post-traitement inclus
```

## Commit — T15 : plafond du repli forcé du pré-chargement (guide S.6/S.30)

**Fichiers** : `StructureTerrainPrep.java`

**Message de commit**
```
T15 : borne le repli force du pre-chargement a 2 generations par tick

- cause du dernier gel : jusqu'a 4 generations de chunk SYNCHRONES dans un meme
  tick -> chien de garde du jeu ("single tick took 60.08 s") pendant le
  pre-chargement d'un monde neuf
- seuil de repli porte a 600 ticks + log dedie
- preuve en jeu : pre-chargement de 169 chunks termine sans mort par watchdog,
  pipeline complet sur monde neuf qui va au bout (42,0 s)
```

## Commit — T16 : fil rouge de phase, sonde de tick, porte de stabilisation

**Fichiers**
- `util/DebugLog.java` *(`setPhase` / `phaseNow`)*
- `util/TerrainEditClamp.java` *(`[DLB-LAGPROBE]`, seuil 1 500 ms)*
- `util/SettleGate.java` *(nouveau : porte de stabilisation de fin de pipeline)*
- `StructureTerrainPrep.java` *(`step()` : durée réelle entre étapes + fil rouge ;
  avancement des tranches ; `SettleGate.wait` avant les `release`)*

**Message de commit**
```
T16 : instrumentation honnete du pipeline + porte de stabilisation

- [DLB-LAGPROBE] nomme la phase en cours des qu'une periode de tick depasse
  1500 ms (c'est cette sonde qui a identifie le pre-chargement -> T15)
- [DLB-STRUCTURE] "l'etape qui vient de finir a pris N ms de temps REEL"
- fil rouge de phase alimente par step() et par chaque tranche des boucles
- SettleGate : la zone n'est rendue au chunk system qu'une fois les entites de
  chute retombees et le moteur de lumiere au repos (plafond 200 ticks, logge)
- preuve en jeu : chronologie complete de prepZone a decorate TERMINE (42,0 s)
  + "zone stabilisee apres 2 tick(s) d'attente (0.1 s)"
```

## Commit — T17 : commandes de pilotage de l'eau (guide S.39)

**Fichiers** : `commands/DlbTestCommands.java`

**Message de commit**
```
T17 : /dlbtest water freeze|thaw|status (guide S.39 : /opti freeze, /opti unfreeze)

- permet de verifier le water dam a la demande, sans attendre une structure
- preuve : freeze -> status (gel ACTIF, 8257 blocs) -> thaw -> status (0 bloc)
```

## Commit — T18 : repli forcé piloté par le budget de tick

**Fichiers** : `StructureTerrainPrep.java`

**Message de commit**
```
T18 : le budget de tick pilote le repli force du pre-chargement (mesure T16)

- sonde : 3791 ms pour 2 generations sur ce serveur de test (2 vCPU), soit ~1,9 s
  par chunk en monde neuf -> le compteur seul (T15) ne suffit pas
- PRELOAD_FORCE_BUDGET_MS = 900 : si deux generations depassent le budget du
  tick, le repli s'arrete (la generation en tache de fond continue)
- sur machine de bureau (~100-200 ms par chunk) le comportement reste celui de T15
```

## Documentation (commits séparés possibles)

- `CHANGELOG.md` (T13 → T18 + bilan)
- `REVUE_ETAPE_PAR_ETAPE_2026-09-20.md` *(nouveau : les 83 sections, étape par étape)*
- `TEST_T13_T16_2026-09-20.log` *(preuve brute du run de validation)*
- `COMMITS_A_APPLIQUER_2026-09-20.md` (ce fichier)

---

# Lots T19 → T21 — défauts constatés dans le log client du 20/09 au soir (17:03→17:29)

> Preuve : `LOG_CLIENT_20SEP_SOIR.log` (log client fourni, 12 060 lignes) + 12 captures.
> Build de contrôle : `sh ./gradlew build` → `BUILD SUCCESSFUL`,
> jar `build/libs/deep_lucky_block-1.0.jar` — **8 836 120 octets (21/09 17:27)**.

## Commit — T19 : water dam complet + dégel exact (fin des murs d'eau)

**Fichiers** : `util/WaterDam.java`

```
T19 : le water dam gele toute la zone et le degel restitue l'etat EXACT

- plafond de 60000 blocs atteint en jeu ("eau gelee : 60000 blocs sur 14463
  colonnes") : 16126 colonnes d'eau n'etaient JAMAIS gelees et ont ete
  traversees par le remodelage -> plafond porte a 1 000 000 (12 Mo transitoires)
- le degel promouvait en SOURCE toute case dont le bloc du dessous etait plein
  (une source ne s'ecoule jamais -> murs d'eau verticaux) et deplacait l'eau au
  "nouveau sol" (40520 blocs reconstruits dans un run) : remplace par une
  restitution EXACTE (etat d'origine, position d'origine), les niveaux d'eau
  d'origine se stabilisent seuls
- preuve : "degel termine : 29975 blocs restitues a leur position EXACTE,
  0 recouverts, 4867 ignores (emprise)" (contre 14871 remis + 40520 deplaces)
```

## Commit — T20 : les colonnes d'eau ne participent plus au lissage

**Fichiers** : `util/WaterDam.java` (masque `frozenColumn`), `StructureTerrainPrep.java`

```
T20 : exclut les colonnes d'eau du lissage (le rivage n'est plus creuse)

- le gel precedant le lissage, la heightmap voyait le FOND de l'ocean a la place
  de sa surface : "ecart de sol avant/apres smooth = -20 blocs (63 -> 43)"
  (dragon) et "sol de l'emprise irregulier apres smooth (median=49 contre 63)"
  (observatory) -> crateres plats, falaises vives, rivages creuses
- les colonnes gelee sont desormais exclues du calcul de flou : hauteur d'eau
  conservee, ni flou ni reconstruction
- preuve : "smooth 181x169 : 6279 colonnes d'eau exclues du lissage"
```

## Commit — T21 : garde-fou d'amplitude du lissage + mesure finale du terrain

**Fichiers** : `StructureTerrainPrep.java`

```
T21 : borne la variation du lissage a 8 blocs du terrain naturel + mesure finale

- mesure nouvelle : "lissage : derive maximale 36 / 58 / 60 blocs" -- le flou
  (7x7 x50 puis 15x15 x12, en prep ET en decorate) pouvait recreuser le paysage
  de plusieurs dizaines de blocs, sans aucun garde-fou
- reference "terrain naturel" memorisee une fois par zone : toutes les passes de
  lissage restent a <= 8 blocs de cette reference (emprise de la structure et
  plans d'eau exceptes : l'aplanissement voulu sous le batiment reste libre)
- mesure finale publiee par structure : "terrain final vs terrain NATUREL :
  ecart moyen 5.82 blocs, maximal 56, 31 % des colonnes a 2 blocs ou moins"
- preuve : pipeline complet en 48.8 s sur monde neuf, aucune mort par watchdog
```

## Commit — T22 : dégel auto-étranglé + étiquetage des phases

**Fichiers** : `util/WaterDam.java`, `procedures/StructureTerrainPrep.java`

```
T22 : le gel/degel de l'eau s'auto-etrangle et toutes les phases sont etiquetees

- mesure en jeu : 2e structure sur un monde deja retaille -> ticks de 13004 /
  12909 / 13625 ms sous un libelle PERIME ("cleanupZone 29568/30589"), puis
  Watchdog "A single server tick took 60.20 seconds" ; la vraie phase etait le
  degel (33551 blocs d'eau reposes, chaque setBlock d'eau verifie la lumiere)
- etiquetage : "gel de l'eau i/N", "degel de l'eau i/N (etrangle xN)",
  "stabilisation puis relachement des chunks" -> [DLB-LAGPROBE] nomme la vraie
  phase des la prochaine mesure
- auto-etranglement : si l'ecart reel entre deux tranches depasse 200 ms, la
  tranche suivante est reportee de 1 a 10 ticks (WARN explicite) ; tranches
  4000 -> 2000 blocs, budget 8 -> 4 ms
- preuve : meme commande sur monde neuf -> degel exact (29108 restitues,
  0 recouverts), pipeline complet en 40,4 s, aucune mort par watchdog
```

## Commit — T23 : eau intacte, lissage asymétrique, végétaux flottants

**Fichiers** : `util/WaterDam.java`, `procedures/StructureTerrainPrep.java`,
`procedures/Structures4Procedure.java`

```
T23 : reponse aux remarques du joueur -- l'eau n'est plus touchee, plus de crateres

1) EAU : le gel et le degel ne sont plus appeles par le pipeline (retirer puis
   reposer 34 000 blocs laissait des murs et des blocs figes). Le relief est
   retravaille AUTOUR des plans d'eau, exclus du lissage (T20). WaterDam reste
   disponible pour /dlbtest water.
2) LISSAGE ASYMETRIQUE : +10 blocs de remblai maximum, -2 blocs de creusage
   maximum par rapport au terrain NATUREL de reference (mesure : le flou
   derivait jusqu'a 60 blocs, -20 blocs constates sur le rivage). Resultat :
   ecart moyen 2.34 blocs et 85 % des colonnes a <= 2 blocs (avant 5.86 / 32 %).
3) VEGETAUX FLOTTANTS : nouvelle passe sweepFloatingDecor (cacao, vignes,
   bamboos, feuilles orphelines) avant les finitions -> 11 041 blocs retires.
4) STRUCTURES A TERRAIN DESACTIVE (circus, shipdead) : nettoyage de la vegetation
   dans un rayon de 3 blocs autour de chaque bloc de la structure, desormais
   execute meme dans ce mode.
5) Mesure finale publiee : "terrain final vs terrain NATUREL ... dont N CREUSEE(S)
   (pire : -X) et M REMBLAYEE(S) (pire : +Y)".

Preuve : TEST_T23_2026-09-21.log -- pipeline complet en 33,5 s, 0 ligne DLB-WATER,
0 exception, aucune mort par watchdog. Build BUILD SUCCESSFUL, jar 8 838 342 o.

## Commit — T24 : limitation de pente (fin des terrasses autour des structures)

**Fichiers** : `procedures/StructureTerrainPrep.java`

```
T24 : borne la pente du terrain reconstruit -- fin des escaliers de terre

- constat sur les captures du 20/09 : des escaliers concentriques (amphitheatre)
  autour des structures ; cause : rebuildColumn coupait chaque colonne a SA hauteur,
  deux colonnes voisines pouvaient differer de 10 a 56 blocs -> parois verticales
- nouvelle passe limitSlope : relaxation sur les 4 voisins, 2 blocs maximum entre
  colonnes voisines, 14 iterations ; emprise de la structure et plans d'eau exclus
  (le plateau du batiment est volontaire) ; re-application de la fenetre du lissage
- metrique : plus grand ecart entre colonnes voisines, lue AVANT et APRES limitation
- preuve : "pentes : ... ramene de 11 bloc(s) a 25 (limite 2)" -- 11 hors emprise
  (56 auparavant), ~5000 cellules adoucies par passe
```

## Commit — T25 : débris de terrain flottants + emprise intouchable

**Fichiers** : `procedures/StructureTerrainPrep.java`

```
T25 : retire les debris meubles flottants (herbe, terre, sable) et protege l'emprise

- les captures montrent des ilots d'herbe et des blocs de terre suspendus dans le
  vide ; le balayage T23 ne traitait que le vegetal et s'arretait a +24 blocs
- desormais : materiaux meubles flottants retires (grass, dirt, sand, gravel, snow,
  clay, mud, moss...), jamais la pierre/les minerais/les terracottas (surplomb
  rocheux = relief legitime) ; scan porte a +48 blocs ; emprise de la structure
  totalement exclue du balayage
- bilan : ecart moyen au terrain naturel 2.45 blocs et 89 % des colonnes a <= 2 blocs
  (debut de session : 5.86 et 32 %) ; pipeline complet en 34.0 s, 0 ligne DLB-WATER
```

## Commits de la passe T26 → T31 (21/09 soir) — numérotation continue

| T | Message de commit |
|---|---|
| T26 | `T26: terrain rendu definitif AVANT le paste (fin des lissages post-paste qui recreusaient le pourtour)` |
| T27 | `T27: registre d'emprises (StructureSites) -- une structure ne se pose plus dans une autre` |
| T28 | `T28: everest enfonce de 6 blocs dans le terrain + emprise enregistree` |
| T29 | `T29: garde-fou d'emprise au point de passage commun (freeOffset) -- couvre les chemins de repli` |
| T30 | `T30: everest -- prechargement de l'emprise finale avant la pose (fin du tick de 10,4 s)` |
| T31 | `T31: ligne « Incassable » dans la description du Bo Cube De Bois (fr + en)` |
| docs | `docs: audit exhaustif des 53 commentaires <Dev> et numerotation continue T0-T31` |

## Suite (22/09)

| T | Message de commit |
|---|---|
| T28 (maj) | `T28: everest -- enfoncement porte a 10 blocs (choix utilisateur du 22/09)` |
| T32 | `T32: everest -- boite de pre-chargement dimensionnee sur l'emprise reelle (88 -> 164 blocs)` |

Rappel : une tâche = un commit, message en français.


---

## T33 — « Gel de la pose de l'everest supprimé, sélection de zone plate réparée, berges d'eau et passe finale de terrain »

**Fichiers** : `src/main/java/deepluckyblock/procedures/Structures4Procedure.java`,
`src/main/java/deepluckyblock/procedures/Structures5Procedure.java`,
`src/main/java/deepluckyblock/procedures/StructureTerrainPrep.java`

```
T33 : fin du gel pendant la pose d'une structure (everest 61 s -> 15,7 s au run de validation)

- EverestJob : plus AUCUNE generation de chunk synchrone (getChunk(..., true) etait appele
  AVANT CHAQUE BLOC : 644 demandes de chargement dans le tick, 36 824 ms de gel en jeu).
  Le chunk est demande en tache de fond et, s'il n'est pas pret, le bloc est mis de cote
  (defer) puis repose par retryDeferredEverest() -- mecanique T12 portee sur l'everest.
- Budgets de TEMPS par tick (PASTE_TICK_BUDGET_MS = 40 ms) dans les boucles de pose S4/S5 :
  25 000 blocs/tick ne bornent rien en temps reel. EVEREST_TICK_TIMEOUT_MS 300 -> 90 ms.
- Prechargement : « termine » exige desormais le statut COMPLET de tous les chunks
  (getChunkNow) et non le simple isLoaded (PRELOAD_VERIFY_EXTRA_TICKS = 200, non bloquant).
- Selecteur de zone plate : un chevauchement d'emprise DECALE le candidat (StructureSites.freeOffset)
  au lieu de le rejeter (les centaines de REJETE vidaient la liste et forçaient le repli
  « le moins pentu ») ; 12 -> 24 candidats verifies.
- Berges d'eau : empreinte en losange (sphere/axium), +1/-1 bloc par anneau (eau + 3 puis + 2),
  verification de fuite apres pose et 2 renforcements possibles (BANK_RETRIES).
- Passe finale de terrain : vue de haut chunk par chunk puis globale, sur le terrain SOL
  uniquement, cuvettes comblees / saillies rabotees avec un ecart maximal de 2 blocs dans un
  rayon de 6 autour du bati, apres l'eau et les berges (la toute derniere du pipeline).
  Budgets 120 ms (analyse) / 150 ms (correction) : jamais de gel, arret propre et logue.

Preuves (sandbox) : EVEREST TERMINE en 15.754s, 7004 blocs reposes sur 2 ticks, 0 tick > 1 s
pendant la pose ; passe finale 61 colonnes retouchees (39 cuvettes / 22 saillies) ;
observatory decorate 14,9 s avec pire tick 373 ms et 0 tick > 1 s.
```

## T34 — « Budget de temps des passes de rattrapage + vérification du pré-chargement + passe finale utilisable »

**Fichiers** : `src/main/java/deepluckyblock/procedures/Structures4Procedure.java`,
`src/main/java/deepluckyblock/procedures/Structures5Procedure.java`,
`src/main/java/deepluckyblock/procedures/StructureTerrainPrep.java`

```
T34 : correctifs des points chauds reveles par le premier run de validation T33

- Les passes de rattrapage (retryDeferred S4/S5 et retryDeferredEverest) reposaient TOUS les
  blocs differes dans le MEME tick : mesure 7 838 ms de gel (6757 blocs en 1 tick). Elles
  respectent desormais PASTE_TICK_BUDGET_MS (40 ms) et reprennent au tick suivant.
- La passe finale ne corrigeait RIEN : isProtected() porte sur la boite protegee GLOBALE du
  pipeline (emprise terrain, bien plus large que le bati) et excluait donc la totalite de la
  zone « bati + 6 blocs » (mesure : 0 colonne analysable). Elle utilise maintenant l'empreinte
  REELLE du bati.
- groundSurfaceY() : lecture de hauteur O(1) + descente bornee a 6 blocs (l'ancienne descente
  bloc par bloc pouvait lire ~300 blocs par colonne d'eau -> tick de 60 s et watchdog).

Preuve : passe finale terrain -- vue de haut 30 chunks (744 colonnes de sol analysables) sur
59x71, 61 colonnes retouchees (39 cuvettes comblees, 22 saillies rabotees) en 4 ms ;
run complet : 288 ticks, pire 373 ms, 0 tick > 1 s, aucun watchdog.
```


---

## T35 — « Les trous profonds de plus de 2 blocs sont rebouchés »

**Fichier** : `src/main/java/deepluckyblock/procedures/StructureTerrainPrep.java`

```
T35 : refill des holes profonds par la passe finale de terrain

- Constat du run de validation T33/T34 : « 687 colonnes creusees de plus de 1 bloc
  (pire : -41) » -- des trous herites du carve, plus profonds que la regle « ecart max
  2 blocs » de la passe finale, donc jamais corriges (consigne <Dev> : « refill les
  holes puis smooth »).
- Un trou n'est comble que s'il est ISOLE (au moins 7 des 8 voisines plus hautes) et
  remonte jusqu'a la MEDIANE des voisines : jamais de tour, une vallee large ou un
  ravin (voisines basses) n'est pas touche. Profondeur bornee a 48 blocs ; puits
  artificiels (ecart avec la heightmap) exclus ; les saillies profondes restent du
  relief reel et ne sont jamais rabotees.
- Preuve : « 3 TROUS PROFONDS rebouches sur 3 detectes » (run t37_run2, everest).
```

## T36 — « Everest et circus : travail de terrain branche (ils n'en avaient aucun) »

**Fichiers** : `src/main/java/deepluckyblock/procedures/Structures4Procedure.java`,
`src/main/java/deepluckyblock/procedures/StructureTerrainPrep.java`

```
T36 : les structures posees en « paste brut » recoivent la passe finale de terrain

- Constat : spawnEverest n'appelle ni prepZone ni decorate (paste brut + sink de 10),
  et le circus/shipdead est en skipTerrain (« modif terrain DESACTIVEE ») : ni berges,
  ni crevasses, ni passe finale -- precisement la ou le joueur voit des creux et des
  bordures d'eau trop basses.
- StructureTerrainPrep.finalTerrainPass() est exposee publiquement et appelee a la fin
  du post-process de ces structures (PostJob.terrainFinal), donc en DERNIER sur le
  terrain comme dans le pipeline complet.
- Preuve : « passe finale terrain : 88 colonnes retouchees (41 cuvettes, 44 saillies,
  3 trous profonds) » sur l'emprise de l'everest.
```

## T37 — « Everest : pré-chargement de l'emprise réelle + passe finale étalée sur plusieurs ticks »

**Fichiers** : `src/main/java/deepluckyblock/procedures/Structures4Procedure.java`,
`src/main/java/deepluckyblock/procedures/StructureTerrainPrep.java`

```
T37 : deux causes de gel restantes supprimees

- La boite de pre-chargement de l'everest etait centree sur le POINT d'ancrage
  (327x327, rayon 155) alors que le paste couvre rotatedPos -> +taille (emprise reelle
  191x295) : « 435 demandes de chargement » PENDANT la pose, tick de 9 145 ms. La
  position finale et l'emprise sont maintenant calculees AVANT le pre-chargement, et
  c'est exactement cette emprise qui est epinglee.
- La passe finale etait plafonnee par un budget de 120/150 ms (« analyse vue de haut
  interrompue par le budget de 120 ms apres 14 chunks ») : elle est desormais repartie
  sur plusieurs ticks (tranches de 40 ms + replanification), donc plus aucun tick
  bloque ET la zone entiere est analysee.
- T37b : analyse et correction s'enchainent dans le meme tick (l'ancien enchainement
  sortait avant la correction : « 0 colonnes retouchees sur 0 examinees » alors que
  3 853 colonnes venaient d'etre analysees).

Preuve (everest) : preloadBox 191x295 (247 chunks), aucune demande de chargement
pendant la pose, EVEREST TERMINE en 14.632s, passe finale 88 colonnes retouchees
(41 cuvettes, 44 saillies, 3 trous profonds rebouches).
```

## Vue d'ensemble de la passe (T33 -> T37)

Le gel de l'everest passe de **61,051 s en jeu** à **14,632 s** en sandbox, et le pire tick
pendant la pose a disparu (il ne reste que la génération des chunks neufs, en pré-chargement,
qui n'existe pas sur un monde déjà visité).


---

# Commits T38 → T45 (retour en jeu du 23/09 — 13 remarques `<Dev>`)

Un commit par tâche, message en français, à appliquer dans l'ordre.

## 1/5 — T38 : /fixwater + /fixlava réimplémentés (eau ET lave)

```
T38 : /fixwater + /fixlava reimplementes (eau ET lave)

Demande en jeu du 23/09 : « tu dois absolument faire un /fixwater 1000 ... afin
de re remplir » (le fleuve gele hors chunks) ; « toute la nouvelle zone vide
prevue a la continuite du lac, sur tous les chunks relies a l'eau et sans bloc » ;
« fait de meme pour le fixlava, inclus le meme systeme que pour l'eau ».

StructureTerrainPrep : fixLiquidsPass() + LiquidJob (rayon 1000 blocs, chunks
charges uniquement, 40 ms/tick) :
  1) conversion flowing -> SOURCE pour l'eau ET la lave (comportement WorldEdit
     /fixwater et /fixlava, verifie en ligne : EngineHub 7.4, FAWE, WorldEdit-BE,
     wiki BadWolfMC, r/Minecraft) ;
  2) memorisation du plus haut bloc de liquide par colonne puis propagation du
     niveau (BFS 4 directions) pour re-remplir les cuvettes vides reliees au plan
     d'eau, creux <= 12 blocs, plafonds 40 000 blocs d'eau / 4 000 de lave.
Aucune generation synchrone (les chunks absents sont ignores) : pas de gel.
```

Fichiers : `src/main/java/deepluckyblock/procedures/StructureTerrainPrep.java`.

## 2/5 — T39 : la structure passe en absolu dernier (+ correctifs T43/T44)

```
T39 : la structure passe EN ABSOLU DERNIER (terrain d'abord)

Consigne en jeu du 23/09 : « ENORME erreur : la structure doit paste en absolu
dernier, apres tous les smooths ».

Avant : prepZone -> PASTE -> carve -> decorate (smooths + passe finale) -> post.
Apres : prepZone -> decorateTerrainOnly (failles, smooths, eau, berges, hole
filler, balayage, passe finale, fixwater/fixlava) -> PASTE -> carve ->
decorateFinish (decors, arbres, naturalisation) -> post.

- StructureTerrainPrep : decorate() -> decorateChain(...) + decorateTerrainOnly()
  et decorateFinish() ; la passe finale est ATTENDUE (rappel de fin) avant de
  rendre la main ; en phase terrain aucune protection d'emprise (le sol doit
  etre lisse partout).
- Structures5Procedure / Structures4Procedure : le paste part de la fin de la
  phase terrain ; les resumes post-pose appellent decorateFinish ; la passe
  finale T36 post-paste est supprimee (PostJob.terrainFinal toujours false).
- T43 : l'emprise du paste est re-scellée (preloadBox) juste avant la pose (le
  terrain a travaille 40 s depuis le pre-chargement : 160 demandes de chargement
  et des ticks de 2 a 7 s mesurees au run t39_run1).
- T44 : la phase terrain rend la chaine terrain avant le paste (sinon
  decorateFinish se reportait indefiniment).
```

Fichiers : `StructureTerrainPrep.java`, `Structures4Procedure.java`, `Structures5Procedure.java`.

## 3/5 — T40 : hole filler (tunnels, failles, cavités)

```
T40 : hole filler -- tunnels, failles et cavites rebouches

Consigne en jeu du 23/09 : « je vois encore des tunnels, des failles etc dans
mon terrain et qui n'ont pas ete re remplis ! » -> « copie pareil ... hole
filler minecraft ».

StructureTerrainPrep : sealUndergroundGaps() + sealColumn() + fillPocket() :
par colonne, du sommet jusqu'a 64 blocs, toute poche d'air encadree par un
plafond ET un plancher solides est rebouchee avec le materiau du plancher
(pierre a defaut). Plafonds : 24 blocs par poche, 250 000 blocs par structure,
passe time-sliced (384 colonnes/tick), poche ouverte vers le bas jamais comblee.
Branche dans la phase terrain AVANT la passe finale (donc avant le paste),
y compris pour l'everest et le repli « NBT vide ».
```

Fichiers : `StructureTerrainPrep.java`, `Structures4Procedure.java`.

## 4/5 — T41 : balayage étendu des lianes et naturels flottants (+ T45)

```
T41 : balayage etendu (lianes volantes + naturels flottants) sur les 2 chemins

Consigne en jeu du 23/09 : « je vois encore des lianes qui volent ! wtf ?? »,
« d'autres entites du meme genre flotter ».

Le balayage T23/T25 n'etait branche que dans decorate() : il ne tournait JAMAIS
dans le chemin « paste brut » (everest/circus) et s'arretait a 8 blocs.
StructureTerrainPrep : sweepFloatingNaturalPass() (anneau complet terrainRing,
fenetre surface +48/-10, cout O(60)/colonne, remontee depuis le sol, accroche
laterale acceptee pour lianes/lichen/racines, 384 colonnes/tick) branche en
derniere etape du terrain sur les deux chemins.

T45 (correctif) : la regle « plus relie au sol » tondait les canopees legitimes
(70 602 blocs sur un monde neuf) ; un decor n'est supprime que si son AMAS
ENTIER flotte (exploration 6 directions plafonnee a 512 blocs, amas ancres
memorises). Canopees intactes, lianes/ilots/residus bien supprimes.
```

Fichiers : `StructureTerrainPrep.java`, `Structures4Procedure.java`.

## 5/5 — T42 : mini-structures décoratives plaquées au sol

```
T42 : mini-structures decoratives plaquees au sol

Consigne en jeu du 23/09 : « certaines mini-structures decoratives (uniquement
elles) flottent de 1-2 blocs au-dessus du sol -> les plaquer au sol ».

StructureScatterDecor : l'origine du decor est calee sur son PLUS BAS BLOC REEL
(minLocalY, lecture de la palette du template ; rotation/miroir autour de Y ne
changent pas la hauteur) au lieu du Y de surface, et apres pose chaque colonne
de l'emprise est PLAQUEE (le vide sous le decor est comble avec le materiau du
sol, 4 blocs max). Log dedie « T42 -- N colonnes de decors plaquees au sol ».
La cause aggravante (passe finale de terrain rabotant le sol SOUS un decor deja
pose, FINAL_MAX_DELTA = 2 blocs) est supprimee par T39.
```

Fichiers : `src/main/java/deepluckyblock/procedures/StructureScatterDecor.java`.

---

## 6. T46 — pré-chargement borné dans le temps et parallèle

```
T46: pre-chargement des chunks borne (25 s) et parallele + pre-chauffage pendant l'annonce

Mesure en jeu du 23/09 au soir (Crimson Lake, zone 406x444 = 783 chunks) : 24 minutes
de pre-chargement sans finir, ~2 chunks livres toutes les 30 s, alors que la consigne
est « max 1 minute total » pour tout le pipeline.

Trois causes cumulees, toutes dans le code :

 1. ChunkKeeper.keep() ne demandait le chargement que de la TETE de sa liste
    (REQUEST_PER_TICK = 4 chunks, toujours les memes) : tant qu'un chunk de tete
    trainait, aucune autre demande n'etait emise, donc la generation restait serie.
 2. StructureTerrainPrep.preloadStep() n'avancait que sur un CURSEUR CONTIGU : un
    seul chunk capricieux (couronne exterieure, hors de la zone demandee par le
    ChunkKeeper) gelait le compteur pendant des minutes alors que des centaines de
    chunks etaient deja charges.
 3. Aucune borne de temps : le pipeline ne demarrait qu'a 100 % de la zone.

Correctifs :
 - ChunkKeeper : demandes REPARTIES sur toute la zone (round-robin), debit adapte
   aux coeurs (8-64/tick, 8-192 en vol), plus de demande pour un chunk deja charge.
 - StructureTerrainPrep : comptage de COUVERTURE (plus de curseur), distinction
   COEUR (emprise + 48 blocs, seule zone attendue, 20 s) / ANNEAU (8 s, non
   bloquant) et plafond absolu de 25 s ; passe le budget, le pipeline demarre et
   les passes sautent les colonnes absentes (T43 re-scelle l'emprise du paste).
 - Repli synchrone reserve au COEUR et a 1 chunk par tick.
 - SMOOTH_RING calcule AVANT ChunkKeeper.track() : maintien et pre-chargement
   portent enfin sur la meme boite.
 - Crimson Lake : warmZone() demandee DES L'ANNONCE (60 s) via ChunkKeeper.warmOnly
   => les chunks vierges se generent pendant le compte a rebours ; les demandes
   sont relancees toutes les 10 ticks pendant 90 s.

Preuves (sandbox 2 vCPU) : observatory 156 chunks NEUFS en 8,884 s (coeur 156/156,
zone complete) ; everest 484 chunks en 25,36 s puis pipeline, preloadBox 247 chunks
en 4,967 s, EVEREST TERMINE en 35,749 s ; 0 exception dans les deux runs.
```

Fichiers : `src/main/java/deepluckyblock/util/ChunkKeeper.java`,
`src/main/java/deepluckyblock/procedures/StructureTerrainPrep.java`,
`src/main/java/deepluckyblock/procedures/CrimsonLakeStructureSpawnProcedure.java`.

---

## 7. T47 — chronométrage + budgets adaptatifs

```
T47: chronometrage [DLB-PERF] du pipeline + budgets adaptatifs + fin du blocage synchrone sur zone geante

Rapport en jeu du 23/09 : « ca prends des temps de fou ! revois tout pour desactiver ce qui
nous fait perdre du temps, revois les ressources ». Relecture du log 02:23-02:48 :

 1. Le compteur de pre-chargement affichait 0/783 alors que 700 chunks etaient DEJA en memoire
    (il comptait une couronne exterieure que personne ne demandait) -> pipeline jamais demarre.
 2. Le repli force appelait getChunk(cx, cz, FULL, true) : generation SYNCHRONE, ~15 s de
    blocage par chunk, « Can't keep up! Running 26381ms », 2 chunks livres toutes les 30 s.
 3. Aucune borne : attente de 100 % d'une zone de 783 chunks.

Correctifs :
 - [DLB-PERF] : chronometrage de tout le pipeline par phase, imprime a la fermeture de la
   fenetre d'edition (phases classees par duree + pourcentage + attente/tick system).
 - Budgets adaptatifs : zone > 512 chunks -> coeur 12 s, anneau 4 s, plafond 15 s (au lieu de
   20/8/25) et repli SYNCHRONE INTERDIT (les demandes asynchrones generent en parallele).
 - Petit helper immuable PreloadState.withBudget() pour recalibrer a la construction.

Preuves (sandbox 2 vCPU, monde neuf) : observatory 132 chunks neufs en 7,667 s / TOTAL 16,3 s ;
everest 484 + 247 chunks, TOTAL 31,6 s dont pre-chargement 23,2 s (73 %, generation pure).
```

Fichiers : `src/main/java/deepluckyblock/util/DebugLog.java`,
`src/main/java/deepluckyblock/util/TerrainEditClamp.java`,
`src/main/java/deepluckyblock/procedures/StructureTerrainPrep.java`.

---

## 8. T48 — Crimson Lake : pose non bloquante + ordre T39

```
T48: crimsonlake - pose sans generation synchrone (blocs differes) + ordre T39 (terrain d'abord, structure en dernier)

Deux defauts restaient propres au lac :

 1. LA POSE BLOQUAIT LE THREAD SERVEUR. Pour CHAQUE bloc : getChunkSource().getChunk(cx, cz,
    true), soit une generation FULL synchrone (~15 s par chunk en jeu, 2 chunks / 30 s,
    « Can't keep up! Running 26381ms »). Les autres structures differaient les blocs
    (Structures5.placeOne), le lac non.
 2. LE LAC ETAIT LE DERNIER CHEMIN A APPELER decorate() APRES LA POSE : toute la chaine terrain
    (double smooth, failles, eau, hole filler, balayage, passe finale) repassait sur la structure
    deja posee, sur 783 chunks -> contraire a la consigne dev du 23/09 (« la structure doit paste
    en absolu dernier ») et tres couteux.

Correctifs :
 - placeCrimsonOne() : ne bloque jamais ; si le chunk n'est pas en memoire le bloc part dans
   `defer` (demande deja faite en tache de fond) et est repose au tick suivant (budget 40 ms/tick).
   Le job ne se termine que quand defer est vide.
 - prepZone -> decorateTerrainOnly -> preloadBox -> PASTE -> decorateFinish (schema des autres
   structures) : le terrain est fige AVANT la pose, apres la pose il n'y a que les decors.

Preuve : a valider en jeu sur l'evenement Crimson Lake (3,46 Mo de NBT, non testable dans le
bac a sable 2 Go) ; regression observatory + everest validee (TEST_T47_T48_2026-09-23.log).
```

Fichiers : `src/main/java/deepluckyblock/procedures/CrimsonLakeStructureSpawnProcedure.java`.

---

## 11. T49 → T52 — la vraie cause du « 1 h d'attente » + pré-chauffage borné

```
T49: zero generation synchrone dans tous les chemins chauds (mesure puis generation differee)

Le log in-game du 23/09 ne montrait pas un mod globalement lent : il montrait UN appel qui gele
le thread serveur, getChunk(cx, cz, FULL, true). Une generation FULL sur un monde neuf attend la
cascade de ses voisins : ~15 s de gel par chunk. D'ou « Can't keep up! Running 26381ms », 2 chunks
livres toutes les 30 s, et 0/783 -> 199/783 en 24 min. Un budget de temps ne peut rien contre un
appel bloquant : les budgets T46/T47 mesuraient l'horloge ENTRE deux gels.

Corrige (5 emplacements, tous hors Crimson Lake deja traite en T48) :
 - SafeSurface.primeChunk()   (appele par surfaceY(), donc a chaque colonne de terrain)
 - SafeSurface.captureHeightmap()
 - Structures4/5.findFlatArea()  (generation synchrone de ~300 chunks x 12-24 candidats !)
 - placeOne()/placeEverestBlock() en mode force
 - StructureTerrainPrep.backfillVoidGap()
Nouveaux outils SafeSurface : loaded/request/requestZone/zoneLoaded/primeChunkSoft. Un chunk non
pret n'arrete plus rien : ses colonnes sont sautees (comportement deja valide par le budget T46),
et la verification « terrain fantome » du findFlatArea repasse dans une SECONDE PASSE bornee.

T51: pre-chauffage borne en memoire (plafond adapte au tas de la JVM, vagues de 16, jamais bloquant)

Le pre-chauffage demandait toute la zone d'un coup (754 chunks pour le lac) : ~0,5-1 Mo par chunk
genere en memoire, donc 400-750 Mo -> mise en OOM mesuree. Desormais : plafond 384/256/160/64
chunks selon le tas (>= 4 Go / 3 Go / 2 Go / sinon ; -Ddlb.preheat=N), chunks les plus proches du
centre d'abord, vagues de 16 toutes les 5 ticks via getChunkFuture, aucun maintien en memoire.
Le reste est charge par le pre-chargement borne du pipeline (T46/T47).

T52: suppression du repli synchrone du pre-chargement (plus aucune generation bloquante)

Deux dernieres portes de sortie synchrones supprimees par defaut : le repli force (1 chunk/tick en
FULL bloquant, autorise pour toute zone <= 512 chunks) et la « reparation » primeChunkAbs d'un
chunk de coeur manquant. -Ddlb.sync=1 restaure l'ancien comportement (diagnostic). Il ne reste
donc aucun chemin de generation synchrone dans le pipeline.

T50b: /dlbtest crimsonlake (rejouer l'evenement du lac sans attendre le 1/500)

Le lac ne se declenchait que par l'evenement aleatoire (1/500 par minute) ou /crimsonlake avec un
joueur connecte. La nouvelle entree rejoue exactement le meme chemin (memes anneaux, meme
pipeline, annonce de 60 s comprise) ; -Ddlb.test.lakeTemplate=<nbt> permet de rejouer le pipeline
avec un petit NBT sur un environnement de test limite en memoire. Corrige au passage : theServer
n'etait renseigne que par la connexion d'un joueur (en console, le pipeline ne demarrait jamais).

Preuves (bac a sable 2 vCPU) :
 - run/logs/t51_run3.log : pipeline complet du lac TERMINE en 52,1 s (ordre T39 respecte, 0 exception)
 - run/logs/t51_run4.log : everest 52 979 blocs, aucune generation synchrone, 73,2 s
 - run/logs/t52_run1.log : zone geante de 616 chunks (taille reelle du lac) -- pre-chargement
   plafonne a 15 s, passes sautant proprement les colonnes non chargees ; run interrompu par la
   memoire du bac a sable (2 Go), pas par le mod.
```

Fichiers : `util/SafeSurface.java`, `procedures/Structures4Procedure.java`,
`procedures/Structures5Procedure.java`, `procedures/StructureTerrainPrep.java`,
`procedures/CrimsonLakeStructureSpawnProcedure.java`, `commands/DlbTestCommands.java`.


---

## 12. T53 -> T66 — passe « OPTI ULTIME » (chargement des chunks, lectures de terrain, tickets)

Un commit par tache. Fichiers touches :
`util/SafeSurface.java`, `util/ChunkKeeper.java`, `util/DebugLog.java`,
`util/StructureTemplateCache.java`, `util/TerrainEditClamp.java`,
`procedures/Structures4Procedure.java`, `procedures/Structures5Procedure.java`,
`procedures/StructureTerrainPrep.java`, `commands/DlbTestCommands.java`.

```
T53: cache de surface partage + ChunkKeeper (lectures de terrain 100% servies par le cache)

SafeSurface : cache direct-mapped 256 entrees (reponses positives seulement), memo par chunk,
invalidation par tranches. ChunkKeeper : la zone du pipeline est tenue en memoire (tickets PORTAL)
avec rafraichissement par tranches (~tour complet en 150 ticks) et 96 tickets/tick au maximum.
DebugLog : ligne [DLB-PERF] avec le bilan du cache et le temps par phase.
Mesure (t53_run1, observatoire) : 1 674 requete(s) moteur, 1 209 621 lecture(s) servies par le
cache (100 %), 40 colonne(s) hors memoire.

T54: parse NBT hors thread serveur au-dela de 256 Ko (plus de freeze a l'apparition)

StructureTemplateCache : TEMPLATE_SYNC_MAX_KB = 256. Au-dela, le .nbt est lu ET parse dans le thread
de fond DLB-StructureLoader ; -Ddlb.templateSync=1 restaure l'ancien comportement.
Mesure : "'observatory' : NBT charge en TACHE DE FOND (743 Ko) ... 3730 ms (le serveur n'a jamais
ete bloque)".

T55: scanGroundY ne scanne plus un chunk absent

Le scan de sol sautait un chunk deja absent en le "primant" (generation synchrone). Il rend
maintenant une colonne inconnue comme telle. Mesure : 28 934 -> 29 280 ms de gel. Hypothese
ecartee (le gel n'etait pas la), correctif conserve car il supprime une generation synchrone.

T56: plus aucune passe ne bloque sur un chunk absent (etat, qualite, eau/lave)

SafeSurface.state() devient non bloquant ; measureFlatQuality mesure sans attendre et exclut les
colonnes inconnues ; les controles eau/lave de Structures4/5Procedure et findFluidSurfaceY
passent par SafeSurface. Mesure : 29 540 ms. Hypothese ecartee, correctif conserve.

T57: instrumentation du scoring (joueur / emprises / mesures terrain)

Compteurs tPlayerMs/tSiteMs/tMeasureMs, ligne "[STRUCT5-FLAT] scoring termine" et
-Ddlb.flatDebug=true. C'est cette instrumentation qui localise le coupable :
28 624 ms dans measureFlatQuality (1 971 candidats x 81 colonnes = ~160 000 lectures).

T58: heightmap "primee" une seule fois par chunk

Heightmap.primeHeightmaps() appele une fois par chunk au lieu de laisser ChunkAccess.getHeight()
re-primer le chunk entier a chaque appel (~180 us/appel, mesure au javap sur le jar NeoForge).
Mesure : 36 863 ms. Hypothese heightmap ECARTEE (le correctif reste : il supprime un calcul inutile).

T59: grille de hauteurs partagee pour le classement des zones

Les 1 971 candidats recalculaient chacun leur propre balayage de terrain. Une seule grille
(gstep = SEARCH_S, gN = (searchR/gstep)*2+1) est desormais partagee ; qualityFromGrid() en derive le
score et rend null si moins de 30 % des cellules sont connues ; les 24 meilleurs candidats restent
verifies colonne par colonne (fiabilite inchangee).
Mesure (t59_run1) : 47x47, 2 002 cellules connues en 16 982 ms, scoring 1 986 candidats en 9 ms.

T60: registre d'etats de chunk (READY/PENDING) + chunkFor/heightOf sans interrogation inutile

Un chunk suivi n'est plus re-interroge : le registre sait s'il est pret ou en vol. Seuil de
fiabilite de la grille : 50 % -> 30 % de cellules connues.

T60b: toutes les demandes de chunk passent par SafeSurface (registre complet)

ChunkKeeper demandait ses chunks via getChunkFuture en direct : ces demandes etaient invisibles du
registre, qui croyait le chunk jamais demande et ATTENDAIT (16 247 ms). Nouveau
SafeSurface.requestThen(level, cx, cz, Runnable) ; ChunkKeeper l'utilise. Mesure : 18 219 ms -- seul,
le routage ne suffit pas.

T61: surfaceScan -- balayage borne des blocs, sans heightmap

SafeSurface.surfaceScan(ChunkAccess, ServerLevel, x, z) balaie les blocs de la section remplie la
plus haute vers le bas (AIR/LEAVES sautes, blocksMotion()/fluide = sol). Remplace la heightmap dans
la grille de scoring. Mesure : 16 812 ms -> la heightmap n'etait pas le cout non plus.

T62: diagnostic du cout reel des acces chunk (nombre, duree, attentes)

Compteurs diagChunkCalls/diagChunkNs/diagChunkWaits (> 2 ms) et journal enrichi de la grille.
Mesure (t62_run1) : 752 recherche(s) de chunk, dont 0 ayant attendu > 2 ms, 3 ms au total ->
LES LECTURES NE COUTENT RIEN ; le cout, ce sont les demandes.

T63: la boucle de scoring ne demande plus AUCUN chargement de chunk (gel 17 s -> 19 ms)

chunkFor() n'appelle plus request() : le classement des zones se fait sur ce qui est deja en
memoire, un candidat non connu est simplement ignore (il est repris a la verification).
Mesure (t63_run1) : grille 16 982 -> 19 ms ; scoring 464 candidats en 6 ms.
C'est LA cause racine du gel pre-pipeline : chaque request() cree un ticket et met le chunk en
file ; 600+ demandes dans un tick = 17 s de gel.

T64: verification des candidats sans attente (qualityOnReady), candidats differes en tache de fond

qualityOnReady(lvl, cx, cz, radius) mesure la qualite uniquement sur les chunks deja prets (null si
moins de 30 % de la fenetre est connue). Les candidats non prets sont DIFFERES (T49) et la zone est
demandee en tache de fond : plus aucun gel dans la verification.

T65: correctif du routage des demandes (callback toujours appele) + garde-fou du compteur

Bug trouve par test : requestThen rendait la main sans appeler son callback quand le chunk etait
deja en vol ; ChunkKeeper incrementait alors son compteur d'appels en vol sans jamais le
decrementer, et au bout de MAX_IN_FLIGHT fuites PLUS AUCUNE demande n'etait emise -- constate :
48 chunks sur 144 jamais charges, pipeline bloque en attente de sa zone.
Correctif : callback appele exactement une fois par appel (toutes sorties confondues) + garde-fou
qui remet le compteur a zero s'il devient incoherent.

T66: re-demande forcee des chunks perdus (reRequest) + zone complete garantie

Le registre READY etait cru sur parole alors qu'un chunk peut avoir ete decharge : la demande etait
sautee et le chunk ne revenait jamais. Ajout de SafeSurface.reRequest() et d'une re-tentative
periodique (5 s) des chunks toujours absents, plus le garde-fou du compteur.
Resultat (t66_run1) : 144/144 chunks, zone complete, pipeline en 20,5 s.
```

**Preuves** : `run/logs/t53_run1.log`, `t55_run1.log`, `t56_run1.log`, `t57_run1.log`,
`t58_run1.log`, `t59_run1.log`, `t60_run1.log`, `t60_run2.log`, `t61_run1.log`, `t62_run1.log`,
`t63_run1.log`, `t64_run1.log`, `t65_run1.log`, `t66_run1.log` (toutes dans le zip).

**Commit final (bilan)** :
`T53-T66: opti ultime du chargement -- gel pre-pipeline 28,9 s -> 0 ; pipeline complet en 20,5 s`


### 13) T67 — une entrée `/dlbtest` par structure + tab partout

**Fichier** : `mod_project/src/main/java/deepluckyblock/commands/DlbTestCommands.java`
(seul fichier touché).

**Message de commit :**
```
T67: une entree /dlbtest par structure (citadel, observatory, dragon, circus, ship, everest,
crimsonlake) + alias FR + suggestions/tab + permission 0 par defaut + /dlbtest list et tree

Pourquoi : la commande n'existait que sous la forme /dlbtest structure <id numerique> (ids a
connaitre par coeur) et exigeait la permission 2 -> en partie solo sans cheats elle n'etait NI
reconnue NI proposee par le tab. Desormais chaque structure a son nom simple (le nom du .nbt) comme
noeud LITTERAL (donc transmis au client et propose par TAB), avec alias francais ; /dlbtest structure
accepte un nom OU un ancien id, avec suggestions ; /dlbtest list affiche la table cliquable ;
/dlbtest tree affiche l'arbre reellement enregistre (diagnostic) ; permission 0 par defaut
(-Ddlb.cmdOp=1 pour revenir a l'ancien comportement operateur).

Preuve (run/logs/t67_run2.log) : /dlbtest tree -> 23 entrees de premier niveau ; /dlbtest observatory
-> pipeline COMPLET en 18,0 s (143/143 chunks) ; /dlbtest structure everest / citadelle / 5 ->
dispatch OK ; /dlbtest structure inconnu -> message d'erreur avec la liste des noms valides.
```


### 14) T68 → T70 — passes par colonnes bornées, amas bornés, colonnes rattrapées

**Fichier** : `mod_project/src/main/java/deepluckyblock/procedures/StructureTerrainPrep.java`
(seul fichier touché).

**Message de commit :**
```
T68/T69/T70: passes par colonnes bornees dans le tick, exploration d'amas bornee, colonnes non
chargees RATTRAPEES (everest : watchdog -> 104,5 s sans aucune colonne perdue)

T68 : le budget de temps d'une tranche de colonnes n'etait verifie qu'ENTRE deux lots de 384
colonnes. Or une colonne peut couter tres cher (58 lectures de blocs + exploration d'un amas de 512
blocs) : MESURE en jeu, tick de 38 340 ms pendant « balayage etendu des naturels flottants », puis
Watchdog et arret du serveur sur everest. Le budget est desormais teste A CHAQUE COLONNE, et toute
colonne > 50 ms est comptee puis journalisee (« N colonne(s) lente(s), pire X ms »).

T69 : l'exploration d'un amas naturel flottant (isFloatingCluster, jusqu'a 512 blocs x 7 lectures)
est bornee a 20 ms. Au-dela on repond « ancre » : on ne supprime JAMAIS un amas qu'on n'a pas pu
verifier entierement (on conserve plutot que d'effacer a l'aveugle) ; les depassements sont
journalises.

T70 : quand une colonne n'est pas encore chargee (pre-chargement borne T46/T51), elle etait comptee
puis JETEE (mesure : 43 321 colonnes du balayage et 45 737 du hole filler non traitees sur everest).
Elles sont desormais mises en attente et REPRISES automatiquement (0,5 s d'intervalle, 30 s au plus)
des que le chunk arrive.

Preuves (run/logs/t68_run3.log, t69_run1.log, t70_run1.log) :
 - observatoire : pipeline COMPLET en 17,9 s, 0 watchdog, 1 colonne lente identifiee (532 ms)
 - everest : plus aucun Watchdog, 0 colonne non traitee, 66 750 blocs flottants retires (vs 66 605),
   50 970 poches rebouchees (vs 50 929), TACHE COMPLETE en 104,5 s (avant : jamais termine).
```


### 15) T71 → T72 — lectures par sections + cache de terrain agrandi

**Fichiers** : `mod_project/src/main/java/deepluckyblock/procedures/StructureTerrainPrep.java`
(+ `util/SafeSurface.java` pour T72).

**Message de commit :**
```
T71: lectures de terrain par SECTIONS dans le hole filler et le balayage (+ plafond de rebouchage
reglable et journalise) ; T72: cache de terrain 4096 entrees + memo de proximite

T71 : les deux passes les plus lourdes lisaient leurs blocs un par un (64 lectures/colonne pour le
hole filler, 58 pour le balayage, ~9 millions chacune sur everest). Desormais les sections de 16
blocs sont testees d'un coup : hasOnlyAir() (16 blocs d'air traites ensemble) et maybeHas(predicat)
(section sans rien d'interessant = sautee). Les lectures unitaires passent par le ChunkAccess du
chunk, resolu une fois par colonne (SafeSurface.chunkFor) au lieu d'un Level.getBlockState par bloc.
Le plafond de blocs rebouches devient reglable (-Ddlb.holeFillMax, defaut 250 000 -> 400 000) et son
atteinte est JOURNALISEE (avant : la passe s'arretait en silence, d'ou des tunnels residuels).

Mesure (everest, monde neuf) : 71 238 poches / 333 798 blocs rebouches (avant : 50 970 / 250 000
avec plafond atteint) ; cout par bloc rebouche 147 -> 101 us (-31 %), soit ~30 % plus rapide a
travail egal ; 0 colonne non traitee (T70).

T72 : cache de chunks de terrain porte de 256 a 4096 entrees + memo "dernier chunk" (les passes
balayent des colonnes consecutives du meme chunk). Resultat honnete : le taux de lectures servies
par le cache n'a pas bouge (13 -> 14 %) car les ~5,2 M de requetes viennent de la quinzaine de
passes sur 147 065 colonnes, pas d'un seul balayage ; les deux correctifs sont conserves (ils ne
peuvent que reduire les recherches) mais l'optimisation de ce compteur est arretee la, le gain
restant etant marginal.

Preuves : run/logs/t71_run1.log (everest 120,3 s, plafond non atteint, 0 colonne perdue),
t72_run1.log (everest 116,4 s), t72_run2.log (observatoire 22,0 s, hole filler 1,3 s).
```


### 16) T70b — aucune attente inutile en fin de passe

**Fichier** : `mod_project/src/main/java/deepluckyblock/procedures/StructureTerrainPrep.java`.

**Message de commit :**
```
T70b: plus aucune attente inutile en fin de passe (colonnes inaccessibles alors que la zone est
complete) + note de fiabilite des mesures du bac a sable

Le mode rattrapage de T70 pouvait attendre jusqu'a 30 s pour des colonnes dont les chunks ne
reviendraient jamais (zone deja declaree complete cote ChunkKeeper). Desormais, si une tentative
entiere ne recupere AUCUNE colonne et que la zone est complete, la passe se termine honnetement au
lieu d'attendre : "N colonne(s) inaccessibles alors que la zone est complete -- passe terminee sans
elles (aucune attente inutile)". C'etait le seul risque d'allongement introduit par T70.

Mesures de reference (charge normale du bac a sable, runs t66 -> t72_run2) : observatoire 17,9-22,0 s
(hole filler 0,9-1,3 s), everest 104,5-120,3 s dont ~40 % de generation de chunks, grille de scoring
13-27 ms. Validation finale du jar : observatoire 23,8 s, aucune attente inutile, aucune exception
(run/logs/t72_run5.log). Les runs sous forte charge de la machine de test (t72_run3 : 123,4 s avec le
MEME jar que t72_run2 a 22,0 s) sont conserves pour transparence.
```

### 17) T73 — l'air n'est plus un bloc : filtre NBT en flux + pose sans air (+ T73b) 23/09/2026

```
feat(perf): lire les structures sans materialiser l'air (filtre NBT en flux)

Directive : "revois peut etre pourquoi l'air est compte comme bloc et comment le supprimer,
vois aussi meme pour les autres structures".

Cause : le .nbt materialise CHAQUE case de la boite du template. Le parseur vanilla cree un
objet par entree (~200 o) -- citadel = 2 114 112 entrees dont 95 % d'air, soit ~400 Mo
alloues puis rejetes a la pose (OutOfMemoryError au chargement, observe avant T73).

1. util/NbtAirFilter.java (nouveau) : lecture en flux du .nbt, deux tableaux primitifs
   seulement, reconstruction d'un tag ne contenant que les vrais blocs + l'air INTERIEUR
   (flood fill). Sous-tags nbt (coffres) et entities preserves. Tout cas inattendu rend la
   main au parse vanilla ; desactivable par -Ddlb.nbtAirFilter=0.
2. util/StructureTemplateCache.java : liste compactee + air interieur calcules une fois au
   chargement (thread de fond), journal [STRUCT-CACHE] avec le gain memoire.
3. Structures4Procedure / Structures5Procedure : pose de la liste compactee, air interieur
   lu dans le cache, et plus JAMAIS d'air repose sur de l'air (case deja vide = aucun acces).

Mesures (monde neuf, charge normale) : observatory 267 036 -> 15 450 blocs a poser
(23,6 s de pipeline, ~47 Mo evites) ; dragon 803 505 -> 75 484 (20,2 s, ~138 Mo evites) ;
citadel 2 114 112 -> 105 276 (43,2 s, ~381 Mo evites, charge et pose pour la PREMIERE fois
-- 113 930 blocs poses, 0 exception). Aucune regression : observatory 23,6 s contre 23,8 s
avant (T70b). everest et crimsonlake (palette sans air) gardent le parse vanilla.

T73b : le premier filtre redecodait les positions a la main avec le mauvais sens
(BlockPos.asLong met Y dans les BITS BAS : Y_OFFSET=0, Z_OFFSET=12, X_OFFSET=38). Une
position (x,y,z) relue donnait (z*4096+y, 0, x) -> boite d'edition de citadel a 274 648
blocs de large (274 672 chunks a pre-charger) et ServerHangWatchdog. Corrige par les
getters vanilla BlockPos.getX/getY/getZ + compteurs de controle dans le journal
("positions lues X .. Y .. Z .. (boite .., 0 hors boite)").

Risque residuel documente (NON corrige, T74 a valider) : SafeSurface.request() utilise
getChunkFuture(..., load=true), bloquant quand il est appele depuis le thread serveur ;
la cause du watchdog etait la zone geante (corrigee), pas cette API.
```

T73c (complement) : everest passe par le filtre en flux et le journal le prouve -- 52 980 entrees ->
52 980 blocs, 0 air, lecture 172 ms, positions 0..173/0..122/0..277 (0 hors boite). Son temps restant
est du MONDE (pre-chargement des chunks 50,8 s = 70 % sur monde neuf, hole filler 8,3 s), pas de la
structure : 72,4 s au total, 0 exception (run/logs/t73_run5.log). Ajout d'un journal explicite pour
les fichiers dont la palette ne contient aucun air ("palette SANS aucun air -- structure deja creuse,
lecture vanilla").

--- Commit n°18 — T75 : les 4 defauts du test in-game du 23/09 22:42 (vol / murs d'eau / temps / ordre)
Symptomes (log utilisateur 23/09 22:42) : structures 7 a 26 blocs au-dessus du sol, murs d'eau aux
frontieres, 62,5 s (observatory) et 81,6 s (dragon), decors poses avant que l'eau des chunks voisins
n'existe. Causes racines : (a) MOTION_BLOCKING_NO_LEAVES ne saute pas les TRONCS -> une cime d'arbre
servait d'ancrage ; (b) un lac est le terrain le plus PLAT du monde -> il gagnait le scoring de zone
plate puis declenchait [STRUCT5-SAFETY] eau=100 % ; (c) fixLiquids jetait silencieusement tout chunk
absent de la memoire ; (d) le thread de chargement NBT etait en MIN_PRIORITY (43 863 ms de parse) et
le pipeline ne travaillait que 12 ms par tick de 50 ms. Correctifs : SafeSurface.groundY /
groundStats (mediane d'emprise) / surfaceMaterial / surfaceScanEx / isCanopy / isSubmerged,
FLAT_MAX_WET, anneau proche de chargement a la demande + retentes bornees, priorite normale +
rechauffage etale des NBT au demarrage, TASK_BUDGET_MS 12 -> 35, arbre jamais plante dans une colonne
noyee. Build OK, jar 7ada62a69baf157e03db7058dc85f6bc, run/logs/t75_run1.log (0 exception).

--- Commit n°19 — T75a : ancrage sur le SOL SOLIDE (fin des structures qui volent)
`isCanopy` (feuilles + LOGS + bambou) exclu de scanGroundY/surfaceScanEx ; `groundY()` (ni air, ni
cime, ni liquide) pour `baseY` et les zones de repli ; `surfaceMaterial()` pour l'analyse de zone
(l'eau sous canopee enfin vue) ; re-ancrage post-smooth sur le **sol median de toute l'emprise**
(`groundStats`, echantillon 4 blocs) au lieu d'une colonne ; journal de preuve
« ancrage FINAL -- baseY=X et 1er bloc reel a Y=Z (ecart au sol = …) ». Mesure du test : observatory
-5 (offset demande), dragon -34 (offset demande) -> aucune structure suspendue.

--- Commit n°20 — T75b : zones en eau interdites (un lac est plat, mais inconstructible)
`FLAT_MAX_WET = 0.10` avec `FlatQuality.wetRatio` : les cellules liquides sont exclues de la
platitude et un candidat a plus de 10 % de colonnes liquides est ecarte, dans les trois mesures
(grille T59, `qualityOnReady` T64, verification/seconde passe). Journal :
« 323 candidat(s) ecarte(s) : surface en EAU ». Aucune ligne `[STRUCT5-SAFETY] … eau=100%` au test.

--- Commit n°21 — T75c : temps /3 (NBT au demarrage + budget de tick 12 -> 35 ms)
Rechauffage de fond des grosses structures des le demarrage du monde (une toutes les 10 s, garde
memoire a 350 Mo, jamais bloquant) ; thread `DLB-StructureLoader` en priorite normale (il etait
affame : 43 863 ms pour 'dragon' en jeu contre 2 859 ms en bac a sable) ; `TASK_BUDGET_MS` 12 -> 35
(le pipeline travaillait 24 % du tick : chaque etape de ~3 s de calcul coûtait 10 a 14 s de temps
REEL, visible dans le log utilisateur). Preuves : « rechauffage de fond 'circus' … (530 Mo de
marge) » puis « charge en tache de fond en 3574ms » ; « rechauffage de fond suspendu » quand la
memoire manque (garde actif).

--- Commit n°22 — T75d : murs d'eau (chunks voisins non charges) + ordre des decors
`fixLiquids` ne jette plus les chunks absents : anneau proche (emprise + 48 blocs) charge a la
demande et retente jusqu'a 6 tours, propagation du niveau d'eau idem (le niveau s'arretait net a la
frontiere), au-dela de l'anneau la passe reste opportuniste (mon premier essai forcait 15 876 chunks
-> ticks de 1809 ms : cadre). Garde anti-noyade : `isSubmerged()` sur les arbres, tout liquide
refuse pour les decors, message de phase « apres TOUS les fixwater ».

--- Commit n°23 — T74 : ancrage lu bloc par bloc + controle anti-vol avant la pose
Cause racine des « structures dans le ciel » : la hauteur d'ancrage venait de la heightmap
MOTION_BLOCKING_NO_LEAVES, qui ne saute PAS les TRONCS -> sur une colonne boisee elle rend la hauteur
de la CIME. Les +7 et +26 blocs du log utilisateur (baseY 69 et 88 pour un sol a 62) sont exactement
la hauteur d'un chene et d'un grand arbre. Correctifs : `SafeSurface.groundY()` lit le sol BLOC PAR
BLOC (ni air, ni cime, ni liquide ; la heightmap ne sert que de borne haute), `groundStats()` prend
une borne de depart (perf) et mesure la MEDIANE de toute l'emprise, et un CONTROLE ANTI-VOL
re-mesure le sol reel juste avant la pose : si le bas de la structure (offset oy compris) est
au-dessus du sol, elle est descendue de l'ecart avec un WARN explicite. Preuve (run/logs/t74_run1.log,
monde neuf) : « controle anti-vol OK -- bas de structure=33, sol reel median=65 (marge=32 bloc(s)
d'enfoncement) » et « ancrage FINAL -- baseY=67 et 1er bloc reel a Y=33 (ecart au sol = -34) » ;
379 candidats en eau ecartes par ailleurs, 0 exception.

## Commit n°24 — T76 : « 1 FREESE ICI » : le gel de 12 979 ms identifie et supprime

**Message de commit :**

```
T76: supprime le gel de 12979 ms du log 23/09 22:42 (tempete d'application de chunks + scanTrees)

- ChunkKeeper : REQUEST_PER_TICK 24 -> 1 et MAX_IN_FLIGHT 48 -> 2 (options -Ddlb.requestPerTick /
  -Ddlb.maxInFlight). 24 demandes/tick laissaient le generateur distancer le thread principal : les
  chunks s'empilaient en attente d'application (statut FULL, thread principal) et le tick suivant
  payait tout le retard. Preuve : 3439 ms et 2675 ms en bac a sable, 12979 ms dans le log utilisateur,
  tous dans UN SEUL tick.
- StructureTerrainPrep : scanTrees ne fait plus de flood-fill (100 entrees de file par bloc collecte,
  ~7 M insertions pour 148 arbres = 9,43 s de gel). Balayage borne au tronc (3x3 x hauteur) et arret
  des qu'on atteint le sol, tronc teste AVANT l'arret. Mesure : 9430 ms -> 58 ms.
- Effet de bord mesure et bienvenu : les vrais arbres n'etaient pas tous vus (le flood-fill marquait
  « vu » jusqu'a ±2 blocs et perdait les troncs voisins) et des big_dripleaf_stem de grottes
  luxuriantes etaient comptes comme arbres. replant : 4 -> 8 arbres reels replantes.
- Diagnostic : la ligne scanTrees passe par step() (ses 9,4 s etaient imputees a l'etape suivante :
  « l'etape [...] a pris 10149 ms » pour une etape de 720 ms).
- Outil de verification DLB_TREE_CHECK=1 : rejoue l'ancien algorithme sur la meme zone dans le meme
  run et journalise nouveau/ancien/identiques/OUBLIES/EN_TROP + trace des colonnes manquees.

Preuves : TEST_T76_2026-09-23.log (observatory puis dragon, monde neuf, seed 1337).

## Commit n°25 — T77 : `naturalize` decoupee en tranches (+ T77b : son anneau tenu en memoire)

**Message de commit :**

```
T77: naturalize decoupee en tranches (dernier tick > 1 s) + T77b son anneau en memoire

- naturalize etait la derniere passe monolithique : 42 813 a 54 064 colonnes traitees d'un bloc
  dans UN tick (LAGPROBE 1753 ms dragon, 3491 ms observatory). Elle ne passait pas par setPhase,
  donc le LAGPROBE facturait son temps a la passe suivante (il accusait cleanupZone) -- meme
  piege que scanTrees en T76.
- Elle avance maintenant par ColumnPass / startColumnPass (tranches de 96 colonnes, budget
  adaptatif 2-16 ms, report des colonnes sans chunk, etiquette de phase). Naturalisation INCHANGEE :
  meme bruit coherent valueNoise2D, memes densites, memes pools ; compteurs passes par closure.
- T77b : le passeur sautait les colonnes dont le chunk n'est pas charge (T70) alors que naturalize
  balaie un anneau plus large que la zone tenue (terrainRing + 16) : 5757 colonnes sur 42813 (13 %)
  laissees sans vegetation. La zone tenue est etendue a l'anneau de naturalize avant la passe
  (ChunkKeeper.track ETEND la zone, aucune epingle perdue) ; le passeur attend ces chunks.

Mesures (observatory, zone -44,-38, monde neuf) : pire tick 3491 -> 1372 -> 1257 ms ; TACHE COMPLETE
23,6 -> 23,8 -> 25,6 s ; 0 colonne non traitee ; 0 exception.
Preuve : TEST_T77_2026-09-24.log.

---

## Commit n°26 — T78 + T79 : fixwater a sortie anticipee, et mort du dernier gel de 60 s

**Message de commit :**

```
T78+T79: fixwater a sortie anticipee ; repli pente-minimale borne (fin du gel de 60 s)

T78 -- fixWaterNearStructure (rayon 20) lancait 4 passes completes identiques a CHAQUE appel
(4,9 s observatory / 6,4 s dragon) alors que la fonction est idempotente : une eau deja etalee
ne bouge plus. Les passes sont desormais successives (log « passe N/4 ») et la boucle s'arrete
des que delta == 0, en annoncant les colonnes economisees
(« passe 1/4 sans aucune correction -- l'eau est deja etalee, arret anticipe (3 passe(s) et
25 839 colonne(s) economisees) »). finishFixWater ne ferme plus qu'une fois
(« aucune eau courante a corriger -- zone saine »). Comportement metier inchange : tant qu'une
passe corrige quelque chose, la suivante tourne.

T79 -- le test T78 a revele un gel SILENCIEUX de 60 s (watchdog : "A single server tick took
60.02 seconds", serveur tue) juste apres « scoring termine : 0 candidat(s) », sans aucune ligne
de log pendant le blocage. Cause : quand le scoring ne retient rien, findFlat() retombe sur le
repli « pente minimale », seule boucle du projet sans filtre ni budget -- le scoring ne mesure
que les chunks en memoire (484 cellules, 3 ms) alors que ce repli mesurait toutes les cellules
du carre de recherche (jusqu'a 14 641 x ~49 lectures de heightmap, et une heightmap non primee
coute un rescan complet du chunk, cf. T58). Correctif, meme famille que T49/T58/T70 :
  (1) mesure des chunks DEJA CHARGES uniquement (SafeSurface.loaded, zero generation) ;
  (2) budget de veille 500 ms teste en cours de balayage + log de sortie (mesurees / ignorees
      / candidats) ;
  (3) sonde toutes les 1500 ms -> plus jamais de gel muet ;
  (4) logs d'entree et de fin systematiques.

Mesures (monde neuf, seed 1337, run du 25/09) :
  observatory : TACHE COMPLETE 24,6 s, pire tick 1322 ms, naturalize 4,0 s, replant 8 ;
  dragon      : TACHE COMPLETE 33,1 s, pire tick 621 ms (0 tick > 1 s), naturalize 2,8 s,
                replant 116, anti-vol OK (bas de structure 37, sol median 72) ;
  fixWaterNearStructure : 42 / 11 / 13 ms au lieu de ~5 s (3 passes economisees) ;
  repli pente-minimale : 529 cellules mesurees en 0 ms (avant : gel de 60 s + serveur tue) ;
  0 exception.

Preuve : TEST_T78_T79_2026-09-25.log + run/logs/latest.log.
```

**Fichiers touchés** : `procedures/StructureTerrainPrep.java` (T78 : `runFixWaterPass` /
`finishFixWater`), `procedures/Structures5Procedure.java` (T79 : repli pente-minimale de
`findFlat`).
