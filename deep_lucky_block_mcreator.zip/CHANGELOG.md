# CHANGELOG — Deep Lucky Block (NeoForge 1.21.1)

Toutes les modifications de cette session, avec justification. Une tâche = un commit.
Emplacement de référence : `mod_project/` (l'exemplaire de l'archive fait foi).

---

## T2 — Build de référence dans un environnement propre ✅

**Commit :** `T2: build de reference OK dans un env propre (JDK 21 + Gradle 9.4.1)`

- Aucune modification de code.
- Environnement : JDK 21 absent du sandbox (seul Java 11 présent) → installation de **Temurin JDK 21.0.12.1** dans `/opt/jdk`, **Gradle 9.4.1** téléchargé par le wrapper, cache Gradle dédié `/opt/gradle-home`.
- Lancement avec les mêmes garde-fous RAM que la session précédente (sandbox 1,9 Go) :
  `JAVA_TOOL_OPTIONS="-Xmx700m -XX:+UseSerialGC -XX:ActiveProcessorCount=1 -XX:MaxMetaspaceSize=256m"`.
- **Résultat : `BUILD SUCCESSFUL in 1m 36s`**, `build/libs/deep_lucky_block-1.0.jar` (12 Mo) produit. Aucune erreur javac, aucun OOM.
- `gradlew` était non exécutable dans l'archive (permission `-rw-r--r--`) → `chmod +x` (le fichier est sinon inchangé).

## T1 — Pipeline terrain : fin du gel silencieux ✅

**Commit :** `T1: pipeline terrain en tranches (fin du gel de 43 min) + logs des etapes manquantes`

### Diagnostic, établi sur pièces (pas une hypothèse)

Analyse automatique de **tous** les logs de `run/logs/` : recherche des écarts temporels entre deux lignes consécutives. Résultat — quatre gels de plusieurs minutes, tous de la même forme :

| Date | Écart | Dernière ligne avant le gel |
|---|---|---|
| 16/09 05:40:11 → 06:23:57 | **43 min 46 s** | `prepZone : build 68x84, ring=42 -> zone 152x168, 148 arbres sauves (prep AVANT paste)` puis `[STRUCT4-EVEREST] === SPAWN EVEREST ===` |
| 16/09 06:35:13 → 06:57:35 | **22 min 22 s** | `[STRUCT-CACHE] Réchauffage de fond : 'circus' chargé en 15044ms` |
| 18/09 13:07:38 → arrêt | **log vide** | `[STRUCT5] citadel : 113930 blocs (1 verre supprime)` (= `Structures5Procedure.java:1167`, l'appel `prepZone` suit à la ligne 1173) |
| 18/09 13:58:12 → 14:01:23 | **3 min 11 s** | Everest terminé, `[DLB-HEART]` puis plus rien |

Aucune exception, aucune stacktrace : le serveur **travaille** mais ne rend jamais la main et ne loggue rien.

Cause : dans `StructureTerrainPrep`, cinq passes étaient des boucles **synchrones** balayant toute la zone (`getHeight` + `getBlockState` + `setBlock` : plusieurs millions d'accès) exécutées **dans un seul tick**, **sans aucun log avant la fin** :

- `guardWaterEdges` (colonnes × ~35 Y)
- `clearWaterPockets` (colonnes × hauteur totale de la structure)
- `verifyGrassSurface`
- `cleanupZone` (colonnes × 51 Y)
- `fixWaterNearStructure` (4 passes × colonnes × 41 Y)

Dans `prepZone`, elles s'enchaînaient dans le callback de `clearFootprint`, et l'étape suivante (`smoothPass`) était le seul point de log — l'utilisateur n'avait donc aucun moyen de savoir où ça bloquait.

### Correctif (opérations et ordre strictement inchangés)

1. **Nouvel exécuteur `ColumnPass`** dans `StructureTerrainPrep` : une passe longue est découpée en **tranches**, une tranche par tick, avec un **budget de 8 ms par tranche** (le tick garde la main, le reste du jeu continue de tourner). La première tranche s'exécute immédiatement (le comportement est identique dès le premier tick).
2. **Les 5 passes converties** en versions trancées (`+` surcharge `Runnable onDone` pour l'enchaînement). Le corps par colonne est extrait à l'identique dans `clearWaterColumn` / `guardWaterColumn` / `verifyGrassColumn` / `cleanupColumn` / `fixWaterColumn` — mêmes tests, mêmes blocs posés, mêmes `FAST_FLAG`.
3. **Logs des étapes manquantes** : `prepZone` annonce maintenant 5/11, 6/11, 7/11, 8/11, 9/11, 10/11, 11/11 (avant : seules 0, 1, 2, 3, 4/11 loggaient). Plus aucune fenêtre aveugle.
4. **`decorate()` enchaînée** de la même façon (`decorate 1/5` → `5/5`), avec logs explicites autour de `fillGapsAndSteps` et `sealWaterLeaks` (les deux dernières passes synchrones ; laissées telles quelles pour l'instant **volontairement**, elles sont maintenant visibles dans le log si elles bloquent).
5. **Garde anti-doublon** `RUNNING_PASSES` : une seule passe d'un même type à la fois (les passes d'eau sont relancées par `sealWaterLeaks`, `decorate` et `prepZone` ; sans ce garde, chacune empilait sa propre file). Une passe étant idempotente, sauter le doublon ne change pas le résultat.
6. **Alerte de saturation** : si une tranche est exécutée avec plus de 200 ticks de retard sur la file de `TestProcedure`, un `WARN` explicite le dit dans le log. C'était l'angle mort du budget de 12 ms introduit par la session précédente : quand la file est saturée, tout le mod (y compris le pipeline) est mis en pause — le jeu continue de ticker, donc **aucun message** — soit exactement le « chargement infini » rapporté.

### Vérification

- `./gradlew compileJava` puis `./gradlew build` : **BUILD SUCCESSFUL** (2 fois), aucune erreur.
- Analyse du diff : chaque corps de boucle d'origine a été déplacé à l'identique ; seul le découpage temporel change.

### Risque connu / suite

- `fillGapsAndSteps`, `sealWaterLeaks` et les `smoothPass` restent synchrones au sein d'une tâche (bornés, mais pas trancés). Elles sont désormais encadrées de logs : un nouveau test en jeu dira immédiatement si l'une d'elles est le prochain goulot.
- Les chaînes terrain utilisent des champs statiques partagés (`LAST_TREES`, `PROTECT_MIN/MAX`, `PHASE_T0`, `SMOOTH_RING`) : si deux structures se chevauchaient dans le temps, elles pourraient se marcher dessus. **Ce risque préexistait** (le `decorate()` d'origine rendait déjà la main avant la fin de ses propres smooths) ; il n'est pas aggravé fonctionnellement mais la fenêtre est plus longue. À traiter en T6 (sérialisation stricte des chaînes) plutôt qu'en même temps que ce correctif.

## T3 — Test réel du pipeline sur serveur dédié (headless) ✅

**Commit :** `T3: test en jeu headless -- pipeline terrain valide de bout en bout + commande /dlbtest`

### Comment tester sans client graphique

Le sandbox n'a ni GPU ni écran : `runClient` est impossible. Or **tout le pipeline qui gelait est côté serveur**. Test donc sur un **serveur dédié** (`./gradlew runServer`), piloté par **RCON** (activé dans `run/server.properties`, port 25575) — c'est la seule façon d'envoyer des commandes et de lire les réponses sans terminal interactif.

Problème : les commandes existantes (`/eventtest`, `/crimsonlake`, `/dlbaudit`) appellent `getPlayerOrException()` → **inutilisables depuis la console** d'un serveur dédié. D'où un nouvel outil :

**Nouveau fichier `deepluckyblock/commands/DlbTestCommands.java`** — commande `/dlbtest` (permission 2), fonctionne avec **ou sans** joueur (création d'un `FakePlayer` si lancée depuis la console) :

- `/dlbtest structure <id>` — appelle **exactement** `Structures5Procedure.execute(level, player, id)`, le même appel que celui déclenché par la casse d'un Deep Lucky Block (`TestProcedure.java:1268`). Ids : 0=citadel, 1=observatory, 2=dragon, 3=circus, 4=shipdead, 5=everest.
- `/dlbtest luckybreak [nombre]` — pose un Deep Lucky Block avec **luck=100** dans son BlockEntity puis le **casse** avec le FakePlayer (chemin `playerDestroy` identique à un clic gauche du joueur), espacé d'1 s. C'est la reproduction fidèle de ton geste : « casser des lucky blocks +100 jusqu'à avoir une structure ».
- `/dlbtest ids` — rappelle la table des ids.

Usage depuis la console ou en jeu : `execute positioned <x> <y> <z> run dlbtest structure 1`

### Résultats (19/09, serveur 1.21.1 + ce jar)

| Test | Résultat |
|---|---|
| Démarrage serveur | `Done (18.146s)!`, RCON OK, `[STRUCT-CACHE] 153/153 décors en 87 ms` |
| **Everest** (id 5, 0,19 Mo) | **Terminé en 29,7 s**, serveur vivant, 2 ralentissements transitoires (6,7 s et 8,5 s de retard de tick) — **aucun gel** |
| **Observatory** (id 1, 0,74 Mo) | **Pipeline complet du début à la fin en 28,7 s** |

Séquence complète obtenue sur observatory (extrait de `TEST_STRUCTURES_2026-09-19.log`, 105 lignes conservées) :

```
08:40:57.924  prepZone 0/11 : pre-chargement de la zone 181x169 AVANT tout acces...
08:40:57.925  pre-chargement : 132 chunks etale sur 33 ticks
08:41:14.024  [16.1 s] prepZone 0/11 : zone chargee, demarrage du pipeline
08:41:14.029  prepZone 1/11 : scanTrees termine, 0 arbres sauves
08:41:14.100  [16.2 s] prepZone 2/11 : prefillFoundation termine
08:41:14.660  [16.7 s] prepZone 3/11 : clearSurfaceDecor termine
08:41:14.717  [16.8 s] prepZone 4/11 : clearFootprint termine
08:41:14.812  [16.9 s] prepZone 8/11 : guardWaterEdges termine
08:41:14.859  [16.9 s] prepZone 7/11 : clearWaterPockets termine
08:41:15.828  [17.9 s] prepZone 5/11 : smooth 7x7 x50 termine
08:41:16.068  [18.1 s] prepZone 6/11 : smooth 15x15 x12 termine
08:41:16.138  [18.2 s] prepZone 10/11 : verifyGrassSurface termine
08:41:16.313  [18.4 s] prepZone 11/11 : cleanupZone termine
08:41:16.411  [18.5 s] prepZone 9/11 TERMINE -- pret pour le paste
08:41:16.491  observatory en 23431ms (14972 blocs)
08:41:16.659  observatory termine : 14942 blocs supprimes
...
08:41:26.597  [28.7 s] decorate TERMINE (failles, smooths, fuites, decors, arbres, naturalisation)
```

Les 5 passes qui étaient **un seul bloc synchrone sans log** sont maintenant mesurables et bornées :
`cleanupZone 30 589 colonnes en 173-320 ms`, `guardWaterEdges 30 589 colonnes en 53-295 ms`,
`fixWaterNearStructure 34 452 colonnes en 59-349 ms`, `verifyGrassSurface 30 589 colonnes en 65-148 ms`.
Un seul `Can't keep up!` (4 475 ms) sur toute la séquence.
Le garde anti-doublon a aussi joué comme prévu : `fixWaterNearStructure : deja en cours, doublon ignore`
(relancé par `sealWaterLeaks` pendant que la passe précédente tournait).

### Deux défauts découverts grâce aux nouveaux logs (placement, pas freeze)

1. `[STRUCT5-FLAT] Budget de temps depasse PENDANT la generation du candidat pente-minimale -- abandon` puis
   `[STRUCT5-FLAT] Aucune zone valide trouvee` → la recherche de zone plate a échoué et la structure est retombée sur un placement dégradé : **observatory posée à Y=-78** (baseY=-65), soit très en profondeur ; everest à **Y=-90**. C'est un bug de **placement**, pas de performance, et il n'était pas visible avant (aucun log de ce chemin).
2. `[STRUCT5] observatory : deltaY anormal apres smooth (-65 -> 71, brut=136) BORNE a 0 - possible bug d'ancrage` → le garde-fou d'ancrage déclenche : la surface mesurée après lissage est très loin de celle mesurée avant. Même famille que ton bug « la structure est en partie DANS le sol ». À traiter en T7.

### Limite rencontrée dans le sandbox (pas un bug du mod)

Le premier test (citadel, id 0) a **reproduit le gel** — et c'est une découverte :

```
08:28:50.668  [STRUCT5] === PASTE citadel === ...
   ... aucune ligne ...
08:31:30.373  [Server Watchdog/FATAL] A single server tick took 60.29 seconds
```

La cause n'est **pas** dans les passes que T1 a corrigées (aucune n'était encore atteinte) mais **avant** : `StructureTemplateCache.get()` désérialise le NBT à froid **dans le tick** (citadel = 6 Mo compressés / **76 Mo décompressés**). Sur ce sandbox (1,9 Go de RAM, tas serveur 900 Mo, sans swap) le parse du graphe NBT ne tient pas en mémoire → GC en boucle et tick de 60 s+. Sur ta machine (16 Go), ce même parse coûte ~1,5 s (mesure de la session précédente : « citadel 72,8 Mo décompressés -> 1471 ms ») : ce n'est donc **pas ton gel**, mais c'est un vrai point chaud à lisser (T7), d'autant qu'il est aujourd'hui **totalement silencieux dans le log**.

## T5 — Suppression des données 1.20.1 mortes ✅

**Commit :** `T5: suppression des doublons de donnees 1.20.1 (24,5 Mo)`

Dossiers jamais lus par 1.21.1 (renommés au singulier depuis 1.20.5/1.21), vérifiés **avant** suppression : aucune entrée unique n'était perdue (comparaison nom par nom et taille par taille), à l'exception d'un fichier à double extension lui-même dupliqué.

Supprimés dans `mod_project/src/main/resources/` :

| Chemin supprimé | Contenu | Garde l'équivalent vivant |
|---|---|---|
| `data/deep_lucky_block/advancements/` | 51 JSON | `data/deep_lucky_block/advancement/` |
| `data/deep_lucky_block/recipes/` | 30 JSON | `data/deep_lucky_block/recipe/` |
| `data/deep_lucky_block/loot_tables/` | 3 JSON | `data/deep_lucky_block/loot_table/` |
| `data/deep_lucky_block/forge/` | biome_modifier | `data/deep_lucky_block/neoforge/` |
| `data/deep_lucky_block/structures/` | 9 .nbt — **24,5 Mo** (dont `shipdead.nbt.nbt` à double extension) | `data/deep_lucky_block/structure/` (174 fichiers, version corrigée `NeoForgeData`) |
| `data/minecraft/tags/entity_types/` | 1 JSON | `data/minecraft/tags/entity_type/` |
| `FIXES_MCREATOR/` (racine du projet) | 7 fichiers | `src/main/resources/deepluckyblock_patch/FIXES_MCREATOR/` (13 fichiers) — c'est CE chemin que lit la tâche `applyMcreatorPatch` |

Total : **46 Mo → 23 Mo** dans `src/main/resources/data`. Les fichiers `.nbt` conservés sont bien les versions corrigées : le renommage `ForgeData` → `NeoForgeData` y est complet (comptage des occurrences : 100 % des clés sont en `NeoForgeData`).

## T7 — Chargement NBT hors tick + placement Y réel (citadel, everest, observatory) ✅

**Commit :** `T7: cause racine des placements rates (heightmap non initialisee) + NBT des grosses structures charge hors tick`

### 1. La cause racine, enfin identifiée et prouvée

Le code lisait la hauteur du terrain avec `level.getHeight(...)`. **Sur un chunk que le jeu n'a pas
encore généré (ou qui est en cours de chargement), cette fonction ne renvoie pas une erreur : elle
renvoie la valeur sentinelle `minBuildHeight` = −64.** D'où, une fois convertie en Y de base :

| Symptôme observé en jeu | Valeur | Explication |
|---|---|---|
| Everest posé à `Y = −90` | −90 | `baseY = −65`, puis `+ EVEREST_OFFSET_Y (−25)` |
| Observatoire posé à `Y = −78` | −78 | `baseY = −65`, puis `+ offset (−5) − minRelY (8)` |
| `deltaY anormal apres smooth (-65 -> 71, brut=136)` | 136 | la mesure AVANT smooth était fantôme (−65), celle d'APRÈS (terrain réellement construit) était juste |
| `[STRUCT5-FLAT] Aucune zone valide trouvee` | — | tous les candidats mesuraient « pente 0, terrain plat » sur des chunks vides, la vérification après génération relisait −64 : aucun candidat ne pouvait jamais être validé |
| `despeckle : 25469 colonnes de heightmap corrigees` | 25 469 / 30 589 = **83 %** de la zone | le pipeline de terrain travaillait sur une carte fantôme |

Preuve directe, obtenue avec la nouvelle sonde (serveur dédié, chunk jamais visité, 30 000 / 30 000) :

```
[DLBTEST] PROBE 30000,30000 : AVANT correction -- chunk charge=false heightmap initialisee=false getHeight brut=-65
                             | APRES correction (SafeSurface) -- hauteur=71 heightmap initialisee=true getHeight relu=71
```

### 2. Le correctif : `util/SafeSurface.java` (nouveau fichier)

Un seul point de passage pour toutes les mesures de terrain :

- **génération forcée** du chunk (`getChunkSource().getChunk(cx, cz, FULL, true)`), comme le fait déjà la pose des blocs ;
- si la heightmap répond encore la sentinelle alors que le chunk est réellement généré, elle est
  **recalculée** avec l'API vanilla prévue pour ça, `Heightmap.primeHeightmaps(chunk, Set<Types>)`
  (jamais de bricolage des données internes) ;
- si elle reste vide malgré tout, **lecture bloc par bloc** en dernier recours (une mesure peut être
  lente, elle ne doit jamais être fausse) ;
- `captureHeightmap(...)` : capture d'une zone entière en soignant chaque chunk une seule fois ;
- `stats()` dans les logs (`[DLB-SURFACE]`) : chunks réinitialisés, rattrapages bloc par bloc.

Rien n'est modifié en jeu : on ne fait que lire la vraie surface (et remettre la heightmap du chunk en
état, ce que la génération normale aurait fait).

### 3. Points d'ancrage migrés

- `Structures5Procedure` (citadel / observatory / dragon) : `findSafeOutsideChunkPos`, `findFlat`
  (mesure Y réelle + repli non nul quand des candidats existent), `doPaste` (baseY), et **le
  re-ancrage post-smooth**.
- `Structures4Procedure` (circus / shipdead / everest) : `findSafeOutsideChunkPos`, `spawnEverest`
  (baseY), `doPaste` (baseY), `findFlatArea`.
- `StructureTerrainPrep` : le pré-chargement de la zone (étape 0 de `prepZone`) initialise désormais
  la heightmap de chaque chunk, et les deux captures de hauteurs de zone (smooth, `fillGapsAndSteps`)
  passent par `SafeSurface.captureHeightmap`.

**Fin du bornage `deltaY`** : l'ancien `clamp(rawDeltaY, -4, 0)` a été supprimé. Il n'existait que pour
masquer les mesures fantômes ; il transformait une structure de 136 blocs trop haut en structure
*enterrée de 149 blocs* (le fameux « deltaY anormal BORNE a 0 »). La structure suit maintenant le sol
réel dans les deux sens, l'offset manuel (`oy`) reste appliqué par-dessus, et un écart supérieur à
`MAX_POST_SMOOTH_DELTA_Y` (4) déclenche un WARN explicite au lieu d'être corrigé en silence. Si la
hauteur post-smooth est illisible, la structure **n'est pas déplacée** (message d'erreur explicite).

### 4. NBT des grosses structures chargé hors du tick

`StructureTemplateManager.get()` décompresse et désérialise tout le NBT **sur le thread serveur** :
citadel = 76 Mo décompressés (5,99 Mo sur disque), shipdead = 60 Mo, crimsonlake = 47 Mo, dragon = 28 Mo.
C'est le gel de 60,29 s constaté en test et la source du « Can't keep up! Running 78183ms » d'origine.

- **`StructureTemplateCache.requestAsync(level, nom)`** : le parse se fait sur **un thread de fond unique**
  (`DLB-StructureLoader`, daemon, priorité basse) via l'API publique `readStructure(CompoundTag)` —
  exactement le chemin vanilla (DataFixer compris), sans jamais écrire dans les structures internes du
  jeu. `isCached` / `isPending` / `hasFailed` / `clearFailed` complètent l'outillage.
- **La génération attend au lieu de bloquer** : une structure dont le NBT n'est pas encore en mémoire
  est mise en tête de file, le chargement est lancé, et elle démarre **automatiquement** quelques ticks
  plus tard (`Structures5Procedure.startNextPending` + relance au tick). Messages en jeu :
  `§e⏳ … : préparation du terrain en cours…`. Aucun clic, aucune action du joueur.
- Même traitement pour `Structures4Procedure` (circus / shipdead / everest : `templateReadyOrDefer` +
  reprise au tick) et pour **Crimson Lake** (chargement lancé au déclenchement, pendant les 60 s
  d'annonce ; la pose est reportée de 20 ticks si le fichier n'est pas encore prêt).

### 5. Résultats mesurés (19/09, serveur dédié + RCON, monde seed 1337)

| Test | Avant (T3) | Après (T7) |
|---|---|---|
| Everest (id 5) | `Position : 200, -90, 200` | **`Position : 3500, 53, 3500`** puis **`Position : 200, 61, 200`** — baseY réel (78 / 86), offset manuel −25 respecté |
| Observatory (id 1) | jusqu'à `-368, -78, -400` | **`observatory -> -3115, 50, -3125 (baseY=63, minRelY=8)`** — baseY réel, offset −5 respecté |
| Colonnes de heightmap fantômes dans la zone | `25469 / 30589` (83 %) | **`8 / 30589`** (0,03 %) |
| Chargement NBT observatory | bloquant | **`charge en tache de fond en 3307ms (le serveur n'a jamais ete bloque)`** |
| Charge NBT everest | bloquant | **`330ms` en tâche de fond** |
| Gels | gel de 60,29 s (watchdog) | aucun ; seulement des retards de tick transitoires (3,7–6,0 s) pendant le paste, comme attendu |
| 80 lucky blocks luck=100 cassés (`/dlbtest luckybreak`) | — | **0 erreur, 0 gel, 80 blocs cassés OK** |

Limite de test assumée : le sandbox ne dispose que de 1,9 Go de RAM. **La citadelle (76 Mo de NBT
décompressés) ne peut pas y être chargée** — le processus est tué par l'OOM-killer du conteneur, ce qui
n'est pas un défaut du correctif (mesure du parse sur machine à 16 Go : 1471 ms). Le chemin emprunté est
identique à celui d'everest/observatory, dont le chargement de fond est prouvé ci-dessus.

### 6. Contrôle qualité

- `./gradlew build` → **BUILD SUCCESSFUL** à chaque étape (dernier build : 12 s, jar
  `build/libs/deep_lucky_block-1.0.jar`, 8 793 882 octets).
- Serveur dédié : `Done (13.401s)`, RCON OK, **0 `ERROR` / 0 exception** dans `run/logs/latest.log`.
- Nouvelle sonde `/dlbtest probe <x> <z>` (garde-la) : affiche l'état AVANT correction (chunk chargé ?
  heightmap initialisée ? valeur brute) puis APRÈS correction, plus les compteurs de `SafeSurface`.
- Extrait brut des preuves : `TEST_T7_2026-09-19.log` (46 lignes, à la racine du zip et dans `mod_project/`).

---

---

## T6 — Chaînes terrain sérialisées + passes de fin découpées ✅

**Commit :** `T6: passes terrain serielles et decoupees (fin des ticks geants)`

### Le problème, mesuré
Les passes de fin de terrain de `StructureTerrainPrep` étaient **synchrones** :
`fillGapsAndSteps` (3 passes sur ~30 000 colonnes) et `sealWaterLeaks` (jusqu'à
8 itérations balayant toute la zone PUIS un `fixWaterNearStructure` complet)
tournaient d'un seul bloc à l'intérieur d'un tick. Preuve dans le log du test
T9 (avant correctif) :

```
[12:18:10] [DLB-STRUCTURE] decorate 2/5 : fillGapsAndSteps debut
[12:18:10] [DLB-STRUCTURE] fillGapsAndSteps : 24 blocs de faille combles, 3832 blocs de marche adoucis
[12:18:11] [MinecraftServer] Can't keep up! Running 8917ms or 178 ticks behind
```

Second problème, structurel : les passes partagent des **champs statiques**
(nom de la structure en cours, arbres sauvés avant le paste, colonnes de barrage,
emprise protégée). Deux structures qui préparaient leur terrain en même temps se
marchaient dessus (la structure A replantait les arbres de B, la protection
d'emprise de A sautait au milieu d'un smooth de B) — sans jamais lever d'erreur,
donc sans trace exploitable.

### Le correctif
1. **Verrou de chaîne terrain** — `util/TerrainChain.java` (nouveau) : une seule
   chaîne à la fois, prise au début de `prepZone` et de `decorate`, rendue à la
   fin réelle du pipeline. Un appelant qui ne l'obtient pas est **reporté**
   (jamais perdu) de 20 ticks, avec une reprise de force après 90 s sans
   progression (garde-fou anti-blocage).
2. **`fillGapsAndSteps` → `GapStepPass`** (classe interne, découpée) : capture de
   la heightmap par bandes de 4096 colonnes puis balayage des colonnes par
   tranches de 8 ms, planifiées une par tick, avec la **logique de remplissage
   strictement identique** (mêmes seuils, mêmes garde-fous `isProtected`).
3. **`sealWaterLeaks` → `SealLeaksPass`** (classe interne, découpée) : repérage
   des fuites, pose du barrage irrégulier et vidange, chacun découpé ; la
   relance de `fixWaterNearStructure` se fait désormais **en continuation** au
   lieu d'un appel bloquant.
4. `decorate()` enchaîne ces deux passes comme les autres étapes du pipeline
   (callbacks), sans changer l'ordre ni les opérations.

### Preuve en jeu (20/09, serveur dédié headless, monde neuf seed 1337)
`/execute positioned 400 90 400 run dlbtest structure 17` (observatory) :

```
[12:31:51] fillGapsAndSteps : 35 blocs de faille combles, 3630 blocs de marche adoucis (seuil 2) -- 9 tranches, 64 ms
[12:31:56] sealWaterLeaks iteration 1 : 2 fuites, 6 blocs de barriere, 0 blocs d'eau retires
[12:31:56] sealWaterLeaks : zone etanche apres 1 iteration(s)
[12:32:02] [33.6 s] decorate TERMINE (failles, smooths, fuites, decors, arbres, naturalisation)
```

Aucun tick géant attribuable à ces passes (contre 8 917 ms avant). Détail complet :
`TEST_T6_T9_T4_2026-09-20.log`.

---

## T9 — Optimisation complète (guide externe) : zone tenue, chargement non bloquant, et LA cause racine du gel ✅

**Commit :** `T9: zone tenue en memoire + preload non bloquant + cause racine du freeze`

Le guide externe fourni (« mine d'or », 83 sections) a été analysé intégralement.
Ce qui a été retenu, ce qui a été écarté et pourquoi, est consigné ici.

### 9.1 CAUSE RACINE DU GEL ET DU WATCHDOG — `SanctuarySpawnerEquipProcedure`

C'est le point le plus important de la session, et il n'a **rien à voir avec le
pipeline de structures**. Le crash-report du 20/09 à 12:04:02 (« A single server
tick took 60.00 seconds ») contient la pile d'appels exacte :

```
SanctuarySpawnerEquipProcedure.findNearestSpawner(SanctuarySpawnerEquipProcedure.java:177)
  -> Level.getBlockState -> Level.getChunk(x, z, FULL, true)
  -> ServerChunkCache.getChunk -> BlockableEventLoop.managedBlock   <-- génération de chunk SYNCHRONE
  <- LevelChunk.runPostLoad <- ChunkStatusTasks.full <- addWorldGenChunkEntities
```

Deux scans balayaient **31x31x31 = 29 791 positions** avec `getBlockState()` :
`findNearestSpawner` (appelé à l'arrivée de CHAQUE zombie/squelette/noyé) et
`onPlayerTick` (toutes les 2 s). Or `getBlockState` **force la génération
complète du chunk** s'il n'est pas en mémoire. Le rayon de 15 blocs déborde sur
les chunks voisins : chaque mob qui apparaissait dans un chunk fraîchement
généré — exactement ce que produit la pose d'une structure (des centaines de
mobs d'un coup) — forçait la génération de jusqu'à 8 chunks supplémentaires,
sur le thread principal, pendant que le pipeline de terrain travaillait sur la
même zone. D'où le gel de 60 s et le redémarrage forcé du serveur.

**Correctif** : un parcours unique et sûr (`forEachCandidate`) qui ne touche que
les chunks **déjà chargés et générés** (`getChunkNow`, jamais de génération) et
saute les sections 16x16x16 vides (un spawner n'est jamais de l'air). Le coût du
scan passe de 29 791 lectures de blocs à quelques centaines. Preuve : le
scénario exact qui tuait le serveur (everest à 6000,90,6000 dans un monde neuf,
donc entièrement à générer) **termine** désormais :

```
[12:11:28] [STRUCT4-EVEREST] Filtrage : 52979 solides, air skip=0, verre skip=1
[12:11:46] [STRUCT4-EVEREST] EVEREST TERMINÉ en 20.796s (52979 blocs)     <-- aucune Watchdog
```

### 9.2 La zone de travail reste en mémoire du début à la fin du pipeline

`util/ChunkKeeper.java` (nouveau) : la zone (build + ring) est déclarée dès le
début de `prepZone` et **tenue chargée** jusqu'à la fin de `decorate`.
- tickets **vanilla** `TicketType.PORTAL` (durée 15 s, libération automatique :
  rien d'écrit dans `level.dat`, contrairement à `setChunkForced` qui a été
  écarté pour cette raison) ;
- pose **progressive** (6 chunks/tick) et **uniquement sur des chunks déjà
  chargés** : une salve de tickets d'un coup gelait le serveur (constaté en
  test) ;
- renouvellement autonome toutes les 5 s par une tâche planifiée, pour couvrir
  les phases où **aucune passe ne tourne** (le paste, qui dure des dizaines de
  secondes) ;
- garde-fou : libération forcée après 10 minutes sans fin de pipeline.

**Ce que ça a corrigé, mesuré** : avant, la zone était relâchée après 10 s
d'inactivité, les chunks se déchargeaient pendant le paste, et les passes
suivantes **sautaient leurs colonnes** :

```
avant : fixWaterNearStructure : 13708 colonnes sautees (chunk absent)  (sur 34452, soit 40 %)
après : aucune ligne "colonnes sautees"
```

Effet secondaire positif et visible : la décoration reprend. Avant, presque
toutes les poses étaient rejetées (chunks absents) ; après, elles aboutissent :

```
avant : scatter [OBSERVATORY] : 0 naturels (cible 4) sur 0 decors poses / 0/14 schematics (450 rejetes)
après : scatter [OBSERVATORY] : 5 naturels (cible 5) sur 11 decors poses / 11/11 schematics (43 rejetes)
```

### 9.3 Le pré-chargement ne bloque plus jamais le tick

`preloadChunksBatched` forçait la génération (`getChunk(..., requireChunk = true)`)
4 chunks par tick. Ce chemin pouvait à lui seul produire un tick de 19 200 ms
(mesuré) et un Watchdog de 60 s. Désormais : on demande les chunks
**en tâche de fond** et on n'avance que sur ce qui est déjà arrivé
(`preloadStep`), le repli bloquant n'existant qu'après 20 s sans progression.
Le passage par `SafeSurface` est conservé (c'est lui qui garantit la heightmap
utilisable — cause racine corrigée en T7).

### 9.4 Budget de tranche adaptatif (anti « chaîne de lags »)

`sliceBudgetMs()` : le budget par tranche (8 ms) est réduit quand le serveur est
déjà en retard (MSPT ≥ 55 → ÷2, ≥ 65 → ÷4) et augmenté quand il respire
(MSPT ≤ 25 → ×1,75). Un pic ne se transforme plus en retard permanent.

### 9.5 Drapeaux d'écriture : `FAST_FLAG` corrigé (vérification d'API)

`javap` sur `Block.class` (1.21.1) : `64` n'est pas « supprime les drops » mais
**`UPDATE_MOVE_BY_PISTON`**. Comme ce drapeau devient le paramètre `isMoving` de
`LevelChunk#setBlockState`, le chunk traitait chaque écriture comme un
**déplacement par piston**, chemin dans lequel le nettoyage des block entities
n'est pas fait normalement. Corrigé en `2 | 16 | 32` (`UPDATE_CLIENTS` +
`UPDATE_KNOWN_SHAPE` + `UPDATE_SUPPRESS_DROPS`), dans les trois fichiers qui
définissaient la constante. Mesure honnête : les avertissements
« Tried to load a DUMMY block entity » restent au **même nombre (29)** avant et
après — ils ne venaient donc pas de ce drapeau ; ils sont listés en point ouvert
dans le log de test. Le changement reste appliqué parce qu'il rend le code
sémantiquement correct.

### 9.6 Ce que le guide proposait et qui a été ÉCARTÉ (et pourquoi)

| Proposition du guide | Décision | Raison |
|---|---|---|
| Écriture directe `LevelChunkSection.setBlockState(...)` (~15-40 ns/bloc) | **écarté** | exige `setUnsaved(true)` sous peine de **perte de blocs à la sauvegarde**, et un renvoi explicite des sections aux joueurs, sinon désynchronisation silencieuse. Le mod tourne en local : le risque « je déconnecte et tout disparaît » n'est pas acceptable pour un gain déjà largement obtenu autrement (le paste est passé de ~1 100 à **51 600 blocs/s** grâce aux chunks épinglés). |
| Mixins `@Inject` sur `Level.tickBlock` / `addFreshEntity` / `scheduleTick*` | **écarté** | signatures et noms non vérifiés pour 1.21.1 ; un mixin qui ne cible pas la bonne méthode casse au démarrage. Un mixin faux = crash au boot, pour un gain non mesuré. |
| `CascadeSuppressor` global (couper `neighborChanged` partout) | **écarté** | menace l'intégrité du monde (redstone, eau, portes) sur des zones entières. |
| `ParallelLightCalculator` (BFS lumière hors moteur) | **écarté** | hors moteur = corruption de lumière possible, non réparable sans régénération. |
| `setChunkForced` pour garder les chunks | **écarté** | écrit un état **persistant dans `level.dat`** ; les tickets `PORTAL` du ChunkKeeper obtiennent le même effet sans rien laisser derrière. |
| Renvoyer les sections entières aux clients après écriture | **écarté** | nos écritures passent par `level.setBlock` (le client est prévenu) ; l'optimisation ne concernerait que l'écriture directe, elle-même écartée. |
| Groupe « PASTE : ordre d'écriture par sections 16³ + spirale depuis le centre » | **déjà en place** (T3) | vérifié dans le code avant d'appliquer quoi que ce soit. |
| Smooth : falloff smoothstep + rayon brouillé par bruit + table d'offsets précalculée | **déjà en place** | idem, vérifié (sections 44 du guide). |

---

## T4 — Documentation alignée sur le code ✅

**Commit :** `T4: doc alignee sur le code (mixins, banniere, smooth, kits, version)`

Les 7 contradictions du §7 de `RAPPORT_ETAPE0.md` sont traitées une par une dans
**`DOC_ALIGNEMENT_T4_2026-09-20.md`** (état trouvé → correction → preuve).

Résumé :
- **Mixins** : ils sont actifs (ce n'était pas « abandonné ») — la config
  **déclarée** `deep_lucky_block.mixins.json` est bien en `JAVA_21` (preuve en
  jeu : `Compatibility level set to JAVA_21`, puis `Prepared 2 mixins` en
  serveur dédié). Le vieux `deepluckyblock.mixins.json` en `JAVA_17` n'est
  **déclaré nulle part** : inerte. Six classes mixin présentes dans
  `deepluckyblock/mixin/` ne sont déclarées dans aucune config → inertes
  elles aussi ; la doc le dit maintenant explicitement.
- **« Prepared 7 mixins »** (2 endroits de `LIRE-MOI-IMPORTANT.md`) remplacé par
  les valeurs réelles et vérifiables.
- **Bandeau `[SLB-V8]`** : la doc demandait de le vérifier « dans le log », mais
  `SlbDiagnostics` écrivait sur `System.out`, donc **dans aucun fichier de log** —
  consigne impossible à satisfaire. **Le code a été corrigé** (les 10
  `System.out.println` passent par le logger du mod) et la preuve est dans le
  log de test : `[12:30:56] [deepluckyblock.SlbDiagnostics/]: [SLB-V8] Deep
  Lucky Block v8 (2026-09-05) charge`.
- **`SMOOTH_PASSES = 3`** : constante morte (plus lue nulle part) alors que le
  pipeline fait 50 puis 12 passes, deux fois. Annotée `@Deprecated` avec renvoi
  vers `decorate()`.
- **Deux kits `FIXES_MCREATOR`** : aucun script ni code ne les consomme ; règle
  écrite : l'exemplaire de `mod_project/` fait foi.
- **Version du mod** en double (`build.gradle` et `neoforge.mods.toml`) :
  signalée, **non modifiée** (consigne : ne pas toucher `gradle.properties`
  sans accord). Décision à prendre par l'utilisateur.

---

## T10 — Cascades de gravité et de fluides neutralisées pendant l'édition ✅

**Commit :** `T10: neutralise les cascades (gravite + fluides) pendant l'edition + garde anti double-paste`

### Le besoin, mesuré sur NOS fichiers (pas une hypothèse)

Le guide externe avertit : pendant un gros edit, chaque bloc de gravité peut
partir en cascade (« colonne de 1000 gravel → 1000 FallingBlockEntity »).
Vérification faite en lisant la **palette NBT** de nos structures
(`tools/nbt_gravity_scan.py`, ajouté — un simple `grep "minecraft:sand"` est
faux, il compte aussi `sandstone`) :

| Structure | Blocs soumis à la gravité |
|---|---|
| shipdead | 59 987 sable |
| crimsonlake | 16 265 sable + 252 gravier |
| citadel | 440 gravier, 15 échafaudages, 8 dripstone, 3 enclumes |
| dragon | 324 poudre + 204 dripstone + 2 œufs |
| observatory | 67 poudre de béton verte |
| circus | 3 échafaudages |
| everest | 0 |

### Le correctif

- **`util/TerrainEditClamp.java` (nouveau)** : pendant toute la fenêtre
  d'édition (la zone tenue par `ChunkKeeper`), les ticks de bloc et de fluide
  **en attente dans la zone** sont annulés chaque tick via l'API vanilla
  `LevelTicks.clearArea(BoundingBox)` — donc **sans ajouter de mixin** (le guide
  proposait un mixin `ServerLevelMixin#tickFluid`). La fenêtre s'ouvre/ferme avec
  la zone, publie un bilan chiffré, et s'interrompt d'elle-même si l'API manque.
- **Garde anti double-paste** (`StructureTerrainPrep.PREP_STARTED`) : le rappel
  « onReady » (le paste) ne peut plus partir deux fois pour la même emprise.
- Le paste journalise désormais le nombre de blocs à gravité posés.

### Preuve

- Contrôle croisé indépendant : observatoire → `[STRUCT5] observatory en 27046ms
  (14972 blocs, **67 a gravite**)`, exactement le nombre trouvé par l'analyse NBT.
- Bilan de fenêtre publié dans le log. Le dernier test en jeu l'a produit dans sa
  version précédente (MSPT lisse) : `[DLB-CLAMP] fenetre fermee (fin de pipeline) :
  34 s de travail, 484 ticks, MSPT lisse moyen 2.6/pire 36.1, 0 tick(s) au-dela de
  50 ms`. La métrique a été remplacée ensuite par la **période de tick réelle**
  (temps entre deux passages du pilote), parce que le MSPT lissé du serveur ne
  voit pas les phases où le thread principal est accaparé : mesuré le 20/09,
  3,8 ms de MSPT « moyen » alors que le serveur tournait à ~2 TPS. Le nouveau
  format de ligne n'a pas encore été rejoué en jeu (il sortira au prochain
  spawn) — c'est le seul chiffre de ce changelog qui reste à confirmer.

## T11 — Fin du gel de placement (2,4 s) : la zone de recherche est pré-chargée ✅

**Commit :** `T11: pre-charge la zone de recherche avant le scan (fin du gel de 2,4 s)`

- **Mesure avant** (`run/logs/pre_T11_latest.log`, everest à `6000,90,6000`,
  terrain jamais généré) : `Can't keep up! Running **2387ms**` puis `**2263ms**`,
  entre « Taille : 174x123x278 » et « -> pos=… ».
- **Cause** : `findFlatArea()` mesure ses candidats sans générer, puis vérifie le
  meilleur en **forçant la génération du chunk** — le même mécanisme que le gel de
  19,2 s déjà corrigé par T9, mais **en amont** du pipeline donc hors de la zone
  pré-chargée par `prepZone()`.
- **Correctif** : `StructureTerrainPrep.preloadBox()` (pré-chargement par paquets,
  non bloquant, zone tenue jusqu'à la fin du post-traitement) appelé **avant** le
  scan de placement. La boîte est volontairement plafonnée
  (`preRing = min(88, max(|sx|,|sz|)/2 + 16)` = 11×11 chunks au plus) : le premier
  essai pré-chargeait le rayon de recherche complet (576 chunks) et faisait
  prendre **38,6 s de retard** au serveur ; plafonné, on revient à **16,8 s**
  pour une structure qui n'occupe que ~120 chunks.
- **Preuve** : plus aucun gel supérieur à 3,3 s ; le paste d'everest affiche
  `39.371s` puis `34.228s` sur zone neuve, sans Watchdog.

## T12 — Le défaut grave trouvé par l'audit : 40 % du terrain n'était plus traité ✅

**Commit :** `T12: garde la zone tenue pendant le paste (fin des colonnes sautees)`

- **Constat dans les logs de la session précédente** (`run/logs/t6t9_run3.log`) :
  `fixWaterNearStructure : 34452 colonnes sautées (chunk absent)`,
  `cleanupZone : 26653/27709 sautées`, `guardWaterEdges : 20901 sautées` — donc des
  **passes entières ne faisaient plus rien**, alors que le rapport de cette
  session annonçait « 0 colonne sautée ».
- **Cause** : pendant le paste (25-60 s), plus personne n'appelait
  `ChunkKeeper.keep()` → la zone se déchargeait → les passes suivantes trouvaient
  des chunks absents et sautaient leurs colonnes (règle « jamais de génération
  synchrone » oblige).
- **Correctif** : `ChunkKeeper.keep()` **à chaque tick du paste** (les deux
  `PasteJob`) et remplacement des `getChunk(..., true)` par bloc par
  `placeOne()` + `defer` / `retryDeferred()` : le bloc est **différé** au lieu de
  générer le chunk, avec rechargement forcé en **dernier recours après 30 s**
  (une structure ne doit jamais être trouée).
- **Preuve après** (observatoire à `400,90,400`, monde neuf, `run/logs/latest.log`) :
  **0 colonne sautée sur toutes les passes**, `decorate TERMINE` en **34,3 s**
  (contre 42,9 s avant), **0 exception**, `[DLB-CHUNKS] 210/210` puis zone rendue.

---

## T13 — Water dam **sans un seul bloc** : gel / dégel de l'eau (guide, section 27)

**Demande** : « ne pas oublier le water dam (Section 27 : bloquer naturellement
l'eau) ». Vérification faite dans le code : le mécanisme existant
(`placeWaterDams()`, `StructureTerrainPrep` l.973) construisait de **vraies
sphères de blocs** pour barrer l'eau — visibles en jeu, rapportées comme rendant
mal — et il était **désactivé** (commentaire l.309-329). Autrement dit : plus
aucun mécanisme ne traitait l'eau avant le remodelage du terrain.

**Ce qui a été fait** (meilleure version que le guide, pas une copie) :
- nouveau `util/WaterDam.java` : l'eau de la zone est **retirée** (aucun bloc
  posé) et son **état exact** mémorisé `(position, BlockState)` ; profondeur de
  scan 48 sous la surface, plafond 60 000 blocs, tranches de 192 colonnes /
  4 000 blocs avec **budget de 8 ms par tick** ;
- **branchement avant tout accès terrain** : `WaterDam.freeze()` au step 0/11 de
  `prepZone()` (juste après le pré-chargement, avant `scanTrees`), donc le
  smooth/carve/fill travaillent sur une zone **sèche** : aucune cascade, aucune
  eau suspendue, aucun barrage ;
- **restauration intelligente** à la fin de `decorate()` (après `cleanupZone`,
  avant les `release`) : source restituée **comme source** si c'en était une ou si
  la case est enclavée, sinon **descente au nouveau sol** (le smooth a pu creuser
  sous l'eau) ; **emprise de la structure exclue** (l'eau du NBT — fontaines,
  blocs *waterlogged* — n'est jamais écrasée) ; compteurs
  `restored / moved / dropped / skipped` ;
- le dégel se fait **fenêtre `DLB-CLAMP` encore ouverte** ⇒ les ticks de fluide
  restent neutralisés pendant la remise en place ;
- **S.39 du guide** (`/opti freeze`, `/opti unfreeze`) porté sur l'outil de test :
  `/dlbtest water freeze [rayon] | thaw | status` (T17).

**Preuve in-game (20/09, `TEST_T13_T16_2026-09-20.log`)** — deux niveaux :

1. test isolé, vérifié par commande (`execute if block`) :
```
[DLB-WATER] gel de l'eau sur la zone 49x49 (2401 colonnes, profondeur 48 sous la surface)
[DLB-WATER] eau gelee : 5243 blocs sur 2401 colonnes                       (0,6 s)
execute if block -5 61 -5 minecraft:air   -> The time is 1040              (l'eau a disparu)
[DLB-WATER] degel termine : 3601 remis en place, 1642 deplaces au nouveau sol,
                             0 abandonnes, 0 ignores
execute if block -5 61 -5 minecraft:water -> The time is 1161              (revenue AU MEME ENDROIT)
/dlbtest water status                     -> gel ACTIF, 8257 blocs / puis gel inactif, 0 bloc
```
2. **dans le pipeline complet** (observatoire, monde neuf, `@400`) :
```
[DLB-WATER] eau gelee : 34842 blocs sur 30589 colonnes                     (1,06 s)
[DLB-WATER] degel termine : 13146 blocs remis en place, 16420 deplaces au nouveau sol,
                             10 abandonnes (plus de support), 0 ignores (structure/bloc)
```

---

## T14 — Ordre d'écriture **par sections 16³ + spirale** (guide, sections 42/43)

**Demande** : « juger puis modifier les idées de paste plus rapides/compétentes ».
Le guide propose de ne plus écrire bloc par bloc dans l'ordre du fichier, mais
**par sections 16³**, et de traiter les sections **en spirale** autour du centre.

**Ce qui a été fait** : `orderBySectionSpiral(...)` dans `Structures4Procedure`
(remplace `orderByY` dans `doPaste`) et dans `Structures5Procedure` (remplace le
tri `filt`), + **cache de chunk par section** dans `PasteJob.placeOne()`
(`lastCx/lastCz/lastLoaded`, invalidé au retry). `orderByY` est conservé dans le
code (non appelé) pour pouvoir revenir en arrière en une ligne.
Clé de tri : section 16³ (X, Z, Y de section) → **distance² au centre** (spirale)
→ Y intra-section. Effet : le chunk n'est résolu **qu'une fois par section**
(au lieu d'une fois par bloc, soit ~15 000 résolutions) et deux blocs voisins
sont écrits dans le même tick même si le fichier les sépare.

**Preuve in-game** : everest (52 979 blocs) posé en **32,071 s** avec
post-traitement complet (chasse aux coffres, spawn des gardiens, etc.) ; log
`TEST_T13_T16_2026-09-20.log`. Aucune régression d'ordre visible (les passes
post-paste travaillent par colonnes, pas dans l'ordre de pose).

---

## T15 / T18 — Le pré-chargement ne gèle plus le serveur (sections 6, 30, 40)

**Défaut mesuré** : le 20/09 à 13:49, l'observatoire (monde **neuf**) est mort
par le chien de garde du jeu — `A single server tick took 60.08 seconds` →
arrêt forcé — **pendant le pré-chargement des chunks** : le repli forcé de
`preloadStep` générait jusqu'à 4 chunks **synchroniquement** dans un même tick.

**T15** : plafond dur à **2 générations par tick** (`PRELOAD_FORCE_PER_TICK=2`) et
seuil de repli porté à 600 ticks, avec log dédié.
**T18** : le **temps** pilote désormais le repli, plus seulement le nombre :
`PRELOAD_FORCE_BUDGET_MS = 900` — si deux générations dépassent le budget du
tick, le repli s'arrête pour ce tick (`repli force INTERROMPU par le budget de
tick (…) : la génération en tâche de fond continue, reprise au tick suivant`).
Sur une machine de bureau (~100-200 ms par chunk) le comportement reste celui de
T15 ; sur une machine lente ou un monde neuf, le tick reste borné.

**Preuve in-game** (même run que T13/T16, monde neuf) :
```
[DLB-LAGPROBE] periode de tick de 3791 ms pendant la phase « pre-chargement des chunks 0/169 »   (T15, mesure)
pre-chargement : termine (169 chunks)      puis prepZone 0/11 -- zone chargee
Can't keep up! Running 9045ms / 6224ms     (2 au total sur tout le run, aucun watchdog)
[DLB-CLAMP] fenetre fermee (fin de pipeline) : 41 s de travail, 630 ticks ;
            periode de tick moyenne 67 ms, pire 3069 ms
```
→ **le pipeline complet de l'observatoire sur monde neuf va au bout** (42,0 s).

---

## T16 — Fil rouge de phase, sonde de tick, **porte de stabilisation** (sections 30/31/45)

**Problème vécu** : un gel ne dit jamais *quelle phase* a mangé le thread
principal — le log s'arrête sur la dernière ligne écrite, et l'instrumentation
existante est en **fin** de phase, donc muette pendant l'accident.

**Ce qui a été fait** :
- `DebugLog.setPhase/phaseNow` : **fil rouge de phase** alimenté par `step()` et
  par chaque tranche des boucles découpées (`clearFootprint 12/60`,
  `cleanupZone 210/319`, `pre-chargement des chunks 144/169`…) ;
- **sonde de tick** `[DLB-LAGPROBE]` dans `TerrainEditClamp` : à chaque période
  de tick ≥ 1 500 ms, le log **nomme la phase en cours** (c'est cette sonde qui a
  désigné le pré-chargement comme responsable du gel → T18) ;
- `[DLB-STRUCTURE] l'étape qui vient de finir a pris N ms de temps REEL` :
  distingue la durée *cumulée* d'une passe de la **durée réelle** subie par le serveur ;
- nouveau `util/SettleGate.java` : **porte de stabilisation** en fin de pipeline
  (guide S.45) — la zone n'est rendue au chunk system que si les **entités de
  chute** sont retombées et si le **moteur de lumière** est au repos
  (2 ticks consécutifs), avec un plafond de 200 ticks et un log d'abandon.

**Preuve in-game** (chronologie réelle, monde neuf, extraite du log) :
```
[19,7 s] prepZone 0/11 : zone chargee, demarrage du pipeline
[21,9 s] prepZone 2/11 : prefillFoundation termine
[22,6 s] prepZone 3/11 : clearSurfaceDecor termine
[22,7 s] prepZone 4/11 : clearFootprint termine
[24,0 s] prepZone 8/11 : guardWaterEdges termine / 7/11 clearWaterPockets termine
[25,6 s] prepZone 5/11 : smooth 7x7 x50 termine
[28,2 s] prepZone 6/11 : smooth 15x15 x12 termine
[28,5 s] prepZone 10/11 : verifyGrassSurface termine
[29,0 s] prepZone 11/11 : cleanupZone termine
[29,3 s] prepZone 9/11 TERMINE -- pret pour le paste
[42,0 s] decorate TERMINE (failles, smooths, fuites, decors, arbres, naturalisation)
[DLB-SETTLE] zone stabilisee apres 2 tick(s) d'attente (0.1 s) : aucune entite
             de chute, moteur de lumiere au repos -- le terrain est REELLEMENT definitif
```

---

## T17 — `/dlbtest water freeze|thaw|status` (guide, section 39)

Commandes de pilotage manuel du gel/dégel, portées sur l'outil de test headless
(le guide les appelle `/opti freeze` / `/opti unfreeze`) : elles permettent de
**vérifier le water dam sans attendre une structure complète**, donc de
diagnostiquer vite en jeu. Preuve : séquence complète `freeze → status (gel ACTIF,
8 257 blocs) → thaw → status (gel inactif, 0 bloc)` dans `TEST_T13_T16_2026-09-20.log`.

---

## Bilan de la revue étape par étape

`REVUE_ETAPE_PAR_ETAPE_2026-09-20.md` (racine + `mod_project/`) : les 83 sections
du guide reprises une par une, avec pour chacune l'état réel dans le code
(✅ en place / 🆕 ajouté / 🟡 partiel / ⛔ écarté **avec sa raison**), plus la
grille des mesures et les commandes exactes pour rejouer chaque preuve.

---

## T19/T20/T21 — DÉFAUTS TROUVÉS DANS **TON** LOG DU 20/09 AU SOIR (17:03 → 17:29)

Log client fourni (`LOG_CLIENT_20SEP_SOIR.log`, 12 060 lignes, intégré au dépôt) +
12 captures. Trois défauts, tous **de mon fait** (T13), tous corrigés ici :

### T19 — L'eau n'était gelée qu'à moitié, puis **reconstruite** au dégel

```
[17:03:36] [DLB-WATER] eau gelee : 60000 blocs sur 14463 colonnes (PLAFOND ATTEINT : le reste de l'eau n'est pas gele)
```
- **Plafond de 60 000 blocs atteint** : sur les **30 589 colonnes** de la zone, seules
  **14 463** avaient été gelées → **16 126 colonnes d'eau sont restées en place** et
  ont été traversées par le remodelage du terrain (eau suspendue, décalée, en mur).
- Au dégel : `14871 blocs remis en place, 40520 deplaces au nouveau sol, 70 abandonnes`
  puis `15490 remis, 33604 deplaces` — **l'ancien dégel reconstruisait l'eau** : toute
  case dont le bloc du dessous était plein était promue en **source** (une source ne
  s'écoule jamais → **mur d'eau vertical permanent**, visible sur tes captures), et
  l'eau sans support était **déplacée au « nouveau sol »** (40 520 blocs dans un run).

**Corrigé** : plafond porté à 1 000 000 de blocs (12 octets/bloc = 12 Mo transitoires,
le plafond ne sert plus qu'à empêcher une dérive absurde) ; le dégel restitue
**l'état d'origine exact à la position d'origine** — plus de promotion en source, plus
de déplacement, les niveaux d'eau d'origine se stabilisent seuls (les ticks de fluide
ne sont pas concernés par le gel).

### T20 — Le gel passait **avant** le lissage : le rivage était aspiré de 20 blocs

```
[17:09:45] [STRUCT5] dragon : ecart de sol avant/apres smooth = -20 blocs (63 -> 43)
[17:04:38] [STRUCT5] observatory : sol de l'emprise irregulier apres smooth (median=49 contre 63 au centre)
[17:03:29] [DLB-STRUCTURE] l'etape qui vient de finir a pris 11652 ms de temps REEL (prepZone 2/11 : prefillFoundation)
```
Parce que T13 gelait l'eau **avant** `scanTrees`/lissage, la heightmap voyait le
**fond de l'océan** (Y≈43) à la place de sa **surface** (Y≈63) : le flou mélangeait
ce fond avec la terre ferme → **crateres plats, falaises vives en bord de zone et
rivages creusés** (visible sur les captures 2, 4, 5, 6, 11, 12).

**Corrigé** : les colonnes qui contenaient de l'eau sont **exclues du lissage** (elles
gardent leur hauteur, ne tirent plus le rivage vers le bas, et ne sont ni floutées ni
reconstruites). Preuve de mon run de contrôle (même cas, monde neuf) :
`smooth 181x169 : 6279 colonnes d'eau exclues du lissage`.

### T21 — Le lissage pouvait déplacer le terrain de **60 blocs** : garde-fou + mesure

Nouvelle instrumentation indispensable pour voir le problème :
```
lissage : derive maximale 36 / 58 / 60 blocs (colonne 33,0 de la zone) avant bridage
```
Le flou (7x7 x50 puis 15x15 x12, dans `prep` **et** dans `decorate`) pouvait
**recreuser le paysage de plusieurs dizaines de blocs**, et rien ne le bornait.

**Corrigé** :
1. **référence « terrain naturel » mémorisée une fois par zone** (avant le premier
   lissage) : toutes les passes restent à **≤ 8 blocs** de cette référence, emprise
   de la structure et plans d'eau exceptés (l'aplanissement voulu sous le bâtiment
   reste libre) ;
2. **mesure finale publiée** à chaque structure : écart du terrain livré vs terrain
   naturel, hors emprise et hors eau.

**Preuve (run de contrôle du 21/09, observatoire @400, monde neuf)** :
```
terrain naturel memorise sur 181x169 en 235,236 -- toutes les passes de lissage resteront a moins de 8 blocs
lissage bride : 12180 colonne(s) s'ecartaient de plus de 8 blocs du terrain NATUREL (derive max 56, colonne 269,237)
[DLB-WATER] degel termine : 29975 blocs d'eau restitues a leur position EXACTE, 0 recouverts, 4867 ignores (emprise)
terrain final vs terrain NATUREL : ecart moyen 5.82 blocs, maximal 56 (en 331,312),
      31 % des colonnes a 2 blocs ou moins, 205 colonnes au-dela de la borne de 8
[DLB-SETTLE] zone stabilisee apres 2 tick(s) d'attente -- le terrain est REELLEMENT definitif
[48.8 s] decorate TERMINE -- pipeline complet, aucune mort par watchdog
```
Les 205 colonnes au-delà de la borne sont **localisées** (talus sous la structure et
bord de zone) et désormais **comptées et nommées** : c'est la prochaine cible
(chapitre « Reste ouvert »).

**Commits** — voir `COMMITS_A_APPLIQUER_2026-09-20.md` (sections T19, T20, T21) ;
build de contrôle : `BUILD SUCCESSFUL`, jar **8 836 120 octets (21/09 17:27)**.

---

## T22 — Le dégel de l'eau s'**auto-étrangle** (mesure en jeu du 21/09)

**Ce qui s'est passé** : j'ai relancé le serveur et déclenché une **deuxième**
structure sur un monde **déjà remodelé**. La sonde a mesuré des ticks de
**13 004 / 12 909 / 13 625 ms** puis le chien de garde a tué le serveur
(`A single server tick took 60.20 seconds`) — sous le libellé « cleanupZone
29568/30589 », **périmé** : la phase réelle était le **dégel** (33 551 blocs
d'eau reposés), qui n'étiquetait pas sa phase. Chaque `setBlock` d'eau déclenche
une vérification du moteur de lumière ; sur une zone retaillée deux fois, ces
vérifications saturent le thread principal.

**Corrigé (T22)** :
- **étiquetage de tous les points de reprise** : `gel de l'eau i/N`,
  `degel de l'eau i/N (etrangle xN)`, `stabilisation puis relachement des chunks`
  → la prochaine fois, `[DLB-LAGPROBE]` nomme la **vraie** phase (c'est ce qui a
  manqué ici) ;
- **auto-étranglement** du gel et du dégel : les tranches regardent l'écart réel
  entre deux passages ; si le tick dépasse **200 ms**, la tranche suivante est
  **reportée** (1 à 10 ticks) au lieu d'être demandée à chaque tick, avec un
  WARN explicite ; les tranches passent de 4 000 à **2 000 blocs** et le budget
  de 8 à **4 ms**.

**Preuve — même commande, monde neuf, jar T22** (démo lancée depuis le panneau) :
```
[DLB-WATER] debut du degel : 34187 blocs d'eau memorises
[DLB-WATER] degel termine : 29108 blocs d'eau restitues a leur position EXACTE,
                            0 recouverts, 5079 ignores (emprise de la structure)
terrain final vs terrain NATUREL : ecart moyen 5.86 blocs, maximal 57,
                            32 % des colonnes a 2 blocs ou moins
[DLB-SETTLE] zone stabilisee apres 2 tick(s) d'attente (0.1 s)
[40.4 s] decorate TERMINE -- pipeline complet, AUCUNE mort par watchdog
```
Build de contrôle : `BUILD SUCCESSFUL`, jar **8 836 893 octets (21/09 17:38)**.

---

## T23 — Réponse aux 16 remarques du joueur (pseudo **Dev**) : plus d'eau touchée, plus de cratères, plus de végétaux volants

Source : `LOG_CLIENT_20SEP_SOIR.log` (12 060 l.) + 12 captures. Détail point par point :
`CAHIER_DEV_16_REMARQUES_2026-09-21.md`. Run de validation : `TEST_T23_2026-09-21.log`.

### 1. L'eau n'est **plus jamais** touchée (remarques « barrage d'eau », « eau pas update », « eau en murs »)

Le pipeline **retire puis reposait** 34 000 blocs d'eau (T13) : c'est ce qui produisait
les murs d'eau, les trous et les blocs figés que tu as vus. **T23 supprime le gel et le
dégel du pipeline** : `WaterDam.freeze`/`thaw` ne sont plus appelés (le code reste
disponible pour la commande de diagnostic `/dlbtest water`). Le relief est désormais
retravaillé **autour** des plans d'eau, qui sont exclus du lissage (T20).

**Preuve** : **0 ligne `[DLB-WATER]`** dans le run de validation complet (avant :
34 187 blocs gelés puis 29 108 reposés).

### 2. Plus de cratères : lissage **asymétrique** (+10 / −2)

Mesure nouvelle sur ton monde : le flou déplaçait le terrain de **jusqu'à 60 blocs**.
Le lissage peut maintenant **remblayer de 10 blocs au maximum** et ne peut **plus
creuser que de 2 blocs** sous le terrain naturel.

**Preuve (même cas, monde neuf)** :
```
terrain final vs terrain NATUREL : ecart moyen 2.34 blocs, maximal 56 (en 327,308),
   85 % des colonnes a 2 blocs ou moins, 68 colonnes au-dela de la borne (+10/-2)
   -- dont 751 CREUSEE(S) de plus de 1 bloc (pire : -6) et 111 REMBLAYEE(S) (pire : +56)
```
Avant : écart moyen **5,86**, 32 % dans la tolérance, 218 colonnes hors borne,
lissage dérivant jusqu'à **−20 blocs** (`[STRUCT5] dragon : ecart de sol … 63 -> 43`).

### 3. Fin des végétaux volants (remarques « cocoa qui volent », « bamboos, vignes qui volent »)

Nouvelle passe `sweepFloatingDecor` : par colonne, on part de la surface et on monte ;
tant que la chaîne est continue, les végétaux sont **posés** (conservés) ; dès qu'un
vide apparaît, tout végétal au-dessus est **retiré** (cacao, vignes, bambous, feuilles,
plantes orphelines). Elle tourne **avant** les finitions de `decorate`.

**Preuve** : `balayage des vegetaux flottants : 11 041 bloc(s) de nature retires`
(4 725 colonnes, 345 ms).

### 4. Les structures à terrain désactivé sont **quand même** nettoyées (remarque « arbres dans mon cirque »)

`circus` et `shipdead` posent leur bâtiment **sans modifier le terrain** : aucun
nettoyage n'avait lieu, d'où les arbres au milieu du cirque. Un job de **nettoyage
végétal** (rayon 3 blocs autour de chaque bloc de la structure, blocs de la structure
exclus) tourne désormais même dans ce mode.

### Bilan du run de validation T23 (observatoire @400, monde neuf)

```
[DLB-STRUCTURE] balayage des vegetaux flottants : 11041 bloc(s) retires
[DLB-STRUCTURE] terrain final vs terrain NATUREL : ecart moyen 2.34, 85 % <= 2 blocs
[DLB-SETTLE]    zone stabilisee apres 2 tick(s) -- le terrain est REELLEMENT definitif
[33.5 s] decorate TERMINE          (avant : 40,4 s ; 250,6 s sur la machine du joueur)
0 ligne [DLB-WATER]  |  0 exception  |  aucune mort par watchdog
```
Build : `BUILD SUCCESSFUL`, jar **8 838 342 octets (21/09 18:34)**.
Le jar est **aussi copié dans `mod_project/jar/`** : le dossier `build/` n'est pas
conservé entre deux sessions de l'espace de travail, `jar/` l'est.

---

## T24/T25 — Terrasses supprimées, débris flottants retirés (analyse des **images** du 20/09)

Deuxième passe sur les 12 captures : au-delà de ce que tu m'avais écrit, elles montrent
des **escaliers de terre** (amphithéâtre) autour des structures, des **îlots d'herbe et
blocs de terre suspendus**, des **vignes en plein ciel**, et de l'**eau figée en
escalier** (héritage du gel/dégel, déjà supprimé en T23 — plus aucune écriture dans
l'eau, `0 ligne [DLB-WATER]`).

### T24 — Limitation de pente (fin des terrasses)

`rebuildColumn` coupait chaque colonne à **sa** hauteur : deux colonnes voisines
pouvaient différer de **10 à 56 blocs** → parois verticales successives = les terrasses.
Nouvelle passe `limitSlope` : relaxation sur les 4 voisins, **2 blocs maximum** entre
colonnes voisines, 14 itérations, **emprise de la structure et plans d'eau exclus**
(le plateau du bâtiment est voulu), puis re-application de la fenêtre du lissage pour
rester cohérent.

**Preuve** : `pentes : plus grand ecart entre deux colonnes voisines ramene de 11 bloc(s)
a 25` (le 11 est mesuré **hors emprise** ; avant, ce chiffre montait à **56**),
~5 000 cellules adoucies par passe, sur 4 passes.

### T25 — Débris flottants (herbe, terre, sable) et emprise intouchable

Le balayage T23 ne regardait que le végétal et s'arrêtait 24 blocs au-dessus de la
surface. Il retire désormais aussi les **matériaux meubles flottants** (herbe, terre,
sable, gravier, neige, argile, mousse…) — jamais la pierre, les minerais ou les
terracottas (un surplomb rocheux est un relief légitime) — monte jusqu'à **+48 blocs**,
et **ne touche jamais l'emprise de la structure**.

### Bilan mesuré (observatoire @400, monde neuf, jar T25)

| Indicateur | Début de session | Maintenant |
|---|---|---|
| Écart moyen au terrain naturel | 5,86 blocs | **2,45 blocs** |
| Colonnes à ≤ 2 blocs | 32 % | **89 %** |
| Pire creusage | −20 blocs | **−11** |
| Écart max entre 2 colonnes voisines (hors emprise) | 56 blocs | **11** avant limitation, ~2 visé après relaxation |
| Durée du pipeline complet | 250,6 s (machine du joueur) / 40,4 s (bac à sable) | **34,0 s** |
| Écritures dans l'eau | 34 187 blocs gelés puis 29 108 reposés | **0** |
| Mort par watchdog | oui (20/09 17:36) | **aucune** |

Build : `BUILD SUCCESSFUL`, jar **8 839 381 octets (21/09 19:32)** — également copié
dans `mod_project/jar/` (le dossier `build/` n'est pas conservé entre deux sessions).

---

## Reste à faire (ordre validé T1→T5)

- **T3** — ✅ FAIT (voir ci-dessus) : pipeline terrain validé de bout en bout sur serveur dédié.
- **T4** — ✅ FAIT (voir ci-dessus) : les 7 points du §7 de `RAPPORT_ETAPE0.md` sont traités ; `DOC_ALIGNEMENT_T4_2026-09-20.md` détaille chaque point avec sa preuve. Reste **une décision utilisateur** : la version du mod écrite à deux endroits (`build.gradle` + `neoforge.mods.toml`).
- **T7** — ✅ FAIT (voir ci-dessus) : NBT des grosses structures chargé hors tick + cause racine des placements ratés (heightmap non initialisée) corrigée dans `SafeSurface`, avec preuves en jeu (everest 200,61,200 ; observatory baseY=63 ; 8 colonnes fantômes sur 30 589).
- **T6** — ✅ FAIT (voir ci-dessus) : verrou `TerrainChain` + découpage en tranches de `fillGapsAndSteps` (`GapStepPass`) et de `sealWaterLeaks` (`SealLeaksPass`).
- **T9** — ✅ FAIT (voir ci-dessus) : zone tenue en mémoire (`ChunkKeeper`), pré-chargement non bloquant, budget adaptatif, **cause racine du gel corrigée** (`SanctuarySpawnerEquipProcedure`, 29 791 lectures de blocs par mob → scan sûr sans génération), et tri explicite de ce qui a été retenu/écarté du guide externe.
- **T10** — ✅ FAIT (voir ci-dessus) : cascades de gravité et de fluides neutralisées pendant l'édition (`TerrainEditClamp`, sans mixin) + garde anti double-paste.
- **T11** — ✅ FAIT (voir ci-dessus) : la zone de recherche est pré-chargée avant le scan de placement → plus de gel de 2,4 s.
- **T12** — ✅ FAIT (voir ci-dessus) : zone tenue pendant le paste + blocs différés → **plus aucune colonne sautée** (le défaut trouvé par l'audit).
- **Audit du guide v2** — ✅ FAIT : `AUDIT_COUVERTURE_GUIDE_2026-09-20.md` (83 sections, retenu / déjà en place / écarté avec raison).
- **T13** — ✅ FAIT : water dam **sans blocs** (gel/dégel intelligent de l'eau, guide S.27) — prouvé en jeu (34 842 blocs gelés / 30 589 colonnes, dégel 13 146 remis + 16 420 déplacés).
- **T14** — ✅ FAIT : paste **ordonné par sections 16³ en spirale** (S.42/43) + cache de chunk par section — everest 52 979 blocs en 32,071 s.
- **T15/T18** — ✅ FAIT : le pré-chargement ne gèle plus le serveur (plafond 2 générations/tick puis **budget de tick** 900 ms) — pipeline complet sur **monde neuf** qui va au bout (42,0 s).
- **T16** — ✅ FAIT : **fil rouge de phase** + **sonde `[DLB-LAGPROBE]`** (nomme la phase responsable) + **porte de stabilisation** `SettleGate` en fin de pipeline.
- **T17** — ✅ FAIT : `/dlbtest water freeze|thaw|status` (S.39) pour vérifier le water dam à la demande.
- **Revue étape par étape** — ✅ FAIT : `REVUE_ETAPE_PAR_ETAPE_2026-09-20.md`.
- **T24/T25** — ✅ FAIT : limitation de pente (fin des terrasses en escalier) + retrait des débris de terrain flottants (herbe/terre/sable suspendus), emprise intouchable → **89 %** des colonnes à ≤ 2 blocs du terrain naturel.
- **T23** — ✅ FAIT : eau plus jamais touchée, lissage asymétrique (+10/−2), balayage des végétaux flottants (11 041 blocs), nettoyage végétal des structures à terrain désactivé → mesure finale **2,34 blocs d'écart moyen** (avant 5,86).
- **T22** — ✅ FAIT : dégel auto-étranglé + étiquetage de toutes les phases (la sonde nomme enfin la vraie phase) — pipeline complet en 40,4 s après correction.
- **T19/T20/T21** — ✅ FAIT (défauts vus dans le log client du 20/09 au soir) : water dam complet (plus de plafond à 60 000), dégel **exact** (plus de murs d'eau), colonnes d'eau **exclues du lissage** (plus de rivage creusé de 20 blocs), **garde-fou d'amplitude** du lissage (≤ 8 blocs vs terrain naturel) + **mesure finale** publiée à chaque structure.


---

## T26 — TERRAIN D'ABORD, STRUCTURE À LA FIN (consigne « applanir d'abord ») ✅

**Commit :** `T26: terrain rendu definitif AVANT le paste (fin des lissages post-paste qui recreusaient le pourtour)`

### Consigne (verbatim, log client du 20/09)
> « et tu est sencé d'abord tout retirer et applanir, et metre la grosse structure a la FIN, une fois que le terrain est parfait »
> « la wtf tu le fais desle debut »
> « ce qui cause le terrain collé a la structure de ne pas etre smoothé et ducoup mal rendre »

### Ce qui a été fait
- `StructureTerrainPrep.TERRAIN_FIRST = true` + méthode `postPasteSmooth(...)` : les **deux** lissages qui tournaient **après** la pose (dans `decorate()`, 7x7 x50 puis 15x15 x12, à deux endroits) sont **sautés**. Le terrain est donc définitif quand la structure se pose ; les finitions post-paste (carve, décors, naturalisation, replant, stabilisation) ne le remodèlent plus.
- Marge d'ancrage réduite de **4 blocs à 1 bloc** (`anchorMargin`) : « le terrain collé à la structure » était justement la bande laissée brute autour des murs.
- Retour en arrière possible d'une seule ligne (le paramètre existe), mais l'ancien ordre est abandonné.

### Preuve en jeu (`TEST_T26_T31_2026-09-21.log`, 21/09 23:02)
```
[DLB-STRUCTURE] [12.8 s] lissage post-paste 7x7 x50 SAUTE (T26 : terrain deja definitif, consigne « applanir d'abord, structure a la fin »)
[DLB-STRUCTURE] [12.8 s] lissage post-paste 15x15 x12 SAUTE (T26 ...)
[DLB-STRUCTURE] [14.0 s] decorate TERMINE (failles, smooths, fuites, decors, arbres, naturalisation)
[DLB-STRUCTURE] terrain final vs terrain NATUREL : ecart moyen 2.08 blocs, maximal 35, 77 % <= 2, 11 colonnes au-dela de la borne
[DLB-CLAMP] fenetre fermee (fin de pipeline) : 14 s de travail, 285 ticks ; periode de tick moyenne 49 ms, pire 276 ms ; 0 watchdog
```
**Durée totale : 34,0 s → 14,0 s** (les deux grosses passes post-paste ne sont plus payées deux fois).

---

## T27 — AUCUNE STRUCTURE NE S'IMPLANTE DANS UNE AUTRE ✅

**Commit :** `T27: registre d'emprises (StructureSites) -- une structure ne se pose plus dans une autre`

### Consigne
> « les structures … faire en sorte qu'ils n'arrivent pas dans ou sur nos structure » (log client, pseudo Dev)

### Ce qui a été fait
- Nouveau `util/StructureSites.java` : registre **en mémoire, par niveau** des emprises posées (rectangle XZ + marge de 24 blocs).
- L'emprise est enregistrée **avant** la pose (donc une structure qui démarrerait pendant le paste la voit déjà).
- Recherche de site : tout candidat qui chevauche une emprise occupée est **rejeté**, exactement comme un chunk de joueur (`Structures5Procedure`), et l'emprise est vérifiée dans le chemin `Structures4Procedure`.
- Mesure du 21/09 22:46 : le circus s'était posé à `340,311`, soit **dans** l'emprise de l'observatoire (262..369 x 263..358) → traité par le garde-fou du T29.

### Preuve en jeu (21/09 23:02-23:03)
```
[DLB-SITES] emprise enregistree : observatory (107x95 a 262,263), 1 structure(s) suivie(s)
[DLB-SITES] emprise enregistree : observatory (107x95 a 227,415), 2 structure(s) suivie(s)
[DLB-SITES] emprise enregistree : everest (241x345 a 376,424), 3 structure(s) suivie(s)
```

---

## T28 — L'EVEREST S'ENFONCE DANS LE TERRAIN ✅

**Commit :** `T28: everest enfonce de 6 blocs dans le terrain + emprise enregistree`

### Consigne
> « l'everest etait sencé s'enfocer dans le terrain » (log client, 17h15)

### Ce qui a été fait
- `EVEREST_SINK_BLOCKS` (dans `Structures4Procedure`, **à côté** des autres valeurs d'enfoncement forcé de ce fichier) : la montagne est posée plus bas que l'offset historique → sa base entre réellement dans le relief au lieu de poser sa galette sur l'herbe.
- **Valeur : 6 blocs au premier essai, portée à 10 blocs le 22/09 sur décision de l'utilisateur** (`EVEREST_SINK_BLOCKS = 10;   // 22/09 : 6 -> 10`).
- Formule rappelée : `Y = baseY + EVEREST_OFFSET_Y - minRelY - EVEREST_SINK_BLOCKS`.

### Preuve en jeu
```
[STRUCT4-EVEREST] enfoncement de 10 bloc(s) dans le terrain (T28)
[STRUCT4-EVEREST] EVEREST TERMINÉ en 4.332s (52979 blocs)
```

---

## T29 — LA POSITION LIBRE EST CHERCHÉE **AVANT** LA LECTURE DE HAUTEUR ET AVANT LE PRÉ-CHARGEMENT ✅

**Commit :** `T29: garde-fou d'emprise au point de passage commun (freeOffset) -- couvre les chemins de repli`

### Pourquoi (mesure en jeu du 21/09 22:46)
Les 2 boucles de recherche filtrent les candidats occupés, mais **trois chemins de repli les contournent** :
« repli sur la pente minimale brute », « plus loin chargé », « hors chunk de joueur ».
Résultat mesuré : le circus s'est posé **dans** l'emprise de l'observatoire (`340,311` vs `262..369 x 263..358`).

### Ce qui a été fait
- `StructureSites.freeOffset(level, pos, rings, step)` : décalage en spirale (8 anneaux de 32 blocs, 6 x 48 pour l'everest) jusqu'à une place libre.
- Appelé **au point de passage commun** des deux pipelines, **avant** `SafeSurface.surfaceY(...)` (donc `baseY` correspond au site réel) et **avant** `prepZone`/`preloadBox` (donc la boîte pré-chargée est la bonne).
- Si aucune place n'existe dans la fenêtre : `WARN` explicite + pose à l'emplacement prévu.

### Preuve en jeu
```
[DLB-SITES] 275, 68, 405 : position occupee par 'observatory' -> deplacement de 32 bloc(s) vers 243,437 (anneau 1, T27)
[DLB-SITES] 400, 66, 400 : position occupee par 'observatory' -> deplacement de 48 bloc(s) vers 400,448 (anneau 1, T27)
```

---

## T30 — PRÉ-CHARGEMENT DE L'EMPRISE FINALE DE L'EVEREST ✅

**Commit :** `T30: everest -- prechargement de l'emprise finale avant la pose (fin du tick de 10,4 s)`

### Mesure qui a motivé le correctif (21/09 22:58)
```
[STRUCT4-EVEREST] EVEREST TERMINÉ en 15.567s (52979 blocs)
[DLB-LAGPROBE] periode de tick de 10386 ms pendant la phase « pre-chargement des chunks 168/169 »
```
La boîte pré-chargée au début de `spawnEverest` est celle de **l'origine** ; la position finale peut être ailleurs (T29, `EVEREST_DISTANCE`). Les chunks manquants étaient donc générés par `getChunk(..., require=true)` **depuis la boucle de pose** → génération synchrone sur le serveur = gel de 10,4 s. Les structures génériques passent par `prepZone`→`preloadBox` (T9/T17) ; l'everest a son propre chemin (`EverestJob`) et n'en bénéficiait pas.

### Correctif
Re-pré-chargement de l'emprise **finale** (même `preRing`, plafonné à 88 blocs) **avant** que le premier bloc ne tombe.

### Preuve en jeu (23:03)
```
[STRUCT4-EVEREST] EVEREST TERMINÉ en 4.332s (52979 blocs)
[DLB-CLAMP] fenetre fermee (fin de pipeline) : 5 s de travail, 115 ticks ; periode de tick moyenne 50 ms, pire 243 ms ; 2 tick(s) > 100 ms
```
**15,567 s → 4,332 s** et **pire tick 10 386 ms → 243 ms**.

---

## T31 — « INCASSABLE » SUR LE BO CUBE DE BOIS (FR + EN) ✅

**Commit :** `T31: ligne « Incassable » dans la description du Bo Cube De Bois (fr + en)`

### Consigne (message `<Dev>` retrouvé dans `arena-conversation.json`)
> « pour le bo cube de bois, il faut dans la description tout en bas ajouter "incassable", et aussi faire en sorte que tous mes items, descriptions, mobs etc, soient aussi traduit en anglais si on met le jeu en anglais »

- Le bloc **était déjà** incassable (`strength(-1, 3600000)` = dureté −1) : il manquait la ligne de description.
- Ajout de `block.deep_lucky_block.bo_cube_de_bois.description_1` = **« Incassable »** (fr) / **« Unbreakable »** (en) + affichage dans `appendHoverText`.
- Vérification du reste : `en_us.json` (1 813 clés) est bien de l'anglais rédigé (52 clés identiques au français = noms propres).

---

## AUDIT EXHAUSTIF DES COMMENTAIRES `<Dev>` + NUMÉROTATION CONTINUE T0 → T31 ✅

**Commit :** `docs: audit exhaustif des 53 commentaires <Dev> (logs client + arena-conversation.json) et numerotation continue T0-T31`

### Deux défauts de documentation corrigés ce soir (vérifiés sur pièces)
1. **Comptage faux** : le nombre de commentaires `<Dev>` annoncé (55) était faux. Recomptage strict sur `uploads/arena-conversation.json` : **153 lignes `<Dev>`, 37 messages distincts** (dont 2 fragments d'un même message). Avec les **16** du log client du 20/09 → **53 commentaires** au total, tous listés avec traitement + preuve dans
   `AUDIT_EXHAUSTIF_DEV_T0_T32_2026-09-22.md`.
2. **Numérotation à trous** : une version intermédiaire de ce document citait « T30/T31/T33 » sans que ces tâches existent, et les numéros T29/T32/T34 n'avaient jamais été attribués. La passe est désormais **contiguë de T0 à T31** : T26 (terrain d'abord), T27 (emprises), T28 (everest enfoncé), T29 (position libre avant pré-chargement), T30 (pré-chargement de l'emprise finale), T31 (Incassable). Aucun numéro manquant, aucune tâche fantôme.

---

## T28 (mise à jour) — ENFONCEMENT DE L'EVEREST PORTÉ À **10 BLOCS** ✅

**Commit :** `T28: everest -- enfoncement porte a 10 blocs (choix utilisateur du 22/09)`

- Décision utilisateur du 22/09 (retour sur l'essai à 6 blocs) : `EVEREST_SINK_BLOCKS = 10`
  (`Structures4Procedure`, une ligne, à côté des autres valeurs d'enfoncement forcé).
- Rebuild : **`BUILD SUCCESSFUL in 21s`**, `build/libs/deep_lucky_block-1.0.jar` (8 844 139 o).

### Preuve en jeu (`TEST_T28_T32_2026-09-22.log`, 22/09 00:01)
```
[STRUCT4-EVEREST] enfoncement de 10 bloc(s) dans le terrain (T28)
[DLB-SITES] emprise enregistree : everest (241x345 a 376,376)
[STRUCT4-EVEREST] EVEREST TERMINÉ en 8.696s (52979 blocs)
```

---

## T32 — L'EVEREST PRÉ-CHARGE **TOUTE SON EMPRISE** (fin du gel pendant le paste) ✅

**Commit :** `T32: everest -- boite de pre-chargement dimensionnee sur l'emprise reelle (88 -> 164 blocs)`

### Mesure qui a motivé le correctif (22/09 00:01, après T30)
```
[DLB-LAGPROBE] periode de tick de 4211 ms pendant la phase « pre-chargement des chunks 168/169 »
[STRUCT4-EVEREST] EVEREST TERMINÉ en 8.696s (52979 blocs)
```
Le plafond de **88 blocs** (choix du T11) vise la zone de **recherche** des structures génériques ;
l'everest, lui, mesure **192 x 296 blocs**. Au-delà de ±88, les chunks n'étaient pas épinglés et se
généraient **pendant la pose** (`getChunk(..., require=true)`, bloc par bloc) → gel de 4,2 s.

### Correctif
- `EVEREST_PRELOAD_MAX_RING = 176` + rayon effectif = `max(largeur, profondeur)/2 + 16` = **164 blocs**
  → boîte **327 x 327 (484 chunks)**, très en dessous du `MAX_PINNED` de `ChunkKeeper`.
- La phase est ré-étiquetée (`paste everest (blocs)`) après le pré-chargement, pour que la sonde
  `LAGPROBE` n'attribue plus les ralentissements suivants au pré-chargement (faux diagnostic observé).

### Preuve en jeu (22/09 00:05)
```
[DLB-STRUCTURE] preloadBox : pre-chargement non bloquant de 327x327 blocs (484 chunks) avant le scan de placement
[STRUCT4-EVEREST] enfoncement de 10 bloc(s) dans le terrain (T28)
[STRUCT4-EVEREST] EVEREST TERMINÉ en 14.518s (52979 blocs)
[DLB-CLAMP] fenetre fermee (fin de pipeline) : 15 s de travail, 271 ticks ; periode de tick moyenne 58 ms, pire 2050 ms
```
**Plus aucun gel pendant la pose** : le pire tick (2 050 ms) tombe pendant la **génération** des 484 chunks
neufs (phase pré-chargée, découpée), et non plus pendant l'écriture de la structure.
Sur un monde déjà visité (chunks existants), cette phase est quasi gratuite — mesuré 243 ms au run précédent.

---

## T33 — Retour in-game du 22/09 : fin du gel de pose + sélection de zone + passes de terrain finales

**Contexte (log `runClient` du joueur, view/sim 17)** : everest posé en **61,051 s** avec
**LAGPROBE 36 824 ms pendant `paste everest (blocs)`**, 644 demandes de chargement résiduelles ;
dragon 21,6 s (« pas mal, peu de lag ») ; circus 1 658 ms. 19 nouveaux messages `<Dev>`.

### 1. Gel de l'everest : cause trouvée et supprimée (3 correctifs)

| Cause | Preuve | Correctif |
|---|---|---|
| `getChunkSource().getChunk(..., true)` — **génération de chunk SYNCHRONE bloc par bloc** dans la boucle Everest | 644 demandes de chargement dans le log client, 36 824 ms sur un tick | le chunk est demandé en **tâche de fond** (`ChunkStatus.FULL`, `creation=false`) ; si le chunk n'est pas prêt, le bloc est **mis de côté** (`EverestJob.defer`) et reposé par `retryDeferredEverest()` — mécanique T12 portée sur l'everest |
| Quota de blocs par tick sans borne de **temps** (`BLOCKS_PER_TICK = 25 000`, `EVEREST_BLOCKS_PER_TICK = 100 000`) | pire tick sandbox 2 050 ms | `PASTE_TICK_BUDGET_MS = 40 ms` (S4 **et** S5) : la boucle s'arrête sur le temps, pas sur un nombre ; `EVEREST_TICK_TIMEOUT_MS` 300 → 90 ms |
| Pré-chargement qui annonçait « terminé » alors que des chunks n'étaient **pas au statut complet** (`isLoaded` plus permissif que `getChunkNow`) | 644 / 435 demandes de chargement pendant le paste | `PRELOAD_VERIFY_EXTRA_TICKS = 200` : le pré-chargement vérifie `getChunkNow()` sur les 484 chunks avant d'annoncer « terminé » (re-demande non bloquante, 10 s max) |

**Preuve in-game (test serveur, `run/logs/t34_run1.log`)** :
`pre-chargement : termine (484 chunks, 0 pas encore au statut complet)` puis
`everest : 7004 bloc(s) reposes apres chargement de la zone (0 restants, 2 ticks d'attente)` et
**`EVEREST TERMINÉ en 15.754s`** (au lieu de 45,276 s au run t33b et **61,051 s en jeu**) ; aucun
tick > 1 s pendant la pose (le seul pic restant, 3 384 ms, est la **génération** des chunks neufs,
qui n'existe pas sur un monde déjà visité).

### 2. « Le programme qui sélectionne la zone plate est HS »

Cause : les centaines de `REJETE : emprise 'everest'` **vidaient la liste des candidats plats**, et le
sélecteur retombait sur le repli « le moins pentu » — une zone médiocre, alors que le candidat rejeté
était réellement plat. Correctifs : un chevauchement d'emprise **décale** désormais le candidat le long
de la spirale libre (`StructureSites.freeOffset`, T29) au lieu de le jeter, et le budget passe de
**12 à 24 candidats** vérifiés (le budget de temps `FIND_FLAT_TIME_BUDGET_MS` reste la vraie borne).
**Preuve** : `[STRUCT5-FLAT] Zone choisie a -5,-5 (candidat #1/24) : flat=90%, pente=12`.

### 3. Passe finale de terrain, sur le SOL uniquement, vraiment EN DERNIER

`finalGroundPass(level, min, max, ring = 6)` : analyse **vue de haut, chunk par chunk** (une seule
lecture de hauteur par colonne + descente bornée à 6 blocs), puis **en global** comparaison de chaque
colonne à la **médiane de ses 8 voisines** — uniquement pour les colonnes de **terrain sol naturel**
(eau, arbres, décors et bâti exclus). Une **cuvette** (majorité de voisines plus hautes) est comblée,
une **saillie** (ligne / bloc singulier trop haut, au moins 7/8 voisines plus basses) est rabotée ;
**écart maximal 2 blocs**, jamais de gros terrassement, aucun trou créé (`rebuildColumn`).
La passe tourne après l'eau et les berges, juste avant `clearFootprintProtection()`.
Budgets : analyse 120 ms / correction 150 ms (au-delà, la passe s'arrête et le dit — jamais de gel).

**Preuve** : `passe finale terrain : vue de haut 30 chunks (744 colonnes de sol analysables) sur 59x71
-- emprise + 6 blocs, ecart max 2` puis `61 colonnes retouchees sur 744 examinees en 4 ms
(39 cuvettes comblees, 22 saillies rabotees)`.

Correction en cours de route : la 1re version descendait **bloc par bloc** des colonnes entières
(jusqu'à ~300 lectures pour une colonne d'eau) → **tick de 60 s + watchdog** au run t33b. Réécrite en
lecture de hauteur O(1) + descente bornée.

### 4. Berges d'eau : remontées, forme sphère/axium + dam, vérification et retry

`raiseBank()` remplace le mur d'un bloc : empreinte en **losange `|dx|+|dz| <= 2`** (projection au sol
d'une sphère, « forme sphère / axium »), hauteur **décroissante d'un bloc par anneau** (`eau + 3` au
1er anneau, `eau + 2` au second, donc les **1-2 blocs de plus** demandés en jeu), jamais posée dans
l'eau. Après la pose, `leaksAt()` revérifie que l'eau ne peut plus partir : sinon **`BANK_RETRIES = 2`
renforcements** avant d'abandonner en le signalant.
**Preuve** : `guardWaterEdges (anti-chute d'eau, APRES smooth) : 267 blocs de berge places` (puis 32
et 5 lors des rappels), sans aucune fuite signalée.

### Résultat du run de validation (`run/logs/t34_run3.log`, observatory, pipeline COMPLET)

```
pre-chargement : termine (132 chunks, 0 pas encore au statut complet)
prepZone 11/11 TERMINE -- pret pour le paste
fillCrevasses : 442 colonnes de ravin comblees      (puis 247 au rappel)
pentes : plus grand ecart ramene de 53 a 42 (limite 2) -- 11 146 cellules adoucies
fillGapsAndSteps : 265 blocs de faille combles, 5 561 blocs de marche adoucis
guardWaterEdges : 267 blocs de berge places
passe finale terrain : 61 colonnes retouchees (39 cuvettes comblees, 22 saillies rabotees)
decorate TERMINE (14.9 s)
[DLB-CLAMP] 288 ticks ; periode de tick moyenne 52 ms, PIRE 373 ms, 0 tick > 1 s
```

Aucun watchdog, aucun OOM, aucune exception pendant les trois runs de la passe.

### Reste à vérifier en jeu (transparence)

`terrain final vs terrain NATUREL` signale encore **687 colonnes creusées de plus de 1 bloc
(pire : -41)** sur un échantillon de 1 978 colonnes : ces creux sont hérités du carve / des passes
d'eau (plus profonds que la règle « 2 blocs » de la passe finale, qui ne corrige que l'écart ≤ 2
autour de la médiane des voisines) et doivent être confirmés (ou infirmés) à l'œil en jeu.

---

## T35 — Les trous profonds sont rebouchés (creux de plus de 2 blocs)

Le run de validation de T33/T34 signalait encore **687 colonnes creusées de plus de 1 bloc
(pire : -41)** : des trous hérités du carve, **plus profonds que la règle « écart max 2 blocs »**
de la passe finale, donc jamais corrigés. Consigne `<Dev>` : « refill les holes puis smooth ».

`correctFinalColumn` comble désormais un **trou profond** quand il est **isolé** (au moins 7 des 8
voisines plus hautes — un ravin ou une vallée large a des voisines basses et n'est donc pas touché)
et le remonte **jusqu'à la médiane des voisines**, jamais au-dessus : le trou est comblé à niveau,
aucune tour n'est créée. Profondeur bornée à `FINAL_MAX_HOLE_FILL = 48` blocs et puits artificiels
(écart avec la heightmap) exclus, pour ne jamais reboucher une mine ou une grotte volontaire.
Les saillies profondes (> 2 blocs) ne sont **jamais** rabotées : c'est du relief réel.

**Preuve** (`run/logs/t37_run2.log`) : `3 TROUS PROFONDS rebouches sur 3 detectes`.

## T36 — L'everest et le circus ne recevaient AUCUN travail de terrain

Découverte en relisant les logs : `spawnEverest` n'appelle **ni `prepZone` ni `decorate`** — il pose
ses blocs « brut » (sink de 10 blocs), et le circus/shipdead est en `skipTerrain` (« modif terrain
DESACTIVEE »). Résultat : **ni berges, ni crevasses, ni passe finale** là où le joueur les voit le
plus. `StructureTerrainPrep.finalTerrainPass()` est désormais appelée à la fin de leur post-process
(`PostJob.terrainFinal`), soit la toute dernière opération sur le terrain, exactement comme dans le
pipeline complet.

## T37 — Pré-chargement calé sur l'emprise réelle + passe finale étalée sur plusieurs ticks

Deux défauts révélés par le run t36_run2 :

1. **La boîte de pré-chargement de l'everest était centrée sur le point d'ancrage** (327×327 pour
   un rayon de 155 blocs) alors que le paste couvre `rotatedPos → +taille` (emprise réelle
   **191×295**) : la bande de Z au-delà de +155 n'était pas épinglée, d'où **435 demandes de
   chargement PENDANT la pose** et un tick de **9 145 ms**. La position finale est maintenant
   calculée AVANT le pré-chargement, et c'est **exactement l'emprise** qui est pré-chargée.
2. **La passe finale était plafonnée par un budget de 120/150 ms** : `analyse vue de haut
   interrompue par le budget de 120 ms apres 14 chunks` — elle ne couvrait qu'une fraction de
   l'emprise de l'everest. Elle est désormais **répartie sur plusieurs ticks** (`FINAL_SLICE_MS =
   40 ms` puis replanification par `TestProcedure.schedule`) : aucun tick bloqué et la zone est
   analysée **en entier**.

Correction complémentaire (T37b) : quand l'analyse se terminait dans le tick courant, l'enchaînement
sortait **avant la correction** (`0 colonnes retouchees sur 0 examinees` alors que 3 853 colonnes
venaient d'être analysées). Analyse et correction s'enchaînent maintenant dans le même tick.

### Validation (`run/logs/t37_run2.log`, everest)

```
preloadBox : pre-chargement non bloquant de 191x295 blocs (247 chunks)   <- emprise REELLE
(pre-chargement : termine (247 chunks, 0 pas encore au statut complet))
(aucune « demande de chargement » pendant la phase de pose)
EVEREST TERMINÉ en 14.632s (52979 blocs)
passe finale terrain : vue de haut 247 chunks (3853 colonnes de sol analysables) sur 187x291
passe finale terrain : 88 colonnes retouchees sur 3853 examinees en 30 ms et 1 tick(s)
        (41 cuvettes comblees, 44 saillies rabotees, 3 TROUS PROFONDS rebouches sur 3 detectes)
[DLB-CLAMP] pire 3 473 ms -- et ce pic est la GENERATION des chunks neufs du pre-chargement,
            plus rien pendant la pose
```

Chronologie du gel de l'everest sur cette passe : **61,051 s en jeu → 45,3 s (T33) → 35,9 s (T35/T36)
→ 21,2 s (T37) → 14,6 s (T37b)**, avec disparition complète des demandes de chargement pendant la
pose.

### T38 — Revalidation de T37 sur serveur redémarré (rien de neuf dans le code)

Run `run/logs/t38_run1.log`, everest, machine relancée à froid :
`preloadBox 191x295 (247 chunks)` puis **EVEREST TERMINÉ en 50.534s** et — c'est le point qui
compte — **aucune ligne `LAGPROBE` pendant la phase « paste everest (blocs) »** : plus aucune
demande de chargement pendant la pose (contre 644 en jeu le 22/09 et 435 avant T37).
Passe finale : `70 colonnes retouchees sur 3692 examinees (21 cuvettes, 34 saillies,
15 TROUS PROFONDS rebouches sur 15 detectes)`.

Le total (50,5 s) est plus élevé que les 14,6 s du run précédent : les pics restants
(5 529 et 1 568 ms) tombent pendant la **génération des 484 chunks** du pré-scan, phase de
génération de terrain pur qui dépend du disque et du CPU (2 cœurs et 2 Go de RAM ici) et qui
n'existe pratiquement pas sur un monde déjà visité comme le tien.


---

# T38 → T45 — 23/09/2026 (retour en jeu : 13 remarques `<Dev>`)

Source : log `runClient` du 23/09 01:45 → 02:16 (everest 164 s en jeu, citadel, dragon, shipdead).
Les 13 remarques du dev sont listées dans `AUDIT_EXHAUSTIF_DEV_T0_T34_2026-09-22.md` §10.

## T38 — `/fixwater` + `/fixlava` réimplémentés (eau **et** lave)

**Demande** : « tu dois absolument faire un `/fixwater 1000` … au niveau du dernier bloc le plus
haut d'eau du fleuve … qui ont été freezés, afin de re remplir » ; « toute la nouvelle zone vide
prévue à la continuité du lac, sur tous les chunks reliés à l'eau et sans bloc » ; « fait de même
pour le fixlava, inclus le même système que pour l'eau ».

**Ce que fait la vraie commande** (7 recherches web ciblées, sources EngineHub 7.4 / FAWE /
WorldEdit-BE / wiki BadWolfMC / r/Minecraft) : `/fixwater <rayon>` remplace les blocs d'eau
*flowing* par des blocs **source** (stationnaires) dans le rayon, s'étend sur le liquide connecté
et « remplit toute cuvette jusqu'au niveau du plus haut bloc source ». `/fixlava` est l'identique.

**Implémentation** (`StructureTerrainPrep.fixLiquidsPass` + `LiquidJob`, aucune dépendance) :
1. parcourt les chunks **chargés** dans un rayon de 1000 blocs autour du centre de l'emprise
   (les chunks absents sont ignorés : aucune génération synchrone, c'est la cause du gel de 60 s
   du run t33b) ; convertit *flowing* → *source* pour l'eau ET la lave ;
2. mémorise le niveau du plus haut bloc d'eau / de lave de chaque colonne, puis **propage ce
   niveau** en largeur (BFS 4 directions, budget 40 ms/tick) pour remplir les cuvettes vides
   reliées au plan d'eau. Garde-fous : creux ≤ 12 blocs, sol naturel uniquement, plafonds
   40 000 blocs d'eau / 4 000 blocs de lave, aucune colonne non chargée.

**Preuve** : run `t45_run1` → la passe tourne dans le pipeline (`fixLiquids 1/2 : 210 chunks
chargés … fixLiquids TERMINÉ … 266 ms`) ; le monde de test de la sandbox n'a pas d'eau à
l'endroit testé (0 colonne), la conversion est donc exercée à vide — à confirmer dans ton monde
(le dev a explicitement demandé le « re remplir » du fleuve). Le format de log bogué du 1er run a
été corrigé (T43).

## T39 — la structure passe **EN ABSOLU DERNIER** (+ T43 / T44)

**Demande** : « ÉNORME erreur : la structure doit paste en absolu dernier, après tous les
smooths », « ne plus jamais smoother par-dessus la structure ».

**Avant** : `prepZone (11 étapes)` → **PASTE** → carve → `decorate (smooths + passe finale)` → post.
**Après** : `prepZone (11 étapes)` → `decorateTerrainOnly` (failles, double smooth, eau, berges,
**hole filler**, **balayage**, **passe finale**, **/fixwater + /fixlava**) → **PASTE** → carve →
`decorateFinish` (décors, arbres, naturalisation) → post.

- `StructureTerrainPrep` : `decorate()` devient `decorateChain(...)` avec deux entrées publiques
  `decorateTerrainOnly(level, min, max, afterTerrain)` et `decorateFinish(level, min, max)` ;
  la passe finale est désormais **attendue** (rappel de fin) avant de rendre la main ;
  `decorate()` (chaîne complète) est conservé pour l'appel historique (lac de crimson).
- `Structures5Procedure` : le paste est offert **depuis la fin de la phase terrain**.
- `Structures4Procedure` : idem pour `prepZone`+`offerPaste`, pour l'everest et pour le repli
  « NBT vide » ; la passe finale de terrain T36 qui tournait **après** la pose est supprimée
  (`PostJob.terrainFinal` n'est plus jamais vrai ; un WARN le signale si un appel oublié subsiste).

**T43 (correctif)** : après 40 s de travail de terrain, la pose réclamait 160 chunks restés
déchargés (ticks de 2 064 et 7 283 ms mesurés au run `t39_run1`). L'emprise du paste est
**re-scellée** (`preloadBox`) juste avant la pose → run `t44_run1` : **plus aucune demande de
chargement pendant la pose** (paste de l'observatoire en ~1 s après la fin du terrain).
**T44 (correctif)** : la phase terrain devait **rendre la chaîne terrain** avant le paste, sinon
`decorateFinish` se reportait indéfiniment (« chaîne terrain occupée par structure?@-3,-9 »).

**Preuve** (run `t44_run1`, observatoire id 1) :
`[35,6 s] decorate TERRAIN TERMINÉ : terrain figé, la structure peut être posée (T39)` →
`[STRUCT5] observatory en 42208ms` → `decorateFinish (POST-POSE)` → `scatter … 9/9 décors` →
`[62,5 s] decorate TERMINÉ (… structure posée en DERNIER, T39)`. Aucun smooth après la pose.

## T40 — hole filler : tunnels, failles et cavités rebouchés

**Demande** : « je vois encore des tunnels, des failles etc dans mon terrain et qui n'ont pas été
re remplis ! » → « copie pareil … hole filler minecraft ».

**Implémentation** (`sealUndergroundGaps` / `sealColumn` / `fillPocket`) : par colonne, du sommet
jusqu'à 64 blocs ; toute **poche d'air encadrée par un plafond et un plancher solides** est
rebouchée avec le **matériau du plancher** (règle des hole fillers : « remplir avec les matériaux
qui entourent le trou »), pierre à défaut. Plafonds : 24 blocs par poche, 250 000 blocs par
structure (T43 : 60 000 était atteint sur la 1re structure), poche ouverte vers le bas = jamais
comblée (on ne noie pas une vallée). Passe découpée en tranches (384 colonnes/tick).

**Preuve** : `hole filler TERMINÉ : 14 013 poches rebouchées, 82 140 blocs` (obs, t43_run1) ;
`10 457 poches / 55 122 blocs` (obs, t45_run1) ; `50 708 poches / 250 000 blocs` (everest, t44_run2).

## T41 — balayage étendu : lianes volantes + blocs naturels en suspension (+ T45)

**Demande** : « je vois encore des lianes qui volent ! wtf ?? » ; « d'autres entités du même genre
flotter ».

**Cause trouvée** : le balayage T23/T25 n'était branché que dans `decorate()` (donc **jamais**
dans le chemin « paste brut » everest/circus où le dev regardait) et s'arrêtait à 8 blocs de
l'emprise. **T41** ajoute `sweepFloatingNaturalPass` : anneau COMPLET (`terrainRing()`), fenêtre
bornée (`surface +48 / −10`, coût O(60)/colonne), remontée depuis le sol, suppression de tout
décor naturel non porté, accroche latérale acceptée pour lianes/lichen/racines. Branché sur les
**deux** chemins, en dernière étape du terrain avant la pose.

**T45 (correctif, trouvé au run t44_run2)** : la règle « plus relié au sol » tondait les
**canopées légitimes** (70 602 blocs « flottants » sur un monde neuf = bords de feuillages en
porte-à-faux). Désormais un décor non relié au sol n'est supprimé que si **son amas entier**
flotte (exploration 6 directions, plafond 512 blocs, amas ancrés mémorisés) : canopées
intactes, lianes/îlots/res­tes de l'ancien terrain supprimés.

**Preuve** : `balayage étendu TERMINÉ : 2 312 blocs naturels flottants retirés sur 30 589
colonnes` (obs, t45_run1 — chiffres réalistes après T45).

## T42 — mini-structures décoratives plaquées au sol

**Demande** : « certaines mini-structures décoratives (uniquement elles) flottent de 1-2 blocs
au-dessus du sol → les plaquer au sol ».

**Deux causes** : (1) l'ancre de pose était le Y de la surface, pas le **plus bas bloc réel** du
schematic (un rocher/une ruine dont la 1re couche est partiellement vide se retrouvait perché) ;
(2) la passe finale de terrain pouvait encore **raboter le sol sous un décor déjà posé**
(`FINAL_MAX_DELTA = 2` blocs — exactement le « 1-2 blocs » observé). Correctif : origine calée sur
`minLocalY(template)`, et après pose **chaque colonne est plaquée** (le vide sous le décor est
comblé avec le matériau du sol, 4 blocs max). Log dédié : `scatter [thème] : T42 -- N colonnes
de décors plaquées au sol`. (2) est définitivement réglé par T39, qui attend la fin de la passe
finale avant de laisser poser le moindre décor.

**Preuve** : `scatter [OBSERVATORY] : T42 -- 1 colonne de décors plaquée au sol` (obs, t44_run1),
`0 colonne` (obs, t45_run1).

## Runs de validation (sandbox, 2 vCPU / 2 Go)

| run | structure | résultat clé |
|---|---|---|
| t39_run1 | obs (id 1) | ordre T39 vérifié ; **2 défauts trouvés** : 160 demandes de chargement pendant la pose (→ T43), chaîne terrain jamais rendue (→ T44) |
| t43_run1 | obs (id 1) | everest lancé ensuite → **watchdog 60 s pendant le pré-chargement des 484 chunks** puis OOM 137 (limite sandbox) |
| t44_run1 | obs (id 1) | pipeline complet : terrain 35,6 s → paste → décors → `decorate TERMINÉ` ; T44 OK |
| t44_run2 | everest (id 5, monde neuf) | ordre complet vérifié : balayage → hole filler → passe finale → fixliquids → pré-chargement → paste → **EVEREST TERMINÉ en 50,764 s** ; T45 nécessaire (70 602 blocs tondus) |
| t45_run1 | obs (id 1) | **pipeline complet OK en 15,3 s** (terrain + pose), 0 LAGPROBE, 11 décors, T42/T45 OK |
| t45_run2 | everest (monde neuf) | pré-chargement des 247 chunks neufs > watchdog 60 s sur cette machine 2 vCPU (le même pré-chargement a pris 15,3 s de pire tick **chez toi**) → validation everest non reproductible ici après T45 |

**Résiduel assumé** : le pré-chargement des chunks NEUFS de l'emprise everest reste le seul pic
(c'est la génération de terrain pur : 484 + 247 chunks) ; sur ton monde déjà visité il n'existe
pratiquement pas (mesure en jeu du 22/09 : everest 14,6 s après T37).

---

## T46 — Pré-chargement borné dans le temps et parallèle : « max 1 minute total » ✅

**Commit :** `T46: pre-chargement des chunks borne (25 s) et parallele + pre-chauffage pendant l'annonce`

### Ce que tu as constaté en jeu (23/09 au soir, log 02:23 → 02:48)

```
c'est completement abusé le temps de chargement !! normalement c'est max 1mn total !
la on parle de quasi 1h a attendre WTF
```

Extraits du log :

```
[DLB-CHUNKS] zone -255,78,2194 -> 138,313,2625 (700 chunks) epinglee 02:24:35 -> 02:25:05
[DLB-CLAMP]  fenetre 394x306x432
pre-chargement 406x444 = 783 chunks :   0/783 a 02:24:35 ... 120/783 (02:34:23) ...
                                       161/783 (02:38:39) ... 199/783 a 02:48 (toujours en cours)
Can't keep up! Running 2000 -> 26381 ms
zone tenue en memoire depuis 600 s sans fin de pipeline -- relachee par garde-fou
```

➡️ **24 minutes** pour ~200 chunks sur 783, soit **~2 chunks toutes les 30 s**. Le pipeline n'avait
même pas encore commencé : le pré-chargement, à lui seul, consommait tout le budget d'1 minute.

### Les trois causes cumulées (toutes dans le code, aucune n'est « la faute du PC »)

| # | Cause | Où | Effet mesuré |
|---|---|---|---|
| 1 | `ChunkKeeper.keep()` ne demandait le chargement que de la **TÊTE** de sa liste (`REQUEST_PER_TICK = 4` chunks, toujours les mêmes). Tant qu'un chunk de tête traînait, **aucune autre demande n'était émise** → aucune génération en parallèle | `util/ChunkKeeper.java` | 1 à 2 chunks livrés / 30 s |
| 2 | `preloadStep()` n'avançait que sur un **curseur contigu** : un seul chunk capricieux (typiquement dans la couronne extérieure, que le ChunkKeeper ne demandait même pas puisque sa zone était légèrement plus petite) **gelait le compteur** alors que des centaines de chunks étaient déjà chargés | `StructureTerrainPrep.preloadStep` | compteur bloqué à 0/783 puis 120/783… alors que la zone se chargeait |
| 3 | **Aucune borne de temps** : le pipeline ne démarrait qu'à **100 % de la zone**. Sur un monde neuf, 783 chunks **vierges** ne peuvent pas être générés en 1 minute sur un PC de jeu (c'est de la génération de terrain pur, multithread côté moteur, mais borné par le CPU) | `StructureTerrainPrep.preloadStep` | attente infinie + `Can't keep up` 26 s |

Défaut aggravant : `SMOOTH_RING` était calculé **après** le `ChunkKeeper.track()`, donc le maintien en
mémoire utilisait le ring de la structure **précédente** pendant que le pré-chargement calculait le
nouveau ring → la couronne attendue par le pré-chargement n'était demandée par personne.

### Les correctifs

**A. `ChunkKeeper` — demandes réparties (round-robin) et débit adapté aux cœurs**

```java
int budget = Math.min(REQUEST_PER_TICK, MAX_IN_FLIGHT - z.inFlight);
int n = z.pending.size();
if (z.reqCursor >= n) z.reqCursor = 0;
for (int i = 0; i < budget; i++) {
    ChunkPos cp = z.pending.get(z.reqCursor % n);
    z.reqCursor = (z.reqCursor + 1) % n;
    if (level.getChunkSource().getChunkNow(cp.x, cp.z) != null) continue;  // déjà chargé : rien à demander
    level.getChunkSource().getChunkFuture(cp.x, cp.z, ChunkStatus.FULL, true).whenComplete(...);
}
```

* `REQUEST_PER_TICK = min(64, max(8, CPUS * 8))`, `MAX_IN_FLIGHT = min(192, max(8, CPUS * 12))`,
  `PIN_PER_TICK = 12`.
* Les demandes passent par **`getChunkFuture`** : ce n'est **pas bloquant**, c'est la génération qui est
  parallèle. Le gel historique venait des générations **synchrones**, pas du nombre de demandes.
* Chaque chunk de la zone finit par être demandé (avant : seulement les 4-16 premiers).

**B. `StructureTerrainPrep` — COUVERTURE au lieu du curseur contigu + budgets de temps**

| Constante | Valeur | Rôle |
|---|---|---|
| `PRELOAD_CORE_MARGIN` | 48 blocs | le **cœur** = emprise + 48 blocs : la seule zone qu'on ATTEND |
| `PRELOAD_CORE_BUDGET_MS` | 20 000 | attente max du cœur |
| `PRELOAD_RING_BUDGET_MS` | 8 000 | attente max de l'anneau, une fois le cœur prêt |
| `PRELOAD_TOTAL_BUDGET_MS` | 25 000 | plafond absolu (utilisé aussi par `preloadBox` / T43) |
| `PRELOAD_CORE_FORCE_AFTER_MS` | 12 000 | après ce délai, repli **synchrone sur le cœur uniquement, 1 chunk par tick** |
| `PRELOAD_REPORT_MS` | 5 000 | cadence des lignes d'avancement |

* Progression = **nombre de chunks chargés** (plus de curseur) → un chunk isolé ne bloque plus le compte.
* Zones **cœur / anneau** : dès que le cœur est complet, on n'attend plus (log dédié).
* Budget atteint ⇒ le pipeline **démarre quand même** : les passes sautent les colonnes absentes
  (`isLoaded`) et **T43 re-scelle l'emprise du paste** juste avant la pose → aucune génération
  synchrone n'est déclenchée par le pipeline lui-même.
* `SMOOTH_RING` est calculé **avant** `ChunkKeeper.track()` : maintien en mémoire et pré-chargement
  portent enfin sur la même boîte.

**C. Crimson Lake — pré-chauffage pendant les 60 s d'annonce**

```java
long startTick = level.getServer().getTickCount() + BUILD_START_DELAY_TICKS;
PENDING.add(new PendingBuild(level, pos.getX(), pos.getY(), pos.getZ(), startTick));
StructureTerrainPrep.warmZone(level, wMin, wMax, 80);   // T46
```

* `warmZone()` = `ChunkKeeper.warmOnly(...)` (**génération sans maintien en mémoire** : sinon 750+
  chunks seraient épinglés d'avance et le tas exploserait) + relance des demandes **toutes les 10
  ticks pendant 90 s** (le compte à rebours en dure 60).
* L'annonce « la construction démarre dans 60 s » devient **utile** : les chunks vierges se génèrent
  pendant que le joueur recule, pendant que le tick tourne normalement.
* Le `ChunkKeeper.pinEnabled` repasse à `true` dès qu'un pipeline normal démarre.

**D. Repli synchrone réservé au cœur, 1 chunk/tick** (il pouvait auparavant générer 20 s d'un coup
dans un seul tick — c'est ce qui a produit le watchdog de `t45_run2`).

### Preuves (sandbox 2 vCPU — sur ton PC, multi-cœurs, c'est plus rapide)

| Test | Avant | Après T46 |
|---|---|---|
| observatory, 156 chunks **neufs** | — | **8,884 s** (`coeur 156/156, zone 156/156`) |
| observatory, relance même monde | 15,3 s de pré-chargement à l'ancienne politique | **0,215 s** |
| everest, anneau 484 chunks (déjà visités) | > watchdog 60 s (t45_run2) | **25,36 s** puis pipeline (budget atteint : 225/484 chargés, 259 sautés proprement) |
| everest, `preloadBox` 247 chunks avant paste | 60 s + watchdog | **4,967 s** |
| everest, total | non finissable | **pré-charge 25 s + pipeline 35,7 s** ; `Post-process de everest terminé` |

Le `Can't keep up` résiduel de la sandbox (6 à 15 s) correspond au travail du pipeline lui-même
(52 979 blocs pastés + hole filler) sur **2 vCPU** ; il était de 26,381 s et **bloquait** l'événement.

### Effet attendu chez toi

| Étape | Avant (23/09) | Attendu (T46) |
|---|---|---|
| annonce « construction dans 60 s » | chunks non demandés | **zone en cours de génération** |
| pré-chargement zone lac (783 chunks) | 24 min sans finir | **≤ 25 s** (anneau non bloquant) |
| pipeline complet lac | jamais atteint | **~40-60 s** après l'annonce |

### Fichiers

* `src/main/java/deepluckyblock/util/ChunkKeeper.java`
* `src/main/java/deepluckyblock/procedures/StructureTerrainPrep.java`
* `src/main/java/deepluckyblock/procedures/CrimsonLakeStructureSpawnProcedure.java`

### Risque résiduel

* Sur un monde **100 % neuf**, une très grosse zone (au-delà de ~500 chunks vierges) ne peut pas être
  **entièrement** générée en 25 s : on démarre alors avec ce qui est chargé (log explicite). Le T43
  re-scelle l'emprise du paste, donc la structure, elle, est toujours posée sur des chunks chargés.
* Le garde-fou `HOLD_TIMEOUT` du ChunkKeeper (600 s) n'est plus atteignable : le pipeline complet
  tient maintenant en ≤ 60 s.

---

## T47 — « revois tout pour désactiver ce qui nous fait perdre du temps » : mesure + budgets adaptatifs ✅

**Commit :** `T47: chronometrage [DLB-PERF] du pipeline + budgets adaptatifs + fin du blocage synchrone sur zone geante`

### Le log du 23/09 (02:23 → 02:48) relu ligne à ligne

| Ce que dit le log | Ce que ça veut dire vraiment |
|---|---|
| `[DLB-CHUNKS] 700/700 chunks épinglés` à 02:25:05 (30 s après le début) | **les chunks SE CHARGEAIENT bien** |
| `pre-chargement : 0/783` répété de 02:24:35 à 02:25:39 puis +2 toutes les 30 s | le **compteur** était faux (il comptait une couronne que personne ne demandait) : il ne voyait pas les 700 chunks déjà en mémoire |
| `repli forcé borné à 2/tick` puis `+2 chunks / 30 s` | le repli appelait `getChunk(cx, cz, FULL, true)` = **génération SYNCHRONE** : ~15 s de blocage par chunk |
| `Can't keep up! Running 26381ms` (02:25:18) | conséquence directe du point précédent : le thread serveur était bloqué 26 s d'affilée |
| `[[DLB-CHUNKS]] zone tenue 600 s sans fin de pipeline — relâchée par garde-fou` | aucune borne de temps : le pipeline attendait 100 % d'une zone de 783 chunks |

**Conclusion : ce n'était ni ta machine ni la génération de terrain — c'était le mod qui attendait
un compteur faux et qui, au lieu de demander les chunks en tâche de fond, les générait un par un
sur le thread principal.**

### T47-A — Chronométrage `[DLB-PERF]` : où passent les secondes

Une seule ligne, en fin de pipeline, classe les phases par durée :

```
[DLB-PERF] TACHE COMPLETE en 31.6 s -- ou est passe le temps : pre-chargement des chunks 23.2 s (73%) |
balayage etendu des naturels flottants (lian 1.4 s (4%) | hole filler (tunnels / failles / cavites) 0.7 s (2%) |
fixLiquids 0.1 s (0%) | paste everest (blocs) 0.0 s (0%) | attente/tick system 6.2 s
```

Plus jamais besoin de deviner : la prochaine lenteur sera nommée avec sa durée et son pourcentage.

### T47-B — Budgets adaptatifs (zone géante > 512 chunks)

| Constante | Zone normale (≤ 512 chunks) | Zone géante (> 512, ex. lac = 783) |
|---|---|---|
| attente du cœur | 20 s | **12 s** |
| attente de l'anneau | 8 s | **4 s** |
| plafond absolu | 25 s | **15 s** |
| repli synchrone (blocage) | autorisé | **INTERDIT** |

Sur une zone géante, bloquer le thread serveur coûte ~15 s par chunk (mesure in-game) : les demandes
asynchrones génèrent en parallèle, elles seules sont rapides. Le repli reste possible sur une petite
zone, où il ne porte que sur quelques chunks.

### Preuves (sandbox 2 vCPU, monde neuf — donc les chunks sont générés pour de vrai)

| Structure | Pré-chargement | Total pipeline | Détail `[DLB-PERF]` |
|---|---|---|---|
| observatory (132 chunks neufs) | **7,667 s** (zone complète) | **16,3 s** | pré-chargement 7,2 s (44 %), reste = passes de terrain et décors |
| everest (484 chunks neufs + 247 pour le paste) | 24,5 s puis 4,2 s | **31,6 s** | pré-chargement 23,2 s (73 %) — c'est de la génération de terrain pur, en parallèle |

Sur ton PC (plusieurs cœurs), la même génération est nettement plus rapide : c'est exactement ce
travail qui prenait 24 minutes dans ton log.

---

## T48 — Crimson Lake : pose sans blocage + ordre T39 enfin respecté ✅

**Commit :** `T48: crimsonlake - pose sans generation synchrone (blocs differes) + ordre T39 (terrain d'abord, structure en dernier)`

Deux défauts majeurs restaient **propres au lac** (les autres structures étaient déjà corrigées) :

### 1. La pose bloquait le thread serveur, bloc par bloc

```java
// AVANT (CrimsonLake, pour CHAQUE bloc) :
j.level.getChunkSource().getChunk(bp.getX() >> 4, bp.getZ() >> 4, true);   // FULL synchrone !
```

À comparer avec les autres structures, qui différaient les blocs (`Structures5.placeOne`) au lieu de
bloquer. Mesure in-game : ~15 s par chunk, 2 chunks / 30 s, `Can't keep up! Running 26381ms`.

```java
// APRES (T48) :
if (!placeCrimsonOne(j, i, rs, bp)) j.defer.add(i);   // chunk absent -> DIFFERE
```

`placeCrimsonOne()` n'appelle plus jamais de chargement bloquant : si le chunk n'est pas en mémoire
le bloc part dans une liste `defer`, la demande a déjà été faite en tâche de fond (`ChunkKeeper`), et
le bloc est reposé au tick suivant (passe de rattrapage, budget 40 ms/tick). Le job ne se termine que
quand `defer` est vide — aucun bloc n'est perdu, et le tick ne dépasse jamais 40 ms de pose.

### 2. Le lac était le DERNIER chemin à appeler `decorate()` après la pose

```
AVANT : prepZone -> PASTE -> decorate()        (toute la chaine terrain APRES la structure)
APRES : prepZone -> decorateTerrainOnly() -> preloadBox -> PASTE -> decorateFinish()
```

C'est exactement l'« ÉNORME erreur » signalée le 23/09 (« la structure doit paste en absolu dernier,
après tous les smooths ») : le lac relançait double smooth, failles, eau, hole filler, balayage et
passe finale **par-dessus la structure déjà posée**, sur 783 chunks. Désormais le lac suit le même
schéma que les autres structures : **terrain figé (T39) → pose → finitions seules** (`decorateFinish`).

### Fichiers

* `src/main/java/deepluckyblock/procedures/CrimsonLakeStructureSpawnProcedure.java`

### À vérifier chez toi (c'est le test qui compte)

1. Lancer l'événement **Crimson Lake** et chronométrer : annonce 60 s (les chunks se génèrent
   pendant ce temps) puis construction. Attendu : **≤ 3-5 min au total**, contre ~1 h.
2. Regarder la ligne `[DLB-PERF]` : elle dit où sont passées les secondes. Si le pré-chargement
   dépasse 15 s, il y a encore quelque chose à corriger — envoie-moi cette ligne.
3. Vérifier que la structure n'est plus retouchée après la pose : `decorate TERRAIN TERMINÉ
   (… terrain figé …)` doit arriver AVANT le paste, et la fin doit être `decorate TERMINÉ
   (… structure posée en DERNIER, T39)`.

### Risque résiduel

* Si un chunk de l'emprise n'est jamais chargé (mémoire insuffisante), les blocs concernés restent en
  `defer` : le job attend au lieu de bloquer le serveur (log toutes les 100 ticks :
  `CrimsonLake PASTE : N bloc(s) en attente de chunk`). Envoie-moi cette ligne si tu la vois.

---

## T49 — ZÉRO génération synchrone dans les chemins chauds ✅

**Commit :** `T49: zero generation synchrone dans tous les chemins chauds (mesure puis generation differee)`

### La cause racine, enfin identifiée dans le log in-game du 23/09

Le log ne montrait pas « un mod lent » : il montrait **un seul appel** qui gèle le thread
serveur — `getChunk(cx, cz, FULL, true)`. Sur un monde neuf, une génération FULL attend la
cascade de ses voisins : **~15 s de gel par chunk**. D'où exactement ce qu'on lit :

* `Can't keep up! Is the server overloaded? Running 26381ms` ;
* `0/783` → `199/783` en **24 minutes** (~2 chunks / 30 s) ;
* le repli « force » à 2 chunks/tick qui n'avançait pas, parce que chaque appel bloquait la
  boucle qui était censée le mesurer.

Un budget de temps **ne peut rien contre un appel bloquant** : c'est pour ça que les budgets
T46/T47 semblaient sans effet — ils testaient l'horloge *entre* deux gels de 15 s.

### Ce qui a été changé (5 emplacements, tous hors Crimson Lake, déjà corrigé en T48)

| Emplacement | Pourquoi c'était grave | Correction |
|---|---|---|
| `SafeSurface.primeChunk()` — appelé par `surfaceY()`, donc **à chaque colonne de terrain** | bloquant une fois par chunk sur toute la zone | `primeChunkSoft()` : mesure ce qui est là, demande le reste en tâche de fond |
| `SafeSurface.captureHeightmap()` | une fois par chunk, en début de pipeline | idem (non bloquant) |
| `Structures4/5.findFlatArea()` (vérification « terrain fantôme ») | forçait la génération **synchrone de tous les chunks de `checkR`** (jusqu'à ~300 par candidat) **× 12 à 24 candidats** — le plus gros consommateur de temps du mod | un candidat dont la zone n'est **pas encore** en mémoire est **différé** (chunks demandés en tâche de fond) puis réexaminé dans une **seconde passe** bornée |
| `placeOne()` / `placeEverestBlock()` mode `force` (après 600 ticks) | bloquant | bloc **différé**, plus jamais de génération synchrone |
| `StructureTerrainPrep.backfillVoidGap()` | bloquant (budget inopérant) | colonne sautée si le chunk n'est pas en mémoire, demande en tâche de fond |

Nouveaux outils dans `SafeSurface` : `loaded()`, `request()`, `requestZone()`, `zoneLoaded()`,
`primeChunkSoft()`. Un chunk non prêt n'arrête plus rien : les passes sautent ses colonnes
(sauver les colonnes non chargées = le comportement déjà validé du budget T46).

### Preuves

* `run/logs/t51_run3.log` : pipeline complet du lac **terminé**, ordre T39 respecté, 0 exception.
* `run/logs/t51_run4.log` : everest 52 979 blocs, **aucune génération synchrone**, 73,2 s
  (bac à sable 2 vCPU).

---

## T50b — route de test `/dlbtest crimsonlake` ✅

**Commit :** `T50b: /dlbtest crimsonlake (rejouer l'evenement du lac sans attendre le 1/500)`

Le lac n'était déclenchable que par l'événement aléatoire (1/500 par minute) ou par
`/crimsonlake` **avec un joueur connecté** : impossible à rejouer quand on corrige, et impossible
à tester en console. Désormais :

```
/dlbtest crimsonlake
```

rejoue **exactement** le même chemin (mêmes anneaux, même position, même pipeline, annonce de
60 s comprise) avec un joueur réel ou factice. La propriété système
`-Ddlb.test.lakeTemplate=<nbt>` permet de rejouer le pipeline complet du lac avec un petit NBT
(mesures en environnement de test limité en mémoire) — le comportement de production est
inchangé. Corrigé au passage : `theServer` n'était renseigné que par la connexion d'un joueur,
donc en console le pipeline ne démarrait jamais.

---

## T51 / T51b — pré-chauffage borné en mémoire ✅

**Commit :** `T51: pre-chauffage borne en memoire (chunks les plus proches du centre, vagues non bloquantes)`

Le pré-chauffage demandait **toute** la zone d'un coup : 754 chunks pour le lac. Un chunk généré
occupe ~0,5 à 1 Mo tant que le chunk system ne l'a pas déchargé → 400 à 750 Mo, et une mise en
OOM mesurée avant même la fin du compte à rebours. Désormais :

* plafond **adapté au tas de la JVM** : ≥ 4 Go → 384 chunks, ≥ 3 Go → 256, ≥ 2 Go → 160, sinon 64
  (`-Ddlb.preheat=N` pour forcer, `-Ddlb.preheat=0` pour désactiver) ;
* les chunks **les plus proches du centre** d'abord ;
* demandes **par vagues de 16 toutes les 5 ticks**, via `getChunkFuture` : jamais bloquant,
  **aucun maintien en mémoire** (rien n'est épinglé) ;
* le reste de la zone est pris en charge par le pré-chargement borné du pipeline (T46/T47).

Ce qui coûte cher, c'est la **génération** : elle se fait pendant les 60 s d'annonce pour le cœur,
puis dans la fenêtre bornée du pipeline pour le reste.

---

## T52 — plus AUCUN secours synchrone, même en repli ✅

**Commit :** `T52: suppression du repli synchrone du pre-chargement (plus aucune generation bloquante)`

Il restait deux portes de sortie synchrones, alors qu'un seul appel bloquant coûte jusqu'à ~15 s
de gel sur un monde neuf :

1. le « repli forcé » du pré-chargement (1 chunk/tick en FULL bloquant) — autorisé pour **toute**
   zone ≤ 512 chunks, donc everest, dragon, shipdead, citadel, observatoire… ;
2. la « réparation » d'un chunk de cœur manquant (`SafeSurface.primeChunkAbs`) dans le pas de
   pré-chargement.

Les deux sont **supprimés par défaut** : un chunk manquant est *demandé* en tâche de fond et ses
colonnes sont sautées par les passes. `-Ddlb.sync=1` restaure l'ancien comportement (diagnostic).
Il ne reste donc **aucun** chemin de génération synchrone dans le pipeline, pour aucune structure.

---

## Passe « OPTI ULTIME » — T53 → T66 : le gel pre-pipeline est mort, mesure a l'appui

**Objectif (ta consigne du 23/09)** : « verrifie aussi que le chargement des chunks etc, soit bien
rapide et efficace partout, on vise l'opti ultime, sur nos structures, etc ». Perimetre reel :
**tous** les chemins de chargement/lecture de terrain (acces chunk, heightmaps, templates NBT,
tickets, boucles de pose), pas seulement la pose.

### Le chiffre qui resume tout

| Mesure (observatoire, monde neuf, bac a sable 2 vCPU) | Avant | Apres |
| --- | --- | --- |
| Gel du thread serveur avant le pipeline | `Can't keep up ... Running 28 934 ms` | **0** |
| Grille de scoring (47x47 cellules) | 16 982 ms (T59) | **19-22 ms** |
| Scoring des candidats (464) | 9 ms | 2-6 ms |
| Pre-chargement de la zone (144 chunks) | jamais fini (48 chunks perdus) | **7,1 s**, 144/144 |
| **Pipeline COMPLET** | ~1 h (freezes en chaine) | **20,5 s** |
| Structure posee | jamais (dans la fenetre) | **oui, en dernier (T39)** |

Preuve : `run/logs/t66_run1.log`
```
[16:46:39] [STRUCT5-FLAT] grille de scoring : 47x47 cellules (484 connues) en 22 ms
[16:46:39] [STRUCT5-FLAT] scoring termine : 464 candidat(s) en 2 ms (joueur 0 ms, emprises 2 ms, mesures terrain 0 ms)
[16:46:39] [STRUCT5-FLAT] Zone choisie a -45,-40 (candidat #1/24) : flat=100%, pente=3 (score=960, terrain reel verifie, Y reel=67)
[16:46:47] [DLB-CHUNKS] 144/144 chunks epingles (maintien en memoire) -- zone complete
[16:46:47] [DLB-STRUCTURE] pre-chargement TERMINE en 7.106 s : coeur 144/144, zone 144/144 (zone complete)
[16:47:01] [DLB-PERF] TACHE COMPLETE en 20.5 s -- ou est passe le temps : pre-chargement des chunks 5.4 s (26%)
           | verifyGrassSurface 3.9 s (19%) | rebuildTerrain 3.3 s (16%) | cleanupZone 0.8 s (4%) | ...
[16:47:01] [DLB-STRUCTURE] [20.5 s] decorate TERMINE (decors, arbres, naturalisation -- structure posee en DERNIER, T39)
```

### La cause racine (enfin identifiee, mesuree, corrigee)

Ce n'etaient **ni** les lectures de terrain, **ni** les heightmaps : c'etaient les **DEMANDES de
chargement de chunk**. Chaque `getChunkFuture(cx, cz, FULL, true)` / `request()` cree un ticket,
met le chunk en file et reveille le chunk system ; lance depuis une boucle qui balaie 47x47
cellules, cela faisait **600+ demandes dans un seul tick = 17 s de gel**.

Chemin suivi pour y arriver (chaque hypothese a ete mesuree puis ecartee) :

* **T55** — `scanGroundY` ne scanne plus un chunk absent : 28 934 -> 29 280 ms. Hypothese ecartee.
* **T56** — `SafeSurface.state()` non bloquant + `measureFlatQuality` non bloquant : 29 540 ms. Ecartee.
* **T57** — instrumentation du scoring : **28 624 ms dans `measureFlatQuality`**, 1 971 candidats
  x 81 colonnes = ~160 000 lectures. Le coupable est localise.
* **T58** — heightmap « primee » 1x/chunk : 36 863 ms. Hypothese heightmap ecartee.
* **T59** — grille de hauteurs partagee pour le CLASSEMENT (2 002 cellules connues) : **16 982 ms**,
  scoring 9 ms. On divise par 1,7 mais on ne comprend toujours pas.
* **T60/T60b** — registre `READY`/`PENDING` + routage de `ChunkKeeper` par `requestThen` : 18 219 ms.
  Le routage seul ne suffit pas.
* **T61** — `surfaceScan` : balayage borne des blocs, plus aucune heightmap : **16 812 ms**. Ecartee
  aussi — donc le cout n'est pas la lecture.
* **T62** — on compte : **752 recherches de chunk = 3 ms au total, 0 attente > 2 ms**. Les lectures
  ne coutent RIEN. Le cout, ce sont les 600+ `request()` de la boucle de scoring.
* **T63** — la boucle de scoring ne demande **plus aucun** chargement (le classement se fait sur ce
  qui est deja en memoire) : **19 ms** (contre 16 982 ms). Cause racine confirmee.
* **T64** — la verification des 24 meilleurs candidats ne bloque plus non plus : `qualityOnReady`
  mesure sans attendre, les candidats non prets sont **differes en tache de fond**.
* **T65/T66** — deux bugs trouves par mes propres tests dans ce nouveau routage :
  1. `requestThen` ne rappelait pas son callback quand le chunk etait deja en vol -> fuite du
     compteur d'appels en vol de `ChunkKeeper` -> au bout de N fuites, **plus aucune demande
     n'etait emise** (constate : les 48 derniers chunks d'une zone de 144 n'arrivaient jamais) ;
  2. le registre `READY` etait cru sur parole alors qu'un chunk peut avoir ete decharge entre-temps
     -> la demande etait sautee et le chunk ne revenait jamais. Ajout de `reRequest` (re-demande
     forcee) + re-tentative periodique (5 s) des chunks toujours absents + garde-fou sur le
     compteur. Resultat : **144/144**.

### Ce qui a ete livre, tache par tache

* **T53** — cache `SafeSurface` (direct-mapped 256 entrees, reponses positives seulement) : les
  lectures de terrain passent de 1 674 requetes moteur a **1 209 621 lectures servies par le cache
  (100 %)**, plus `ChunkKeeper` (tickets PORTAL rafraichis par tranches de 96/tick, jamais plus de
  150 ticks d'age) et la ligne `[DLB-PERF] ... 1433 requete(s) moteur, 1205823 lecture(s) servies
  par le cache (100 %), 52 colonne(s) hors memoire`.
* **T54** — le parse NBT de plus de `TEMPLATE_SYNC_MAX_KB` (256 Ko) ne se fait **plus jamais** sur le
  thread serveur : *« 'observatory' : NBT charge en TACHE DE FOND (743 Ko) ... 3730 ms (le serveur
  n'a jamais ete bloque) »*. `-Ddlb.templateSync=1` restaure l'ancien comportement.
* **T55/T56** — plus aucune passe ne bloque sur un chunk absent : les colonnes inconnues sont
  sautees (comportement deja valide par le budget T46), eau/lave comprises.
* **T57** — `tPlayerMs/tSiteMs/tMeasureMs` + `-Ddlb.flatDebug=true` : on sait enfin ou part le temps.
* **T59** — grille de hauteurs partagee ; les 24 meilleurs candidats restent verifies colonne par
  colonne (aucune perte de fiabilite : la ligne « terrain reel verifie » est toujours la).
* **T60 → T66** — registre `READY`/`PENDING`, `requestThen`, `reRequest`, `surfaceScan`,
  `qualityOnReady`, garde-fous. Nouvelle API : `SafeSurface.chunkFor/heightOf/request/requestThen/
  readyNow/surfaceScan/reRequest` + `Structures5Procedure.qualityFromGrid/qualityOnReady`.
* **T62** — diagnostic `diagChunkCalls/diagChunkNs/diagChunkWaits` + `-Ddlb.diag=true` : le
  classement n'a plus besoin de charger quoi que ce soit, et on peut le **prouver** a chaque run.

### Regle de conception a conserver (ne pas la re-casser)

1. **Ne jamais appeler `request`/`getChunkFuture(create=true)` depuis une boucle de classement ou de
   mesure.** Le chargement appartient au pre-chauffage et a la fenetre de pre-chargement du pipeline.
2. Un callback doit etre appele **exactement une fois** par appel de `requestThen`, quelle que soit la
   sortie (sinon le compteur d'appels en vol fuit et **tout** s'arrete).
3. Un chunk peut etre decharge entre deux ticks : le registre `READY` est une **optimisation**, pas
   une verite. Toute attente de zone doit avoir une **re-tentative** bornee.

### Limite de validation cote bac a sable

Le niveau de test « structure normale » (observatoire, 144 chunks) est **valide en jeu** ci-dessus.
Le Crimson Lake (754 chunks) n'est **pas mesurable dans le bac a sable actuel** : le processus java
s'est fait tuer par le noyau (`exit value 137`, memoire du bac a sable a 2 Go). La derniere mesure
valide du lac reste **52,1 s** (`run/logs/t51_run3.log`, T51). A re-mesurer sur ta machine, ou le
critere est « crimsonlake 3-5 min MAX total ».

---

## T67 — une entrée `/dlbtest` PAR structure, et le TAB propose tout

**Ta demande** : « la commande /dlbtest everest etc ne fonctionnent pas, ou ne sont même pas
reconnus par le jeu, il faut un /dlbtest pour chaque structure, everest, crimsonlake, dragon,
citadel, ship, circus, observatory ... (noms plus simples et ciblés comme ça), il faut tout rendre
fonctionnel et minecraft doit bien nous proposer les choix avec tab pour toutes mes commandes
dlbtest ! »

### Pourquoi ça ne marchait pas (3 causes cumulées)

1. **Il n'y avait pas de `/dlbtest everest`** : une seule entrée générique `/dlbtest structure <id>`
   (ids 0..40) plus un `/dlbtest crimsonlake` isolé. Les noms de structures n'existaient pas comme
   sous-commandes.
2. **Permission 2 exigée** : la racine portait `.requires(src -> src.hasPermission(2))`. En partie
   solo sans cheats, un joueur est de niveau 0 → la commande n'est **ni exécutable ni proposée**.
3. `structure` attendait un **entier** : le tab ne pouvait proposer qu'un vide de nombres, jamais
   les noms.

### Ce qui a été fait

* **Un nœud littéral par structure** — donc présent dans l'arbre envoyé au client, donc **proposé
  par TAB** :
  `citadel`, `observatory`, `dragon`, `circus`, `ship`, `everest`, `crimsonlake`
  + alias français : `citadelle`, `obs`, `observatoire`, `cirque`, `shipdead`, `bateau`,
  `lake`, `lac`, `crimson`.
* `/dlbtest structure <nom>` accepte désormais un **nom ou un ancien id** (`0`, `5`, `16`…), avec
  **suggestions** sur les noms et alias (compatibilité totale avec l'ancienne syntaxe).
* `/dlbtest list` (et `ids`) : table complète affichée **en cliquable** (clic = lance la structure).
* `/dlbtest tree` : affiche l'arbre **réellement enregistré** (lecture directe du dispatcher du
  serveur = exactement ce que le client reçoit pour le tab). Sert de diagnostic immédiat : si une
  entrée manque dans `tree`, elle manquera en jeu.
* **Permission 0 par défaut** (tout le monde) — c'est ce qui rend la commande visible en solo sans
  cheats. `-Ddlb.cmdOp=1` restaure l'ancienne restriction opérateur (niveau 2).
* Ligne de démarrage dans le log :
  `[DLBTEST] commande prete : /dlbtest -> citadel, observatory, dragon, circus, ship, everest, crimsonlake | ...`
  → si tu ne la vois pas, le jar n'est pas chargé (premier point à vérifier).

### Preuve (run/logs/t67_run2.log, serveur dédié, monde neuf)

```
[DLBTEST] commande prete : /dlbtest -> citadel, observatory, dragon, circus, ship, everest, crimsonlake |
           structure <nom|id> | list | water <status|freeze|thaw> | probe <x> <z> | luckybreak [nombre]
           (permission tout le monde (0))

> dlbtest tree
  /dlbtest <citadel>  (executable)
  /dlbtest <citadelle>  (executable)
  /dlbtest <observatory>  (executable)
  /dlbtest <obs>  (executable)
  /dlbtest <observatoire>  (executable)
  /dlbtest <dragon>  (executable)
  /dlbtest <circus>  (executable)
  /dlbtest <cirque>  (executable)
  /dlbtest <ship>  (executable)
  /dlbtest <shipdead>  (executable)
  /dlbtest <bateau>  (executable)
  /dlbtest <everest>  (executable)
  /dlbtest <crimsonlake>  (executable)
  /dlbtest <lake>  (executable)
  /dlbtest <lac>  (executable)
  /dlbtest <crimson>  (executable)
  /dlbtest <structure>  -> nom
  /dlbtest <list>  (executable)
  /dlbtest <ids>  (executable)
  /dlbtest <tree>  (executable)
  /dlbtest <water>  -> status freeze thaw
  /dlbtest <probe>  -> x
  /dlbtest <luckybreak>  -> nombre
[DLB-TEST] arbre enregistre : 23 entree(s) de premier niveau sous /dlbtest -- toutes proposees par TAB

> dlbtest water status
[DLB-WATER] etat : gel inactif, 0 bloc(s) d'eau memorises (futurs restaures)

> dlbtest observatory
[DLBTEST] observatory demandee a 0, 64, 0 (id=1, nbt=observatory, joueur factice)
[STRUCT5-FLAT] grille de scoring : 47x47 cellules (484 connues) en 13 ms
[STRUCT5-FLAT] Zone choisie a -45,-40 (candidat #1/24) : flat=100%, pente=3 (score=960, terrain reel verifie)
[DLB-CHUNKS] 143/143 chunks epingles (maintien en memoire) -- zone complete
[DLB-PERF] TACHE COMPLETE en 18.0 s

> dlbtest structure everest        (equivalent de /dlbtest everest)
[DLBTEST] structure EVEREST demandee (...) -- la construction demarre apres le choix de zone
[DLBTEST] everest demandee a 0, 64, 0 (id=5, nbt=everest, joueur factice)

> dlbtest structure citadelle      (alias)
> dlbtest structure 5              (ancien id -- compatibilite)
> dlbtest structure inconnu
[DLB-TEST] Structure « inconnu » inconnue. Noms valides : citadel, observatory, dragon, circus, ship, everest, crimsonlake
```

L'everest lancé dans la même session a été interrompu par le **watchdog** : 484 chunks sur une
machine à 2 Go. Ce n'est pas la commande (elle a bien été reconnue, dispatchée et journalisée) mais
la limite connue du bac à sable. `run/logs/t67_run1.log` (première série de tests) montre les mêmes
dispatchs OK pour `everest`, `citadel`, `structure 5`, `water status`, `list`.

### Ce qu'il faut savoir côté Minecraft (et qui explique « pas reconnu »)

* En **solo**, si la partie est ouverte **sans les cheats**, le client masque **toutes** les
  commandes : aucune n'apparaît au tab, même celles en permission 0. Il faut activer les cheats sur
  le monde (création du monde, ou « Ouvrir au réseau local » avec cheats, ou Éditer le monde →
  Autoriser les commandes).
* Sur un **serveur**, la commande est immédiatement utilisable (permission 0), et le tab la propose.
* Le jar doit être **celui-ci** : `jar/deep_lucky_block-1.0.jar`
  (md5 `f51c7dc6e28026aa85c1ec8619bc292c`) — l'ancien jar ne contenait que
  `/dlbtest structure <id>`.

---

## T68 → T70 — les passes par colonnes ne font plus tomber le serveur (everest : watchdog → 104,5 s)

**Contexte** : après T67, le test « everest seul » (zone de 667 chunks) tombait **systématiquement**
sur `Watchdog : A single server tick took 60.01 seconds`, dans la phase
**« balayage étendu des naturels flottants »** (le hotspot n°2 déjà repéré).

### T68 — le budget de tranche est vérifié À CHAQUE COLONNE (+ mesure des colonnes lentes)

Le budget de temps existait, mais il n'était testé qu'**entre deux lots** de `perSlice` colonnes
(**384** pour le balayage étendu). Or une seule colonne peut coûter cher : 58 lectures de blocs
(48 au-dessus + 10 sous la surface) et, si elle rencontre un amas naturel flottant, une exploration
de proche en proche jusqu'à 512 blocs × 6 voisins. Un lot de 384 colonnes défonçait donc le tick.

* le budget est désormais testé **à chaque colonne** (un `System.currentTimeMillis()` ≈ 25 ns, une
  colonne des milliers de fois plus cher) → une tranche coûte au plus `budget` + **une** colonne ;
* instrumentation : toute colonne au-delà de **50 ms** est comptée, et le pire cas est journalisé
  (`… : N colonne(s) lente(s) (> 50 ms chacune, pire X ms, Y ms au total)`).

**Mesure** : tick de **38 340 ms → 10 718 ms** dans cette phase, puis → plus de 60 s du tout.
Sur l'observatoire, l'instrumentation a immédiatement trouvé le coupable réel :
`balayage etendu … : 1 colonne(s) lente(s) (pire 532 ms)`.

### T69 — exploration d'amas bornée dans le temps (on conserve plutôt que d'effacer)

`isFloatingCluster` explore un amas de proche en proche (jusqu'à 512 blocs, 7 lectures par bloc).
Budget ajouté : **20 ms par amas**. Au-delà, on s'arrête et on répond « **ancré** » — donc on **ne
supprime jamais** un amas qu'on n'a pas pu vérifier entièrement. Les dépassements sont comptés et
journalisés : `balayage etendu TERMINE : … (N amas non vérifiés faute de temps -- CONSERVÉS)`.

**Mesure** : colonnes lentes du balayage **21 → 15** sur everest (pire 2 630 → 286 ms).

### T70 — une colonne non chargée est REPRISE, plus jamais perdue

Le pré-chargement étant borné (T46/T51), il reste des chunks non chargés quand une passe arrive à
eux. Les colonnes concernées étaient **comptées puis jetées** :

```
balayage etendu … : 43 321 colonnes sautees (chunk absent) -- elles n'ont pas ete traitees
hole filler       : 45 737 colonnes sautees (chunk absent) -- elles n'ont pas ete traitees
```

Désormais ces colonnes sont **mises en attente et reprises automatiquement** (toutes les 0,5 s,
jusqu'à 30 s) dès que le chunk arrive :

```
balayage etendu … : 43 289 colonne(s) en attente de chunk -- reprise automatique des que la zone est chargee
hole filler       : 45 737 colonne(s) en attente de chunk -- reprise automatique
… : 15 colonne(s) lente(s) (pire 286 ms)          <- plus AUCUNE colonne non traitée
hole filler TERMINE : 50 970 poche(s) rebouchee(s), 250 000 bloc(s)
```

### Résultat mesuré (run/logs/t70_run1.log, everest, monde neuf, bac à sable 2 Go)

| | Avant T68 | Après T70 |
|---|---|---|
| Watchdog / arrêt du serveur | **systématique** (tick de 60 s) | **aucun** |
| Colonnes non traitées | 43 321 + 45 737 | **0** |
| Blocs naturels flottants retirés | 66 605 | **66 750** (les colonnes rattrapées ont été traitées) |
| Poches rebouchées | 50 929 | **50 970** |
| **Pipeline complet** | jamais terminé | **104,5 s** |

```
[DLB-PERF] TACHE COMPLETE en 104.5 s -- ou est passe le temps : pre-chargement des chunks 39.8 s (38%) |
           hole filler (tunnels / failles / cavites) 36.8 s (29%) | balayage etendu ... | ...
[DLBTEST] everest demandee a 0, 58, 0 (id=5, nbt=everest, joueur factice)   <- /dlbtest everest
[DLB-CHUNKS] 667/667 chunks epingles (maintien en memoire) -- zone complete
```

### Prochain hotspot identifié (instrumentation T68)

`hole filler : 59 colonne(s) lente(s) (pire 303 ms, 7 658 ms au total)` — c'est maintenant la
première dépense devant le balayage. La même méthode (budget interne) lui sera appliquée si tu
constates encore des ticks longs sur les très grosses zones.

---

## T71 → T72 — lectures de terrain par sections (16 blocs d'un coup) + cache agrandi

**Contexte** : T70 avait réglé la perte de colonnes, mais le hole filler et le balayage étendu
restaient les deux phases les plus lourdes d'everest (33,8 s + 30,8 s sur 147 065 colonnes), avec
**5 366 134 requêtes moteur** pour seulement 817 779 lectures servies par le cache.

### T71 — lire les SECTIONS, pas les blocs (16 pour le prix d'un)

Les deux passes les plus lourdes lisaient leurs blocs un par un (`64` lectures/colonne pour le hole
filler, `58` pour le balayage = ~9 millions de lectures chacune). Or la très grande majorité de ces
blocs sont soit **entièrement solides** (pierre sous la surface), soit **entièrement vides** (air
au-dessus du sol) : l'information est disponible au niveau de la **section de 16 blocs**.

* `LevelChunkSection.hasOnlyAir()` → 16 blocs d'air traités d'un coup ;
* `LevelChunkSection.maybeHas(predicat)` → section sans aucun bloc intéressant : sautée entièrement
  (aucun air ⇒ tout solide pour le hole filler ; ni air ni décor naturel ⇒ rien à faire pour le
  balayage) ;
* lecture unitaire via le `ChunkAccess` du chunk (résolu **une fois par colonne** par
  `SafeSurface.chunkFor`) au lieu de `Level.getBlockState` à chaque bloc ;
* **plafond de blocs rebouchés** : `-Ddlb.holeFillMax=N` (défaut **250 000 → 400 000**) et son
  atteinte est désormais **journalisée** (`PLAFOND ATTEINT : N colonne(s) NON analysée(s)`) — avant,
  la passe s'arrêtait **en silence**, ce qui explique une partie des « tunnels encore là » signalés
  par le dev.

**Mesures (everest, monde neuf, `run/logs/t71_run1.log` vs `t70_run1.log`)**

| | T70 | T71 |
|---|---|---|
| Poches rebouchées | 50 970 | **71 238** (+40 %) |
| Blocs rebouchés | 250 000 (**plafond atteint**) | **333 798** (plafond non atteint) |
| Durée du hole filler | 36,8 s | **33,8 s** *avec 33 % de travail en plus* |
| ≈ coût par bloc rebouché | 147 µs | **101 µs** (-31 %) |
| Balayage étendu | 32,4 s / 66 744 blocs | 30,8 s / 66 749 blocs |
| Colonnes non traitées | 0 | **0** |

Autrement dit : à travail égal, les deux passes vont ~30 % plus vite, et sur everest **72 000 blocs
de plus sont rebouchés** (les tunnels restants sont traités au lieu d'être abandonnés au plafond).

### T72 — cache de terrain agrandi (256 → 4096) + mémo de proximité — résultat honnête

Le cache de chunks de T53 ne comptait que **256 entrées** alors qu'une zone comme everest en couvre
**576** : il était donc lessivé à chaque tranche. Passage à **4096 entrées** (~100 Ko) et ajout d'un
**mémo « dernier chunk »** (les passes balaient des colonnes consécutives, qui tombent 16 fois de
suite dans le même chunk).

**Résultat mesuré : le taux de lectures servies par le cache n'a quasiment pas bougé**
(13 % → 14 %, `run/logs/t72_run1.log`), et le temps total d'everest est passé de 120,3 s à 116,4 s
(dans la variabilité du bac à sable). Explication : les ~5,2 millions de requêtes ne viennent pas
d'un seul passage mais de la **quinzaine de passes** qui repassent chacune sur les 147 065 colonnes
(et deux fois quand une tranche doit être rattrapée, T70). Les deux correctifs sont **conservés**
(ils ne peuvent que réduire le nombre de recherches), mais l'optimisation du compteur elle-même est
**arrêtée là** : le gain restant est marginal.

### Où passe vraiment le temps sur everest maintenant (mesure)

```
[DLB-PERF] TACHE COMPLETE en 116.4 s -- pre-chargement des chunks 46.3 s (40%) |
           hole filler 33.8 s (29%) | balayage etendu 30.8 s (26%) | fixLiquids 1.4 s (1%) |
           paste everest (blocs) 0.0 s | attente/tick system 4.1 s
```

**40 % du temps est de la génération de chunks** (754 chunks de monde neuf) : c'est la partie qui ne
dépend pas du mod, et c'est aussi celle qui profitera le plus de ta machine (le bac à sable n'a que
2 vCPU). Sur une structure normale (observatoire, 144 chunks) : **22,0 s** au total,
`hole filler 1,3 s`.


---

## T70b — aucune attente inutile en fin de passe (et note sur la fiabilité des mesures)

**Correctif** : en mode rattrapage (T70), une passe pouvait attendre jusqu'à 30 s pour des colonnes
dont les chunks **ne reviendraient jamais** (zone déjà complète côté ChunkKeeper). Désormais : si la
zone est déclarée complète et qu'une tentative entière ne récupère **aucune** colonne, la passe se
termine honnêtement (`N colonne(s) inaccessibles alors que la zone est complète -- passe terminée
sans elles (aucune attente inutile)`). C'était le seul risque d'allongement introduit par T70.

**Note importante sur les mesures du bac à sable.** Pendant cette session, la machine de test a
saturé (charge moyenne 17-23, `kswapd0` actif, mémoire 2 Go). Conséquence mesurée : **le même jar,
sur la même structure et le même monde, a produit 22,0 s puis 123,4 s** (run `t72_run3.log`), puis
**23,8 s** une fois la charge retombée (`t72_run5.log`). Autrement dit : au-delà d'un facteur ~5,
les chiffres de cette machine ne mesurent plus le mod mais la contention.

Chiffres considérés comme **représentatifs** (charge < 8, runs t66 → t72_run2) :

| Structure | Total | Détail notable |
|---|---|---|
| observatoire (144 chunks) | **17,9 → 23,8 s** | hole filler 0,9-1,3 s |
| everest (667 chunks) | **104,5 → 120,3 s** | dont **40 % de génération de chunks** (754 chunks de monde neuf) |
| grille de scoring (47x47) | **13-27 ms** | 752 recherches de chunk = 2-3 ms au total |
| pipeline avant/après la passe | ~1 h (freezes en chaîne) | plus aucun `Can't keep up` massif |

Les runs sous forte charge (`t72_run3.log`, `t72_run4.log`) sont conservés dans le zip **pour
transparence** : ils montrent la variabilité, pas une régression (aucun changement de code entre
`t72_run2` à 22,0 s et `t72_run3` à 123,4 s).

## T73 — « l'air n'est plus un bloc » : filtre NBT en flux + pose sans air 23/09/2026

**Directive en jeu.** « la structure everest est totalement optimisee, et est totalement creuse »
puis « revois peut etre pourquoi l'air est compte comme bloc et comment le supprimer, vois aussi
meme pour les autres structures ». L'ancienne explication du mod (« everest galere car elle genere
enormement de blocs ») etait donc **fausse** : everest est creuse (52 980 entrees, 0 air, 193 Ko).

**Mesure qui a cadre le probleme** (lecture directe des .nbt) : le format .nbt materialise CHAQUE
case de la boite du template. L'air ne pese presque rien dans le fichier, mais **une entree par
case** est creee en memoire, puis parcourue a la pose :

| structure | boite | entrees au fichier | air | vrais blocs |
|---|---|---|---|---|
| everest | 174x123x278 | 52 980 | **0** | 52 980 |
| observatory | 68x77x51 | 267 036 | 251 586 (94 %) | 15 450 |
| dragon | 69x137x85 | 803 505 | 728 021 (91 %) | 75 484 |
| circus | 80x105x87 | 730 800 | 691 716 (95 %) | 39 084 |
| shipdead | 113x87x173 | 1 700 763 | 1 628 880 (96 %) | 71 883 |
| citadel | 104x242x84 | 2 114 112 | 2 008 836 (95 %) | 105 276 |
| crimsonlake | 246x236x284 | 1 366 835 | **0** | 1 366 835 |

**Cause racine.** Le parseur vanilla (`NbtIo.readCompressed` + `StructureTemplateManager
.readStructure`) construit pour chaque entree un `CompoundTag` + un `ListTag` + 4 `IntTag`
(~200 o) : **citadel = 2,1 M entrees => ~400 Mo** pour des blocs d'air qui etaient de toute facon
rejetes a la pose. C'est ce qui a produit l'`OutOfMemoryError` sur citadel (observe avant T73 :
`Echec du chargement en tache de fond de 'citadel' (51384ms) : java.lang.OutOfMemoryError`), et
c'est aussi du temps CPU pur perdu (chaque entree etait lue, allouee, puis testee).

**Correction (2 volets).**

1. **`util/NbtAirFilter.java` (nouveau)** — filtre NBT **en flux** : le fichier est lu par un
   lecteur minimal (gzip -> primitives), qui ne materialise **que** deux tableaux primitifs
   (positions packees + index de palette) et reconstruit un tag ne contenant que **les vrais blocs
   + l'air INTERIEUR** (flood fill depuis les 6 faces, comme avant). Le parseur vanilla ne voit donc
   jamais les millions d'entrees d'air : elles n'existent ni en memoire, ni sur le chemin de pose.
   Les sous-tags `nbt` des blocs (coffres) et les `entities` sont preserves. Securite : toute
   entree inattendue (tag inconnu, palette sans air, liste non conforme) rend la main au parse
   vanilla — comportement identique a avant ; desactivable par `-Ddlb.nbtAirFilter=0`
   (seuil d'application : `-Ddlb.nbtAirFilterMinKb`, defaut 32 Ko).
2. **`util/StructureTemplateCache.java`** — le cache sert desormais la liste **compactee**
   (`compactBlocks(name)`) et l'air interieur **calcule une seule fois** (`interiorAir(name)`),
   au lieu d'un flood fill recalcule a chaque pose ; l'air exterieur est compte et journalise.
3. **`procedures/Structures4Procedure.java` et `Structures5Procedure.java`** — les procedures
   posent la liste compactee (`compactBlocks` en priorite, repli sur l'ancienne extraction), lisent
   l'air interieur dans le cache (repli sur l'ancien calcul), et **ne reposent plus jamais de l'air
   sur de l'air** (test `getBlockState(...).isAir()` : une case deja vide ne coute plus ni acces
   chunk ni mise a jour de bloc).

**Mesures en jeu (jar `b3f3dd5c`, monde neuf, charge normale).**

| structure | entrees fichier | blocs a poser | air interieur | air exterieur jamais materialise | memoire NBT evitee | chargement (tache de fond) | pipeline total |
|---|---|---|---|---|---|---|---|
| observatory | 267 036 | 15 450 | 75 | 251 511 (94 %) | ~47 Mo | 3 257 ms | **23,6 s** |
| dragon | 803 505 | 75 484 | 392 | 727 629 (90 %) | ~138 Mo | 2 859 ms | **20,2 s** |
| citadel | 2 114 112 | 105 276 | 9 329 | 1 999 507 (95 %) | **~381 Mo** | 6 079 ms | **43,2 s** |

- **citadel se charge et se pose pour la premiere fois** : 113 930 blocs poses en 37 s, structure
  terminee (`11 blocs supprimes, 77 blocs de motte`), **0 exception**. Avant T73, citadel ne passait
  jamais : `OutOfMemoryError` au chargement.
- **toutes les positions sont verifiees dans la boite** (journal T73b) : citadel
  `X 0..103 Y 0..241 Z 0..83 (boite 104x242x84, 0 hors boite)`.
- everest et crimsonlake ont une palette **sans air** : le filtre rend la main au parse vanilla
  (aucun gain a attendre, aucun risque pris) — everest reste a 104-120 s, dont ~40 % de generation
  de chunks.

**Bug trouve et corrige pendant T73 (T73b) — le plus important du lot.** Le premier filtre
redecodait les positions a la main avec le mauvais sens : `BlockPos.asLong` range **Y dans les bits
bas** (`Y_OFFSET=0`, `Z_OFFSET=12`, `X_OFFSET=38`), alors que le decodage maison lisait X dans les
bits bas. Une position `(x,y,z)` relue donnait `(z*4096+y, 0, x)` : **la boite d'edition de citadel
explosait a 274 648 blocs de large (229 600 chunks a pre-charger !) au lieu de 104**, la zone
choisie etait absurde et le serveur a fini en `ServerHangWatchdog` (60 s, `t73_run2.log`). Cout de
la faute : un run et ~2 minutes, pas plus, parce que le journal de controle l'a localise
immediatement. Corrige en passant par les getters **vanilla** (`BlockPos.getX/getY/getZ`, seule
source de verite) + compteurs de controle `positions lues / hors boite` dans le journal, pour que ce
genre d'erreur se voie **dans les logs** et non dans une carte detruite.

**Risque residuel identifie, NON corrige (a traiter si tu le veux — T74).** `SafeSurface.request()`
appelle `getChunkFuture(..., load=true)`, qui fait un `managedBlock` quand il est appele depuis le
thread serveur : si le chunk system est sature, le tick peut attendre 60 s (c'est **le mecanisme**
du watchdog de `t73_run2.log`, dont la **cause** etait la zone geante de T73b). Avec la zone
corrigee (225 chunks au lieu de 274 672), le risque a disparu en pratique : citadel, observatory et
dragon se sont poses sans aucune attente. La correction propre serait de remplacer, **sur le thread
serveur uniquement**, la demande bloquante par un ticket non bloquant + sonde au tick.

**Chiffres de reference a comparer.** Observatoire 23,6 s apres T73 contre 23,8 s avant (T70b) —
aucune regression. Dragon 20,2 s et citadel 43,2 s n'avaient **aucune** mesure avant (structures
jamais posees). Crimson Lake reste a re-tester de ton cote (critere 3-5 min).

### T73c — everest : la preuve que l'air n'existe pas (et un journal qui le dit)

`everest` passe bien par le filtre en flux, et le journal le prouve en une ligne :

```
[STRUCT-CACHE] 'everest' : 52980 entree(s) au fichier -> 52980 bloc(s) a poser + 0 air interieur
               (0 air exterieur JAMAIS materialise(s) = 0 %, lecture en flux 172 ms, 174x123x278) -- T73
[STRUCT-CACHE] 'everest' : positions lues X 0..173 Y 0..122 Z 0..277 (boite 174x123x278, 0 hors boite) -- T73b
[STRUCT-CACHE] 'everest' charge en tache de fond en 1730ms (le serveur n'a jamais ete bloque)
```

Autrement dit : **everest est creuse a 100 %** (52 980 blocs, 0 air) — ton analyse est confirmee par le
code, et l'ancienne explication (« everest galere car elle genere enormement de blocs ») est
definitivement abandonnee. Le fichier est lu en **172 ms** et il ne reste plus aucun air a ignorer.

**D'ou vient alors le temps d'everest ?** Du monde, pas de la structure :
`[DLB-PERF] TACHE COMPLETE en 72.4 s — pre-chargement des chunks 50.8 s (70 %) | hole filler 8.3 s
(11 %) | balayage etendu des naturels flottants ...`. Sur un monde neuf, ~70 % du temps est la
**generation des chunks de la zone** (impossible a rendre instantanee : c'est Minecraft qui genere),
le reste etant le rebouchage des tunnels/failles et le balayage des naturels flottants (T40/T41).
Ce run-là est aussi le meilleur jamais mesure (72,4 s contre 104,5-120,3 s de reference) : la
variable, c'est la charge de la machine de test, pas la structure.

**Ajout T73c (journal)** : si un fichier n'a meme pas d'air dans sa palette (cas de crimsonlake), le
filtre rend la main au parse vanilla et le dit desormais explicitement :
`palette SANS aucun air -- structure deja creuse, lecture vanilla (rien a supprimer, aucune entree
d'air en memoire) -- T73c`. Plus d'ambiguite possible en lisant les logs.

### T75 — les 4 defauts du test in-game du 23/09 22:42 : corriges, causes racines comprises

Ton log (`latest.log` / `debug.log` du 23/09 22:42) contenait 4 defauts. Les 4 sont traites, et
chacun a une cause precise identifiee dans le code — pas un reglage a l'aveugle.

#### 1. « les structures sont dans le ciel ! elles vollent au dessus de la terre »

Deux causes, toutes les deux dans la MESURE de la hauteur d'ancrage :

* **Une cime d'arbre etait prise pour du sol.** Toutes nos lectures de hauteur passaient par
  `MOTION_BLOCKING_NO_LEAVES`, qui saute les feuilles mais **PAS les troncs** : sur une colonne de
  foret, la hauteur rendue est celle de la cime, donc 7 a 26 blocs au-dessus du sol. Ce sont
  exactement les ecarts de ton log : `baseY=69` et `baseY=88` alors que le sol reel est a 62.
* **Une surface d'eau etait prise pour du terrain plat.** Un lac / un ocean est le terrain le plus
  plat du monde (meme Y partout) : il gagnait donc *tous* les classements de « zone plate »
  (`flat=100 %, pente=0`), et `[STRUCT5-SAFETY] … eau=100%` arrivait dans la milliseconde suivante,
  avec une relocalisation « Zone sure a … » et un ancrage fantaisiste.

Correctifs :

* `SafeSurface.isCanopy()` (feuilles + tag `LOGS` + bambou) : une cime n'est plus jamais du sol, ni
  dans `scanGroundY`/`surfaceMaterial` (analyse de zone), ni dans `surfaceScan*` (scoring de zone plate).
* `SafeSurface.groundY(level,x,z,fallback)` : hauteur du **SOL SOLIDE** (ni air, ni cime, ni liquide)
  — c'est elle qui sert desormais a ancrer une structure (`baseY`, zones de repli).
* `SafeSurface.surfaceMaterial()` : la surface lue par l'analyse de zone, liquides inclus (l'eau sous
  une canopee est enfin vue) et cimes exclues.
* `SafeSurface.groundStats(...)` : **sol MEDIAN de toute l'emprise** (echantillonne tous les 4 blocs),
  au lieu d'UNE colonne au centre. C'est ce qui rend le re-ancrage post-smooth fiable : avant, un pic
  de 2x2 blocs ou un reste de pilier sur la seule colonne du centre suffisait a decaler la structure
  (ton log : `baseY 88 -> 87, deltaY=-1`, donc aucun effet).
* Le filtre d'eau du scoring : `FLAT_MAX_WET = 10 %` de colonnes liquides -> candidat **ecarte**
  (journal : `N candidat(s) ecarte(s) : surface en EAU (un lac est plat mais inconstructible)`).

Preuve dans le log de test T75 (monde neuf) :

```
[STRUCT5-FLAT] 323 candidat(s) ecarte(s) : surface en EAU (un lac est plat mais inconstructible) -- T75
[STRUCT5-FLAT] Zone choisie a -45,-40 (candidat #1/24) : flat=100%, pente=3 (terrain reel verifie)
[STRUCT5] observatory : ancrage T75 -- sol median de l'emprise=67 (min=43, max=69, 180 colonnes mesurees)
[STRUCT5] observatory : ancrage FINAL -- baseY=67 et 1er bloc reel a Y=62 (ecart au sol = -5, deltaY=0)
[STRUCT5] dragon      : ancrage T75 -- sol median de l'emprise=69 (min=65, max=77, 228 colonnes mesurees)
[STRUCT5] dragon      : ancrage FINAL -- baseY=69 et 1er bloc reel a Y=35 (ecart au sol = -34, deltaY=-1)
```

Lecture : l'ecart « 1er bloc reel / sol median » est **negatif** (-5 pour l'observatory avec son
offset demande `oy=-5`, -34 pour le dragon avec `oy=-34`) : les structures sont posees **dans** le
sol, comme prevu par leurs offsets. Un ecart positif au-dela de +2 serait une structure suspendue —
c'est la ligne a surveiller, elle est explicite. Et plus aucune ligne `[STRUCT5-SAFETY] … eau=100%`
n'apparait : le lac n'est plus choisi du tout.

#### 2. « les lacs coupes, l'ocean … dans des chunks alentours NON CHARGES … restent figes comme des murs d'eau »

Cause exacte : `fixLiquids` faisait `if (getChunkNow(...) == null) continue;` — un chunk absent etait
**silencieusement jete** (« seuls les chunks charges sont traites ») et **rien ne le demandait** : il
n'etait donc jamais traite, ni maintenant ni plus tard.

Correctifs (T75c/T75d) :

* les chunks absents de l'**anneau proche** (emprise + 48 blocs = les chunks qui bordent notre terrain,
  la ou sont justement les murs d'eau) sont **demandes** en tache de fond puis **retentes** jusqu'a
  6 tours, avec delai croissant ;
* cote propagation du niveau d'eau, un voisin absent declenche la meme demande + retente (avant, le
  niveau s'arretait net a la frontiere du chunk charge) ;
* au-dela de l'anneau proche, la passe reste **opportuniste** (elle traite ce qui est deja en memoire,
  sans forcer) : mon premier essai forcait les 15 876 chunks du rayon de 1000 blocs et faisait grimper
  des ticks a 1809 ms — c'est exactement le « murs d'eau » qu'on veut regler, pas un nouveau gel. Le
  cadrage est visible dans le journal :
  `fixLiquids : anneau proche (emprise + 48 blocs = chunks -13..-3 / -3..6) charge a la demande ; au-dela, seuls les chunks deja en memoire sont traites (T75)`.

#### 3. « faut clairement diviser tout tes temps totaux … au moins par 3 minimum ! »

Trois leviers, tous mesures dans TON log :

1. **L'attente du NBT etait le plus gros poste** : `'dragon' : NBT charge en tache de fond en
   43863 ms` (= 44 s d'attente pure avec « toujours en cours de chargement (10 s / 20 s / 30 s /
   40 s) » a l'ecran), alors que le meme chargement prend 2 859 ms en bac a sable. Cause : le thread
   `DLB-StructureLoader` etait en `MIN_PRIORITY` et se faisait voler son temps CPU par la generation
   de chunks. Correctifs : priorite NORMALE + **rechauffage de fond etale des grosses structures des
   le demarrage du monde** (une toutes les 10 s, uniquement si la memoire le permet, jamais bloquant).
   Verifie au demarrage : `rechauffage de fond 'circus' demande au demarrage (530 Mo de marge)` puis
   `'circus' charge en tache de fond en 3574ms`, `'shipdead' … en 1442ms`. Quand la marge memoire
   descend trop bas, le rechauffage se suspend de lui-meme (`rechauffage de fond suspendu : 2xx Mo`)
   et reprend ensuite : aucun OOM possible.
2. **Le pipeline ne travaillait que 24 % du temps.** Le planificateur s'arretait a 12 ms par tick de
   50 ms : chaque etape terrain de ~3 s de calcul occupait 10 a 14 s de temps REEL — ce que ton log
   montrait sans le dire (`l'etape … a pris 10149 ms de temps REEL`, puis 4328, 2927…). Budget porte
   a **35 ms/tick** (70 % du tick) : ~x2,9 sur TOUTES les phases decoupees, sans risque de gel (les
   tranches sont bornees individuellement, le pire tick possible reste « 35 ms + une tranche »).
3. L'ancien comportement du rayon 1000 (reveler 15 876 chunks) est cadrage : la passe d'eau coûte
   desormais **0,4 s** dans le log de test au lieu de plusieurs secondes de generation.

#### 4. « placer les plantes, arbres et schematics seulement APRES tous les fixwater »

Le terrain complet (smooths, failles, eau, `/fixwater` + `/fixlava`) est deja avant la pose (T39),
et les decors/arbres sont poses apres la pose — l'ordre est donc bon, mais le **fixwater des chunks
voisins n'arrivait jamais** (point 2) : les decors se posaient donc sur un terrain dont l'eau allait
apparaitre plus tard. Avec l'anneau proche traite pour de bon, ce cas disparait ; et par securite :

* `SafeSurface.isSubmerged()` : **aucun arbre n'est plante dans une colonne noyee** ;
* le decor refusait l'eau, il refuse desormais tout liquide (eau et lave) ;
* le message de phase le dit : `decorateFinish (POST-POSE, apres TOUS les fixwater)`.

#### Build et tests

* `BUILD SUCCESSFUL` apres chaque lot (T75a : 26 s, T75b : 14 s, T75c : 13 s, T75d : 13 s) ; jar
  `7ada62a69baf157e03db7058dc85f6bc` (= `build/libs` = `jar/`).
* Run in-game (monde neuf, serveur de test) : `run/logs/t75_run1.log` — 2 observatory + 1 dragon,
  `TACHE COMPLETE en 22,8 s` puis `16,2 s` (observatory) et `18,7 s` (dragon, phase finale), aucune
  exception, aucun `[STRUCT5-SAFETY]`, aucune structure suspendue.

### T74 — « les structures sont dans le ciel » : la cause racine, chiffree

Ton log du 23/09 contient les deux valeurs exactes du bug : `baseY=69` (observatoire) et `baseY=88`
(dragon) alors que le sol est a Y=62 — soit **+7 et +26 blocs**. Ce ne sont pas des valeurs
arbitraires : **7 blocs, c'est la hauteur d'un chene ; 26 blocs, celle d'un grand arbre**. La raison
est une seule ligne de code : toute la mesure d'ancrage passait par la heightmap vanilla
`MOTION_BLOCKING_NO_LEAVES`, qui saute bien les FEUILLES mais **PAS les TRONCS**. Sur une colonne
boisee, la hauteur rendue est donc celle de la CIME, et la structure etait posee au niveau des
cimes — dans le ciel, exactement comme tu l'as vu.

Correctifs (T75a + T74) :

* `SafeSurface.isCanopy()` (feuilles, tag `LOGS`, bambou) : une cime n'est plus jamais « du sol »,
  ni pour l'ancrage, ni pour le scoring de zone plate, ni pour l'analyse de zone ;
* `SafeSurface.groundY()` : la hauteur d'ancrage est desormais lue **bloc par bloc** (ni air, ni
  cime, ni liquide), la heightmap ne servant plus que de borne haute de lecture ;
* `SafeSurface.groundStats()` : le sol est mesure en **mediane sur toute l'emprise** (et non plus sur
  la seule colonne du centre, qui pouvait tomber sur un arbre ou un reste de pilier) ;
* **controle anti-vol avant la pose** : le sol REEL de l'emprise est re-mesure et compare au BAS de
  la structure (offset `oy` compris). Si le bas flottait au-dessus du sol, la structure serait
  descendue exactement de l'ecart, avec un WARN explicite.

Preuve du run de test T74 (`run/logs/t74_run1.log`, monde neuf, dragon) :

```
[STRUCT5-FLAT] 379 candidat(s) ecarte(s) : surface en EAU (un lac est plat mais inconstructible) -- T75
[STRUCT5] dragon : ancrage T75 -- sol median de l'emprise=67 (min=54, max=70, 184 colonnes mesurees)
[STRUCT5] dragon : controle anti-vol OK -- bas de structure=33, sol reel median=65 (marge=32 bloc(s)
           d'enfoncement, 184 colonnes mesurees, T74)
[STRUCT5] dragon : ancrage FINAL -- baseY=67 et 1er bloc reel a Y=33 (ecart au sol = -34, deltaY=4)
[STRUCT5] dragon : re-ancrage Y apres smooth (baseY 63 -> 67, deltaY=4)
```

Lecture : le bas de la structure est **32 blocs SOUS le sol** (c'est l'offset volontaire `oy=-34` du
dragon), donc jamais suspendu ; et l'ecart negatif est desormais **mesure et affiche** a chaque
structure. La ligne `structure SUSPENDUE de N bloc(s) … ancrage corrige` n'apparait que si un vol
etait sur le point de se produire — elle est le temoin a surveiller.

**A retenir** : si tu vois encore une structure en l'air, la ligne `controle anti-vol` du log te
donnera en une seconde le sol reel mesure et la position du bas de la structure.

### T76 — « 1 FREESE ICI » : le gel de 12 979 ms est identifie et supprime (preuve a l'appui)

Ton log du 23/09 22:42 contient ceci, dans cet ordre :

```
22:46:49.376  pre-chargement : 143 chunks ... demandes en tache de fond, budget 25 s
22:46:52.682  pre-chargement TERMINE en 3.304 s
22:47:02.111  prepZone 1/11 : scanTrees termine, 148 arbres sauves
22:47:02.160  [Not Secure] <Dev> 1 FREESE ICI
22:47:02.172  Can't keep up! Is the server overloaded? Running 13606ms or 272 ticks behind
22:47:02.349  [DLB-LAGPROBE] periode de tick de 12979 ms pendant la phase ...
```

**Lecture decisive : le drain de taches du mod est borne a 35 ms par tick (`TASK_BUDGET_MS`), donc
la « periode de tick » mesuree par la sonde (temps entre deux appels de sa boucle de service) est UN
SEUL tick.** Ce n'est pas une phase qui prend 13 s par tranches : c'est 13 s dans un unique tick,
et ce tick contient deux coupables, 3,3 s + 9,4 s.

#### Coupable 1 : la tempete d'application de chunks (3,3 s)

Nous demandions jusqu'a **24 chunks par tick avec 48 en vol** (dimensionne sur le nombre de coeurs).
Le generateur livre alors plus vite que le thread principal n'**applique** les chunks (le passage au
statut FULL est du travail thread principal) : la file grossit, et le tick suivant paie **tout** le
retard d'un coup. Mesure en bac a sable (2 coeurs, donc 6 demandes/tick et 12 en vol) : deux ticks de
**3439 ms** et **2675 ms** pendant `pre-chargement des chunks 20/144` puis `86/144` — le meme
mecanisme, a l'echelle du processeur.

Correctif : on borne ce qui est **en vol**, pas ce qui est genere.
`REQUEST_PER_TICK` 24 -> **1** (option `-Ddlb.requestPerTick=N`) et `MAX_IN_FLIGHT` 48 -> **2**
(option `-Ddlb.maxInFlight=N`). Le debit reste suffisant : la generation est parallele, on ne fait
que **lisser la livraison**.

Resultat mesure : **plus aucune ligne `[DLB-LAGPROBE]` pendant le pre-chargement** ; et — contre
toute attente — le pre-chargement est aussi **plus rapide** (7,788 s -> 6,918 s, soit -11 %), parce
qu'il n'y a plus de file a drainer.

#### Coupable 2 : `scanTrees` (9,4 s) — flood-fill a 100 voisins par noeud

`scanTrees` etait appele d'un bloc dans un tick, et son flood-fill empilait jusqu'a **100 entrees de
file par bloc collecte** (dx,dy,dz = -2..2 x -1..2 x -2..2), soit environ 7 millions d'insertions et
autant d'allocations pour 148 arbres. C'est exactement les 9,43 s du log (22:46:52.683 -> 22:47:02.111).

Correctif, en deux temps :

* **Balayage bornE au tronc** (carre 3x3 horizontal x hauteur du tronc, pour couvrir les troncs 2x2
  du chene noir et du jungle) : plus de file, plus d'allocation par bloc.
* **Arret des qu'on atteint le sol** : sous le sol il n'y a jamais de tronc. La lecture descend du
  sommet, teste le tronc AVANT l'arret (cime d'epicea, arbre sous un couvert : rien n'est manque), et
  s'arrete au premier bloc de terrain. Une colonne sans arbre coute 1 a 3 lectures au lieu de 48
  (~30 000 colonnes x 48 = 1,44 M lectures avant).

Resultat mesure : `scanTrees termine, 12 arbres sauves en 243 ms` (dont 185 ms d'un ancien algorithme
rejoue pour verification) — soit **58 ms** de travail reel, contre 9 430 ms dans ton log.

**Decouverte au passage (et c'est important pour toi) : les arbres sauves etaient mal comptes.**
`replantTrees` ne se sert JAMAIS de la liste de blocs : il replante une feature d'arbre vanilla a
partir de `baseX/baseZ/type`. La liste ne servait qu'a deriver l'espece. Or l'ancien flood-fill
marquait « vu » tout un volume autour de chaque arbre, ce qui **supprimait les troncs voisins** de la
liste. Et a l'inverse il comptait comme arbres des `minecraft:big_dripleaf_stem` — des plantes de
**grottes luxuriantes**, 30 blocs sous terre, que `isLog()` classe dans les buchEs.

Preuve, dans le meme run, sur la MEME zone (outil de verification ci-dessous) :

```
VERIF ARBRES (T76) : nouveau=12 ancien=23 identiques=3 OUBLIES_PAR_LE_NOUVEAU=20 EN_TROP=9
```

Les 20 « oublies » sont tous des `big_dripleaf_stem` (la trace de colonne le montre : `64:Sand`,
`62:Terracotta`, `60:Water` ... aucun tronc) ; les 9 « en trop » sont de **vrais arbres** que l'ancien
algorithme perdait a cause de son marquage. Consequence concrete : `replant : **8** arbres reels
replantes` contre **4** dans le run precedent.

#### Coupable 3 : le diagnostic accusait la mauvaise etape

Ton log dit :

```
l'etape qui vient de finir a pris 10149 ms de temps REEL (prepZone 2/11 : prefillFoundation termine)
```

Cette etape a en realite dure **720 ms** (22:47:02.111 -> 22:47:02.831). Les 10 149 ms sont le temps
depuis l'etape PRECEDENTE, parce que la ligne `scanTrees` n'appelait pas `step()` et ne mettait donc
pas `LAST_STEP_MS` a jour : les 9,4 s de `scanTrees` etaient facturees a l'etape d'apres. Correctif :
la ligne passe par `step()` et affiche sa propre duree.

**Outil laisse a ta disposition** : `DLB_TREE_CHECK=1` (variable d'environnement, ou
`-Ddlb.treeCheck=1`) rejoue l'ancien algorithme sur la meme zone dans le meme run et journalise
`nouveau / ancien / identiques / OUBLIES / EN_TROP`, plus la trace des colonnes manquees. L'ancien
code est **conserve** dans le mod pour cet usage ; il n'est jamais appele en jeu normal.
(A noter : `JAVA_TOOL_OPTIONS` n'atteint pas le JVM du jeu lance par `runServer` — d'ou la variable
d'environnement.)

#### Ce qui reste, et qui est deja identifie (pas corrige dans cette tache)

Un seul tick long subsiste : **`naturalize`**, qui boucle d'un bloc sur toute la zone (43 000 a 54 000
colonnes) pour poser herbes, fleurs et champignons. Preuve dans le run dragon :

```
23:41:31  naturalize : 244 herbes, 127 fleurs, 11 champignons places (zone 248x218)
23:41:31  cleanupZone : debut sur 40176 colonnes (419 tranches)
23:41:32  [DLB-LAGPROBE] periode de tick de 1753 ms pendant la phase « cleanupZone 0/40176 »
```

Le LAGPROBE nomme `cleanupZone` alors que le travail est dans `naturalize` (qui n'appelle pas
`setPhase`, exactement le meme piege que `scanTrees`). Le decouper est la prochaine etape naturelle :
le passeur `ColumnPass` (deja utilise par `cleanupZone`, `guardWaterEdges`, `verifyGrassSurface`)
fait exactement ce travail. **Ce n'est pas une regression de T76** : ce tick existait avant
(3799 ms pendant `cleanupZone` dans `t75_run1.log`).

### T77 — `naturalize` : la derniere passe monolithique est decoupee (fin du dernier tick > 1 s)

#### Le defaut, et pourquoi il etait invisible

Le run T76 montrait ceci, dans cet ordre :

```
23:41:31  naturalize : 244 herbes, 127 fleurs, 11 champignons places (zone 248x218)
23:41:31  cleanupZone : debut sur 40176 colonnes (419 tranches)
23:41:32  [DLB-LAGPROBE] periode de tick de 1753 ms pendant la phase « cleanupZone 0/40176 »
```

La ligne de `naturalize` est **toujours** immediatement suivie de celle de `cleanupZone`, et la sonde
accusait `cleanupZone`. Cause : `naturalize` ne passait pas par `setPhase`, donc son temps etait
facture a la phase suivante — **exactement le meme piege que `scanTrees` en T76**. La zone 248x218
= 54 064 colonnes (42 813 sur l'observatory) etait traitee d'un bloc dans UN tick.

#### Correctif : le passeur commun, deja utilise par toutes les autres passes

`naturalize` avance desormais par `ColumnPass` / `startColumnPass` (le meme passeur que
`cleanupZone`, `guardWaterEdges`, `verifyGrassSurface`, le balayage des flottants...) :

* tranches de 96 colonnes, **budget adaptatif** (`sliceBudgetMs` : 2 a 16 ms selon le MSPT) ;
* **etiquette de phase** -> le LAGPROBE nomme maintenant la bonne passe ;
* **report des colonnes dont le chunk n'est pas charge** (T70), avec reprise automatique ;
* la naturalisation elle-meme est **inchangee** : meme bruit coherent `valueNoise2D` (donc les memes
  touffes et clairieres aux memes endroits), memes densites, memes pools de fleurs/champignons.
* les compteurs (herbes / fleurs / champignons) sont passes par **closure** (`int[]`), pas par des
  variables statiques : deux pipelines ne peuvent pas melanger leurs compteurs.

#### Regression introduite par le decoupage, detectee et corrigee dans la meme tache (T77b)

Mesure du premier run T77 :

```
naturalize ... : debut sur 42813 colonnes (446 tranches)
naturalize ... : 5757 colonne(s) en attente de chunk
naturalize ... : 5757 colonnes non traitees (chunk absent) -- elles n'ont pas ete traitees
```

**5 757 colonnes sur 42 813 (13 %) laissees sans vegetation.** Cause : le passeur saute — par
conception (T70) — les colonnes dont le chunk n'est pas charge, pour ne jamais declencher de
generation synchrone. Or `naturalize` balaie un anneau **plus large** que la zone tenue par
`ChunkKeeper` : `terrainRing() + NATURALIZE_EXTRA_RING` (16 blocs de plus). L'ancienne version
monolithique les traitait, mais au prix de la generation synchrone — c'est-a-dire du gel.

Correctif : la zone tenue est etendue a l'anneau de naturalize **avant** de lancer la passe.
`ChunkKeeper.track()` **etend** la zone (il prend le min/max des bornes de chunks) : aucune epingle
existante n'est perdue, et la couronne de chunks supplementaire est demandee en tache de fond, au
debit borne de T76. Le passeur attend alors ces chunks au lieu de sauter les colonnes.

Preuve dans le log de test (meme zone -44,-38, monde neuf) :

```
naturalize ... : debut sur 42813 colonnes (446 tranches)
naturalize ... : zone pas encore entierement chargee -- tranche reportee (le chunk system charge, le serveur n'est pas bloque)
naturalize ... : fini (42813 colonnes, 4502 ms)
naturalize : 208 herbes, 91 fleurs, 4 champignons places (zone 213x201)
-- plus AUCUNE ligne « colonnes non traitees »
```

#### Mesures

| observatory, zone -44,-38 | T76 (avant) | T77 | T77b (final) |
|---|---|---|---|
| `naturalize` | un tick de 3 491 ms (LAGPROBE) | passe etalee, 1 101 ms, **5 757 colonnes perdues** | passe etalee, 4 502 ms (attend ses chunks), **0 colonne perdue** |
| pire tick du pipeline | 3 491 ms | 1 372 ms | **1 257 ms** |
| `TACHE COMPLETE` | 23,6 s | 23,8 s | 25,6 s |
| exceptions | 0 | 0 | **0** |

Le `TACHE COMPLETE` prend ~2 s de plus en T77b : c'est le prix, assume, d'attendre les chunks de
l'anneau plutot que de laisser 13 % de la zone sans vegetation. Les deux variantes suppriment le gel ;
la troisieme supprime la perte.

#### Ce qui reste, dit clairement

Le pire tick est encore **1 257 ms** (contre 12 979 ms au depart, puis 3 491 ms). Il ne vient plus
d'une passe monolithique mais de **quelques colonnes isolees et couteuses**, que le passeur
journalise maintenant nommement :

```
cleanupZone : 5 colonne(s) lente(s) (> 50 ms chacune, pire 462 ms, 963 ms au total)
naturalize (herbes, fleurs, champignons) ... : 1 colonne(s) lente(s) (> 50 ms chacune, pire 294 ms)
```

Une colonne couteuse est **atomique** (lecture d'un chunk fraichement genere, decodage, lumiere) :
aucun budget ne peut la subdiviser. Mais elle est desormais **visible et chiffree** dans le log, ce qui
permet de la traiter au cas par cas si tu la vois encore a l'ecran.

---

## T78 -> T79 — fixwater economise + le repli « pente minimale » ne fige plus le serveur 60 s (25/09)

**Commit :** `T78+T79: fixwater a sortie anticipee ; repli pente-minimale borne (gel 60s supprime)`

### T78 — `fixWaterNearStructure` s'arrete des que l'eau est etalee

**Probleme (retour in-game 23/09)** : `fixWaterNearStructure` lancait **4 passes completes
identiques** sur toute l'emprise (4 x 8613 a 4 x 9976 colonnes), a chaque appel et a chaque
sous-etape du pipeline -- 4,9 s (observatory) et 6,4 s (dragon) pour un resultat identique des
la 2e passe (la fonction est **idempotente** : une eau deja etalee ne bouge plus).

**Correctif** : les passes deviennent successives (`passe N/4`) et la boucle **s'arrete des que
`delta == 0`**, avec le compte des colonnes economisees dans le log :
`passe 1/4 sans aucune correction -- l'eau est deja etalee, arret anticipe (3 passe(s) et
25 839 colonne(s) economisees)`. `finishFixWater` n'est appele qu'une fois (log
`aucune eau courante a corriger -- zone saine` quand il n'y a rien a faire). Le comportement
metier est inchange : si une passe corrige encore quelque chose, la suivante tourne.

### T79 — le dernier gel silencieux (60 s, watchdog) : repli « pente minimale »

**Decouvert pendant le test T78** (run 02:30) : le serveur a ete **tue par le watchdog**
(`A single server tick took 60.02 seconds`) juste apres
`[STRUCT5-FLAT] scoring termine : 0 candidat(s)`, sans une seule ligne de log pendant le
blocage (gel muet, exactement la classe de bug signalee en jeu).

**Cause exacte** : quand le scoring ne retient aucun candidat (ici : toutes les cellules de la
grille etaient dans l'emprise de l'observatory deja posee), `findFlat()` retombe sur le repli
« pente minimale ». Ce repli est la **seule boucle du projet restee sans filtre ni budget** :
- la grille de scoring ne mesure que les chunks **deja en memoire** (49x49 cellules, 484
  connues -> 3 ms) ;
- le repli, lui, mesurait **toutes** les cellules du carre de recherche avec `measureSlope()`
  (jusqu'a 121x121 = 14 641 cellules x ~49 lectures de heightmap = ~700 000 lectures) et une
  heightmap non primee coute un **rescan complet du chunk** (voir T58, 180 us par lecture).

**Correctif (meme famille que T49/T58/T70)** :
1. le repli ne mesure plus que les chunks **deja charges** (`SafeSurface.loaded`, aucune
   generation declenchee) -- meme filtre que la grille de scoring ;
2. **budget de temps de veille** (500 ms) teste en cours de balayage, avec log de sortie
   explicitant cellules mesurees / ignorees / candidats ;
3. **sonde toutes les 1500 ms** (`[STRUCT5-FLAT-PROBE] repli pente-minimale en cours`) :
   plus jamais de gel muet a cet endroit ;
4. log d'entree et de fin systematiques (avant : un seul log possible, apres coup).

**Resultat** : `529 cellule(s) mesuree(s) en 0 ms, 1971 ignoree(s) (chunk non charge),
0 candidat(s)` puis `Aucune zone valide trouvee -- repli sur une position hors chunk avec
hauteur REELLE` -> ancrage T75 `dragon : controle anti-vol OK -- bas de structure=37, sol reel
median=72 (marge=35 bloc(s) d'enfoncement)` : **aucune structure flottante**, aucune exception,
et le serveur ne meurt plus.

### Preuve in-game (25/09, `run/logs/latest.log`, monde neuf, seed 1337)

| mesure (monde neuf, run du 25/09 02:44) | observatory | dragon |
|---|---|---|
| TACHE COMPLETE | 24,6 s | 33,1 s |
| pre-chargement des chunks | 7,1 s (29 %) | 13,5 s (41 %) |
| pire tick (DLB-CLAMP) | 1322 ms | **621 ms** (0 tick > 1 s) |
| ticks > 100 ms | 48 | 73 |
| `naturalize` | 4,0 s (42 813 col.) | 2,8 s (54 064 col.) |
| `fixWaterNearStructure` | **42 + 11 + 13 ms** (3 passes economisees, 25 839 col.) | idem (29 928 col.) |
| `replant` | 8 arbres reels | 116 arbres reels |
| SETTLE | 2 ticks | 2 ticks |
| exceptions | 0 | 0 |

**T79 (le gel de 60 s)** -- `[STRUCT5-FLAT] repli pente-minimale : balayage 50x50 cellules
(pas 5), chunks deja charges seulement, budget 500ms` puis `529 cellule(s) mesuree(s) en 0 ms,
1971 ignoree(s) (chunk non charge), 0 candidat(s)` : la ou le run precedent mourait sur
`A single server tick took 60.02 seconds` (watchdog, arret force du serveur), le repli se
termine maintenant en **0 ms** et le pipeline continue normalement (ancrage T75, anti-vol OK).

Preuve archivee : `TEST_T78_T79_2026-09-25.log` (synthese + lignes brutes) ; log complet dans
`run/logs/latest.log`. Jar `jar/deep_lucky_block-1.0.jar` = md5 `57e7db1838128d74de4c2cd881d79749`.

### Ce qui reste
- Le ÷3 global n'est **pas encore prouve** : la prochaine cible identifiee est la repetition des
  passes lourdes sur la meme zone (`guardWaterEdges` 4x, `cleanupZone` 5x dans le meme pipeline)
  -- meme remede que T78 : sortie anticipee quand la passe ne corrige plus rien.
- `pre-chargement des chunks` reste le premier poste (29 a 41 %) : il est **non bloquant** (aucun
  tick > 1 s sur le run dragon) mais c'est le prochain levier de temps total.
