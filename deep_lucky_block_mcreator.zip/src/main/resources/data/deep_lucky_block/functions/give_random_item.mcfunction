# give_random_item.mcfunction - TEST 100% Bottes
give @s netherite_boots{Enchantments:[{id:"minecraft:protection",lvl:3},{id:"minecraft:feather_falling",lvl:3},{id:"mme:dodge",lvl:2}]} 1
say Test : Bottes Netherite données