# drop_random_loot.mcfunction - Version corrigée

give @p netherite_boots 1
say Test Bottes Netherite données