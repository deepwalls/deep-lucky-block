package deepluckyblock.block;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;

/**
 * STUB : ce bloc n'est plus utilise.
 * Le Crimson Lake est declenche par sa procedure (CrimsonLakeStructureSpawnProcedure),
 * pas par un bloc spawner. Ce fichier est garde uniquement pour la compatibilite
 * de compilation. Tu peux le supprimer definitivement plus tard.
 */
public class CrimsonLakeSpawnerBlock extends Block {
    public CrimsonLakeSpawnerBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }
}
