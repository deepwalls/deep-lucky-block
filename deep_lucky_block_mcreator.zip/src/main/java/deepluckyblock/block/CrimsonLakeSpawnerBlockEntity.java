package deepluckyblock.block;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;

/**
 * STUB : cette block entity n'est plus utilisee.
 * Gardee uniquement pour la compatibilite de compilation. Tu peux la supprimer plus tard.
 */
public class CrimsonLakeSpawnerBlockEntity extends BlockEntity {
    public CrimsonLakeSpawnerBlockEntity(BlockPos pos, BlockState state) {
        super((BlockEntityType<?>) null, pos, state);
    }
}
