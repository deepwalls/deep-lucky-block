package deepluckyblock.procedures;

public class SpawnStructureProcedure {
    public static void execute() {
    }
}