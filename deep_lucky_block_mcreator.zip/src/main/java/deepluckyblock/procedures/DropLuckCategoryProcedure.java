package deepluckyblock.procedures;

public class DropLuckCategoryProcedure {
	public static void execute() {
		double luck = 0;
	}
}