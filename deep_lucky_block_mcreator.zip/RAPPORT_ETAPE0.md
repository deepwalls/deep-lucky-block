# RAPPORT D'ÉTAPE 0 — Deep Lucky Block (NeoForge 1.21.1)

Date : 19/09/2026 — Aucune ligne de code écrite. Aucune recherche web lancée (comme demandé).
Dépôt : `https://github.com/deepwalls/deep-lucky-block` (CAS B : clone). HEAD = `8fc7d8d`, branche unique `main`.
Archive décompressée : `/home/user/projet/mod_project` (1945 fichiers).

---

## 0. AVERTISSEMENT DE RÉCUPÉRATION (à lire, ça change des choses)

1. **Cinq documents ont été supprimés du dépôt** par une série de commits « Delete … » (c5f0bbb, 63f9a6b, 0bf54bf, 7928fab, 58f2f4d, 39e4b44, 78b269d, f7cda5d, 1aad247…) puis seuls certains ont été ré-uploadés. **Il n'y a plus, à la racine du dépôt :** `LIRE-MOI-IMPORTANT.md`, `arena-conversation.md`, `arena-conversation.json`, `dernierslogs2..6.txt`, `image-1..4.png`.
   → Je travaille donc sur **les exemplaires de `mod_project/`** (md5 identiques à la racine pour PORT_REPORT, PATCH, README, REPARER, audit CSV).
2. **`arena-conversation.md` est un export raté** : « Curseur valide : `null` — 0 messages récupérés ». Le contenu réel est dans `arena-conversation.json` (`etapes.rsc.texte` + `etapes.html.texte`) que j'ai extraits (`/tmp/rsc.txt`, 2 148 290 car. ; `/tmp/html_plain.txt`, 73 851 car.).
   **Conséquence** : l'export s'arrête sur la session `01a07455` (06→14/09). **Les 4 derniers jours (15→18/09), ceux des structures et du terrain, n'y figurent PAS.** J'ai reconstitué cette période par le code, les horodatages de fichiers et les logs.
3. **`REPARER.bat` n'est pas un script** : c'est une page HTML « Google Drive — Virus scan warning » (2 428 o). Son contenu réel n'est pas dans l'archive → je ne peux pas lire ce qu'il corrige.
4. **`build/` a survécu mais pas `~/.gradle`** : les classes compilées du 18/09 13:36 sont là (preuve que le projet compilait), mais le cache Gradle de la machine précédente est absent.
5. **`.mcreator` et `.mcreator/userSettings` sont datés du 18/09 à 23:39**, soit **9 h 38 après le dernier log de l'archive (14:01)**. Il y a donc eu une session MCreator (et probablement un test en jeu) **dont aucun log ne figure dans l'archive**.

---

## 1. Ce que fait le mod « Deep Lucky Block »

ModId `deep_lucky_block`, version `1.0`, généré par MCreator 2026.1 puis repris à la main (1 415 fichiers dans `src/`, 54 Mo).

- **Cœur** : blocs « lucky » (Deep / Supreme) qui, à la casse, tirent des items aléatoires par **grade/rareté** (`GenerateLuckyItemProcedure`, ~3 300 lignes) + un système de **Luck** (bonus en %) lu depuis un DataComponent et une **roue de drops**.
- **418 enchantements autonomes**, entièrement **data-driven** (JSON `data/deep_lucky_block/enchantment/`), effets gérés par 3 gros handlers (`UniversalEnchantmentHandler`, `EquipmentExpansionHandler`, `FishingTridentElytraHandler`), tooltips, auras, glint coloré.
- **Items/armures** : Samouss (armure de boss), Lunettes du Patron, Bo' Cube De Bois, armes/outils enchantés, potions.
- **Coffres « Lucky Chests »** auto-remplis (mixin `ItemChestTagTransferMixin`, drapeaux `slb_*` en `NeoForgeData`).
- **NPC Manish** (villageois commerçant, 7 offres, `ManishDiscountTint`), entités (End Knight, Slime King, Shadow Mirror, Jerry…).
- **Structures** : 8 grosses structures NBT (circus, shipdead, everest, citadel, observatory, dragon, crimsonlake, sand_hourglass) + 153 décors, posées par `Structures1..5Procedure` / `StructureScatterDecor`, avec **préparation de terrain** (`StructureTerrainPrep` : clear, smooth gaussien, replant, naturalize, water-guard).
- **Divers** : 51 advancements, HUD/cœurs élémentaires, configs TOML (luck infusion, drop, tillage…), compat LuckyTools/LuckyXp/ImmediatelyFast.

## 2. État d'avancement

| Domaine | État |
|---|---|
| Port 1.20.1 → 1.21.1 | **Fait** (PORT_REPORT 05/09 : BUILD SUCCESSFUL, `runServer` « Done (6.5s)! », 1320 recettes / 1450 advancements, 0 warning) |
| Enchantements data-driven | **Fait et vérifié** : 418 JSON = 418 `CustomEnchantment.create()` = 418 lignes du CSV d'audit (0 écart dans les deux sens) |
| DataComponents | **Fait** : `DeepNbt` encapsule `CUSTOM_DATA` ; plus aucun `getTag()/setTag()` legacy sur ItemStack |
| Mixins | **Actifs** (contrairement à la doc) : 6 déclarés, 7 fichiers orphelins |
| Généralisation mobs (enchantements) | **Fait** (EntityTickEvent.Post, `getItemBySlot`) |
| Manish discount + teinte | **Fait** (`client/ManishDiscountTint.java`) |
| Luck Infusion config | **Fait** (enregistrée, kit + live identiques) |
| **Structures / terrain** | **CASSÉ — c'est le sujet du blocage** |
| Couleurs/glint, coffres, cœurs | Fonctionnels d'après les logs du 18/09 |

**Ce qui casse précisément** : le pipeline de préparation de terrain d'une **grosse structure** (chemin `Structures5Procedure` → `StructureTerrainPrep.prepZone`) **se fige et n'écrit plus rien dans le log**, indéfiniment. Everest (qui passe par un autre chemin « raw ») se pose bien, lui (22 s).

## 3. Dernière action de la session précédente, horodatée

- **Dernière écriture de code** : `src/main/java/deepluckyblock/procedures/StructureTerrainPrep.java` — **mtime 18/09/2026 13:21** (seul fichier daté après le lot de 13:18 ; 145 563 o). C'est le correctif « préchargement étalé de la zone AVANT tout accès » dans `prepZone()`.
- **Compilation correspondante** : `build/classes/java/main/deepluckyblock/procedures/StructureTerrainPrep.class` daté **18/09 13:36:40** et contenant bien les chaînes `preloadChunksBatched` / `prepZone 0/11` → **le correctif a été compilé**.
- **Fin de session IA** : session `01a0a280-5d83-7044-9aa7-e6289ed7f2ea`, `updatedAt = 2026-09-18 11:53:38 UTC` = **13:53:38 Paris**. Elle s'est arrêtée **avant** de tester ce correctif en jeu.
- **Dernier test en jeu (dernier log de l'archive)** : `run/logs/latest.log`, 13:50:54 → **14:01:23**, terminé par un arrêt manuel.
- **La ligne exacte du plantage/gel cherchée** (log `2026-09-18-3.log.gz`, époque 13:04→13:36) — **dernière ligne du fichier, plus rien après** :

```
[18Sep2026 13:07:38.328] [Server thread/INFO] [deepluckyblock.procedures.Structures5Procedure/]: [STRUCT5] citadel -> 53, 26, -161 (baseY=73, minRelY=12, rot=CLOCKWISE_90, 25706ms)
[18Sep2026 13:07:38.385] [Server thread/INFO] [deepluckyblock.procedures.Structures5Procedure/]: [STRUCT5] citadel : 113930 blocs (1 verre supprime)
```

`Structures5Procedure.java:1167` est **exactement** cette ligne ; l'instruction suivante (l.1173) est `StructureTerrainPrep.prepZone(...)`. Le code n'a plus jamais loggé → le gel est **à l'entrée du pipeline terrain**. C'est mot pour mot le scénario documenté dans le code lui-même (« citadel : 113930 blocs » puis PLUS RIEN).

## 4. L'erreur encore présente dans les logs

**Il n'y a AUCUNE exception Java dans les logs récents.** Vérifié sur `latest.log`, `debug.log`, `2026-09-18-1/2/3.log.gz` : zéro `Exception`, zéro `Caused by`, zéro stacktrace. C'est un **gel silencieux**, pas un crash — d'où ton ressenti « tout freeze, aucune nouvelle dans les logs, ça dure à l'infini ».

Les seules stacktraces de l'archive sont **anciennes (05-06/09) et déjà corrigées** :

| Fichier | Erreur | Statut |
|---|---|---|
| `crash-2026-09-06_06.48.50` | `NullPointerException: … DeepNbt.getOrCreateTag(ItemStack) is null` → `CustomCreativeTabs.lambda$static$2(CustomCreativeTabs.java:79)` | Corrigé (DeepNbt commite puis relit la référence vivante) |
| `crash-2026-09-06_07.04.52` | `IllegalStateException: Not building!` → `BufferBuilder.ensureBuilding(68)` ← `ModelPart.compile` ← `BlockEntityWithoutLevelRenderer.renderByItem` ← `ItemRenderer.render` (avec `ItemRendererEnchantMixin` dans la pile) | À re-vérifier (rendu BEWLR) |
| `crash-2026-09-05_12.52.39` | `Trying to access unbound value: ResourceKey[minecraft:armor_material / deep_lucky_block:samouss]` | Corrigé (v5/v8) |
| `crash-2026-09-05_12.10.10-fml` | Mod loading failed | Résolu depuis |

## 5. Changements prévus / en cours mais **jamais appliqués ou mal appliqués**

| # | Fichier / méthode visée | Ce qui manque |
|---|---|---|
| 1 | `StructureTerrainPrep.prepZone()` (l.184-225) | Le correctif du 13:21 est **présent et compilé, mais JAMAIS testé en jeu** : après 13:36, aucun log ne montre de spawn de citadel/shipdead/circus. La session est morte avant le test. |
| 2 | `StructureTerrainPrep.prepZoneAfterPreload()` (l.231-292) | L'intention documentée (« chacune annonce désormais sa fin, on peut donc localiser un arrêt à coup sûr ») n'est appliquée **qu'aux étapes 2/11, 3/11 et 4/11**. Les étapes **5 → 10 n'ont aucun log** : `smoothPass(7×7,50)`, `smoothPass(15×15,12)`, `verifyGrassSurface`, `cleanupZone`, `fixWaterNearStructure`. → fenêtre **100 % silencieuse** = ton « aucune nouvelle dans les logs ». |
| 3 | `guardWaterEdges()` (l.2030-2078), `clearWaterPockets()` (l.303-329), `fixWaterNearStructure()` (l.2080-2117) | Ces passes **synchrones non budgétées** (triples boucles `getHeight` + `getBlockState` + `setBlock` sur toute la zone) sont exécutées **dans la même tâche planifiée** que le `onDone` de `clearFootprint`, donc dans **un seul tick**, avec **aucun log avant la fin**. Rien ne les étale comme le fait `preloadChunksBatched`. |
| 4 | Backlog du 14/09 après 06:19 | (a) Manish discount + teinte → **fait** ; (b) `LuckInfusionConfig.SPEC` jamais enregistrée → **fait** (kit + live identiques) ; (c) Bo' Cube traduisible → clé présente (`block.deep_lucky_block.bo_cube_de_bois`) ; (d) audit EN → `en_us`/`fr_fr` = 1812 clés chacun, 0 manquante, 27 valeurs identiques (noms propres, à trancher au cas par cas). |
| 5 | `src/main/resources/data/deep_lucky_block/structures/` (pluriel) | **Dossier mort 1.20.1 jamais supprimé : 24 Mo** (les 8 mêmes .nbt + un `shipdead.nbt.nbt` — extension doublée). Idem `advancements/`, `recipes/`, `loot_tables/`, `forge/`, `data/minecraft/tags/entity_types/`. Ils gonflent le jar et prêtent à confusion. |
| 6 | `SlbDiagnostics.banner()` | Le bandeau de version documenté comme **le** moyen de vérifier qu'on charge le bon jar est émis par `System.out.println` → **absent de `run/logs/latest.log`** (présent uniquement sur la console). Non vérifiable côté fichier de log. |

## 6. Tâches restantes, dans l'ordre

1. **T1 — Rendre le pipeline terrain observable et borné, puis re-tester citadel en jeu.** *(risque FORT)*
   `StructureTerrainPrep.prepZoneAfterPreload` (logs 5→10 + découpage en tâches étalées de `guardWaterEdges` / `clearWaterPockets` / `fixWaterNearStructure`), appelants `Structures5Procedure.java:1167-1173`, `Structures4Procedure.java:910`, `CrimsonLakeStructureSpawnProcedure.java:401`.
2. **T2 — `./gradlew build` dans le sandbox.** *(risque MOYEN)* `build/` n'est pas persisté dans les snapshots Arena et `~/.gradle` est absent → build **complet de zéro** ; la session précédente échouait en OOM sur 1,9 Go de RAM et contournait avec `JAVA_TOOL_OPTIONS="-Xmx700m -XX:+UseSerialGC -XX:ActiveProcessorCount=1 -XX:MaxMetaspaceSize=192m"`.
3. **T3 — Vérifier ce qui tourne réellement chez toi.** *(risque MOYEN)* `.mcreator` du 18/09 23:39 : il existe une session postérieure au dernier log. Sans son log, on ne peut pas confirmer si le gel actuel est celui du 13:07 (citadel) ou un nouveau.
4. **T4 — Aligner la documentation sur la réalité** *(risque FAIBLE)* : mixins JAVA_17 vs « JAVA_21 », « 7 mixins » vs 6 déclarés, « mixins abandonnés » vs mixins actifs, « smooth 3 passes » vs 50/12, `REPARER.bat` qui n'est pas un script.
5. **T5 — Nettoyage des dossiers data morts (24 Mo)** *(risque FAIBLE, à ton accord)* : `structures/`, `advancements/`, `recipes/`, `loot_tables/`, `forge/`, `tags/entity_types/`.

## 7. Incohérences documentation ↔ code

1. **Mixins « abandonnés » : faux.** `neoforge.mods.toml` déclare `[[mixins]] config = "deep_lucky_block.mixins.json"`, `build.gradle` met `MixinConfigs` + `MixinConnector` au manifest, et le runtime loggue « Compatibility level set to JAVA_21 » + « Reference map … could not be read ». Les mixins sont **bien actifs**. Le dossier `_deprecated_mixins_backup/` ne contient qu'**1** fichier (`GuiHeartSuppressMixin.java.bak`) — je n'y touche pas.
2. **`README-INSTALL.txt` annonce `deep_lucky_block.mixins.json` en `JAVA_21`** ; les **trois** copies du fichier disent `JAVA_17` (kit + live + racine).
3. **`LIRE-MOI-IMPORTANT.md` attend « Prepared 7 mixins »** ; le JSON déclare **6** mixins (1 commun + 5 client). Il existe en plus **7 fichiers de mixin orphelins** jamais déclarés (`LuckyStatsSyncMixin`, `LuckyTweaksDimensionPoolMixin`, `LuckyXpEventRollsMixin`, `LuckyXpRouletteOverlayMixin`, `LuckyXpShowerMixin`, `DlbMixinPlugin`, `GlintMixinConnector`).
4. **`LIRE-MOI` dit de vérifier `[SLB-V8]` « dans le log »** : le bandeau est un `System.out.println`, donc **hors `latest.log`**.
5. **`StructureTerrainPrep` documente « SMOOTH … 3 passes »** (et `SMOOTH_PASSES = 3`) alors que le pipeline appelle **50** et **12** passes. La constante est **morte**.
6. **Deux kits de patch identiques coexistent** : `FIXES_MCREATOR/` (7 fichiers, à la racine du projet, **jamais lu**) et `src/main/resources/deepluckyblock_patch/FIXES_MCREATOR/` (celui qu'utilise `applyMcreatorPatch`). Éditer le mauvais = patch invisible.
7. **`gradle.properties` ne contient ni `modId` ni `version`** ; la version est en dur dans `build.gradle` (`1.0`) **et** dans `neoforge.mods.toml` (`1.0`) → deux sources de vérité.

## 8. Contenu réel de l'archive

**`deep_lucky_block-neoforge-1.21.1.mcreator` : PRÉSENT** — 448 553 o, daté du 18/09 à 23:39.

Arborescence de `mod_project/` après décompression (1945 fichiers) :

```
.eclipse/ (2)        .gradle/ (35)      .mcreator/ (50)     FIXES_MCREATOR/ (7)
_deprecated_mixins_backup/ (1, NE PAS TOUCHER)             assets_src/ (8)
build/ (256, dont classes/ du 18/09 13:36)                 elements/ (47 .mod.json)
gradle/ (2)          jar/ (VIDE)         models/ (11)       pixel_gen/ (10)
run/ (86, logs + crash-reports + config)                   src/ (1415, 54 Mo)
LIRE-MOI-IMPORTANT.md (8 272 o)          PORT_REPORT.txt (26 400 o)
PATCH_GENERATELUCKYITEM.md (3 250 o)     README-INSTALL.txt (1 993 o)
REPARER.bat (page HTML Google Drive)     audit_enchant_table.csv (419 lignes)
arena-conversation.md (2 130 o, export raté) / .json (5 523 099 o)
build.gradle (7 305 o)  settings.gradle (377 o)  gradle.properties (760 o)
gradlew / gradlew.bat   mcreator.gradle (0 o)   deep_lucky_block-neoforge-1.21.1.mcreator
```

`src/` : 4 namespaces de données (`deep_lucky_block`, `luckytools`, `minecraft`, `supreme_lucky_block`) — 418 enchantements, 51+51 advancements, 30+30 recettes, 174+9 structures .nbt (20 Mo + 24 Mo), 16 fichiers `config/`, 47 éléments MCreator.

---

## CHECKLIST TECHNIQUE 1.21.1 — vérifiée

| Point | Verdict |
|---|---|
| `META-INF/neoforge.mods.toml` | **OK** (`javafml`, `loaderVersion [4,)`, `modId deep_lucky_block`, `version 1.0`, deps `minecraft [1.21.1,1.22)` + `neoforge [21.1,)`, `enumExtensions`). Pas de `mods.toml` ni `neoforged.mods.toml` résiduel. |
| Séparation des bus | **OK**. 40 classes avec `@SubscribeEvent`, **toutes** annotées `@EventBusSubscriber`. 9 en `bus = MOD` (init/registres/payloads) ; le sous-handler GAME (`EventBusVariableHandlers`) est bien en bus par défaut. `DeepLuckyBlockMod` s'enregistre via `NeoForge.EVENT_BUS.register(this)`. |
| Registres | **OK**. `DeferredRegister` partout (`createBlocks`, `BuiltInRegistries.*`, `Registries.*`). Plus aucun `DeferredRegister.create(ForgeRegistries.ENCHANTMENTS)` : c'est désormais un registre **datapack**. Zéro `net.minecraftforge.*` en code (1 seule occurrence, dans un commentaire). |
| DataComponents | **OK**. `util/DeepNbt.java` fait le pont `CUSTOM_DATA`/`CustomData` ; aucun `getTag()/setTag()` legacy sur ItemStack. |
| Enchantements data-driven | **OK**. 418 JSON ↔ 418 `create()` ↔ 418 lignes CSV, 0 orphelin. |
| Mixins | **À SIGNALER** : pas abandonnés (voir §7). `defaultRequire: 0` → un mixin qui casse **échoue en silence** (pas de crash, mais fonctionnalité perdue) : cohérent avec le `Not building!` du 06/09. |
| `GenerateLuckyItem` / patch glint | **OK** : `import deepluckyblock.compat.DeepCustomGlint;` + `DeepCustomGlint.applyThemed(stack);` en fin de `addEnchantment()` (l.3281). Lib Glint & Glamour **commentée** dans `build.gradle` → no-op assumé. |
| `./gradlew build` | **NON lancé** (consigne d'arrêt). Dernier build local réussi le 18/09 13:36 (classes présentes). |

---

## CE QUE J'ATTENDS DE TOI AVANT DE CODER

1. **Validation de ce rapport** (et de l'ordre des tâches T1→T5).
2. **Le log de la session du 18/09 au soir** (celle qui a touché `.mcreator` à 23:39) : c'est le seul moyen de savoir si le gel que tu décris est bien celui du 13:07 (citadel) ou un nouveau, plus récent. S'il n'existe pas, dis-le : on partira du principe que c'est le gel citadel.
3. **Autorisation de lancer `./gradlew build` dans le sandbox** (long, ~1,9 Go de RAM, risque d'OOM) — ou tu préfères que je commence par l'instrumentation du terrain (T1) et qu'on build une seule fois à la fin ?

> Note de suivi : je n'ai lancé **aucune** recherche web (0/7). Je déclencherai les ≥ 7 recherches ciblées demandées pendant la phase de correction, pas avant.
