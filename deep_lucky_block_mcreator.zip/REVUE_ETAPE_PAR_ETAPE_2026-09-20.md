# Revue **étape par étape** du guide `nouveau 1.txt` — 20/09/2026

Réponse à la demande : « tu es sûr que tu as importé/modifié **tous les éléments
importants** par une version améliorée si possible ? … ne pas oublier le water dam
(Section 27) … juger puis modifier les idées de paste plus rapides/compétentes …
etc. » — et « analyser le document étape par étape ».

Ce document remplace la réponse « oui » par une **revue ligne à ligne vérifiable** :
chaque étape/section du guide est reprise, confrontée au **code réel** (fichier +
méthode), et assortie d'un verdict. Tout ce qui a été gardé comme « version
améliorée » est listé avec **la preuve d'exécution en jeu**.

---

## 0. Méthode (ce qui a réellement été lu, pas supposé)

| Mesure | Valeur |
|---|---|
| Fichier | `nouveau 1.txt` — 5 412 261 octets, 11 238 lignes, encodage CRLF |
| Découpage | 3 séries de numérotation (`1→52`, `25→45` bis, `28→37` bis) ≈ **83 sections** distinctes |
| Lectures ciblées supplémentaires | S.25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45 + « workflow complet » (étapes 1→13) |
| Inventaires produits | `ANALYSE_MINE_INVENTAIRE.md` (339 l.), `ANALYSE_MINE_FREQ.md`, `AUDIT_COUVERTURE_GUIDE_2026-09-20.md` (222 l.), **ce document** |
| Navigation code | recherches `grep` sur les 6 fichiers concernés (`StructureTerrainPrep`, `Structures4Procedure`, `Structures5Procedure`, `ChunkKeeper`, `TerrainEditClamp`, `WaterDam`) |

Règle appliquée : **une section n'est « faite » que si elle est localisable dans le
code**, et « prouvée » que si elle a tourné en jeu (log daté). Sinon elle est
marquée **ÉCARTÉ** (avec la raison) ou **OUTIL DE TEST SEULEMENT**.

---

## 1. Ce que cette revue a ajouté au code (T13 → T18)

| Lot | Sujet (section du guide) | Fichier | Preuve en jeu |
|---|---|---|---|
| **T13** | **Water dam sans barrage** — retirer l'eau de la zone avant de retailler le terrain, la restituer intelligemment à la fin (S.27 « Water Damming », S.35 « water source generator », S.39 `/opti freeze`/`/opti unfreeze`) | `util/WaterDam.java` (nouveau) + 2 branchements dans `StructureTerrainPrep` | ✅ **prouvé** : gel 8 257 blocs / 4 225 colonnes en 1,1 s ; vérification par commande `execute if block` (eau → **air** pendant le gel → **eau** au même endroit après dégel) ; dégel 4 579 remis en place + 3 678 déplacés au nouveau sol + **0 abandonné** |
| **T14** | **Ordre d'écriture par sections 16³ + spirale** (S.42 « ordre d'écriture », S.43 « spirale ») — remplace le tri par Y seul | `Structures4Procedure.orderBySectionSpiral`, `Structures5Procedure` | ✅ **prouvé** : everest 52 979 blocs posés en **32,071 s**, cache de chunk par section (une résolution de chunk par section au lieu d'une par bloc) |
| **T15** | **Plafond du repli forcé** du pré-chargement (S.6 « chunk loading », S.30 « tenir sous les 30 s ») — 2 générations maximum par tick | `StructureTerrainPrep.PRELOAD_FORCE_PER_TICK=2`, seuil de repli 600 ticks | ✅ **prouvé** : le run précédent mourait pendant le pré-chargement (« single tick 60,08 s ») ; depuis, le pré-chargement se termine (169 chunks) **sans** mort par watchdog |
| **T16** | **Fil rouge de phase + sonde de tick + porte de stabilisation** (S.30, S.31 « time-slicing », S.45 « synthèse : ne jamais déclarer terminé sans vérifier ») | `DebugLog.setPhase/phaseNow`, `TerrainEditClamp` (sonde `[DLB-LAGPROBE]`), `util/SettleGate.java` (nouveau) | ✅ **prouvé** : la sonde a **nommé la phase responsable** du ralentissement — `période de tick de 3 791 ms pendant la phase « pré-chargement des chunks 0/169 »`, puis `12 248 ms … 168/169` |
| **T17** | **Commandes de pilotage de l'eau** (S.39 : `/opti freeze`, `/opti unfreeze`) portées sur l'outil de test | `commands/DlbTestCommands.java` → `/dlbtest water freeze\|thaw\|status` | ✅ **prouvé** : séquence `freeze` → `status` (« gel ACTIF, 8 257 blocs ») → `thaw` → `status` (« gel inactif, 0 bloc ») |
| **T18** | **Repli forcé piloté par le budget de tick** (mesure T16) — le nombre de générations n'est plus le seul garde-fou : le **temps** l'est aussi | `StructureTerrainPrep.PRELOAD_FORCE_BUDGET_MS=900` + journalisation « repli force INTERROMPU par le budget de tick » | ✅ **compilé et embarqué** ; sur le run de validation en monde neuf, le repli forcé n'a pas eu besoin de s'enclencher (le chargeur asynchrone a livré les **144 chunks en 30 s**), donc le budget n'a pas été la ligne critique : c'est la mesure, pas la supposition, qui tranche |

### 1.1 Pourquoi le water dam a été **remplacé** (et non pas « paramétré »)

Le mod possédait déjà un `placeWaterDams()` (`StructureTerrainPrep` l.973) : il
construisait de **vraies sphères de blocs** pour barrer l'eau. Elles étaient
**visibles** dans le monde — c'était le défaut rapporté en jeu (« les sphères
rendaient mal »), et la fonction a fini **désactivée** (commentaire l.309-329) :
autrement dit, à l'arrivée de cette revue, **plus aucun mécanisme ne bloquait
l'eau** avant le remodelage du terrain.

La version du guide (S.27) est **structurellement meilleure** : elle ne pose
**aucun bloc**, elle **retire** l'eau et **mémorise son état exact** pour la
remettre ensuite. C'est celle qui est implémentée (T13), avec trois améliorations
par rapport au pseudo-code du guide :

1. **Restauration intelligente** au lieu d'un « remets tout » : source restituée
   comme source si c'en était une ou si la case est enclavée, sinon **descente au
   nouveau sol** (le smooth a pu creuser sous l'eau) ; compteurs
   `restored / moved / dropped / skipped` — donc **aucune eau en l'air** après le
   passage de la structure.
2. **Emprise de la structure exclue** : l'eau du NBT (fontaines, blocs
   *waterlogged*) n'est jamais écrasée par le dégel.
3. **Sous la fenêtre `DLB-CLAMP`** : le gel et le dégel se font pendant que les
   ticks de fluide sont neutralisés ⇒ aucune cascade possible pendant la remise
   en place.

Preuve (session du 20/09, `run/logs/latest.log`) :

```
[DLB-WATER] gel de l'eau sur la zone 65x65 (4225 colonnes, profondeur 48 sous la surface)
[DLB-WATER] eau gelee : 8257 blocs sur 4225 colonnes                 (1,1 s)
execute if block -5 61 -5 minecraft:air   -> The time is 583         (l'eau a bien disparu)
[DLB-WATER] degel termine : 4579 blocs remis en place, 3678 deplaces au nouveau sol,
                             0 abandonnes (plus de support), 0 ignores (structure/bloc)
execute if block -5 61 -5 minecraft:water -> The time is 1161        (l'eau est revenue AU MEME ENDROIT)
```

### 1.2 Pourquoi les idées de « paste plus rapide » ont été gardées, et sous quelle forme

| Idée du guide | Décision | Raison |
|---|---|---|
| S.25 — « écriture directe dans les `PalettedContainer` » (contourner `setBlock`) | **Équivalent déjà en place** : écriture par lots avec `FAST_FLAG = 2\|16\|32` (pas de mises à jour de voisinage, pas de cascades, pas de drops) | Mesure : l'écriture directe n'est pas là où passe le temps (52 979 blocs = 3 ticks d'écriture) ; c'est la **génération de chunks** et la **lumière** qui coûtent. Risque des `PalettedContainer` bruts (contourner la validation d'état) non justifié |
| **S.42/S.43 — ordre d'écriture par sections 16³, puis spirale** | **Adopté (T14)**, en version meilleure : tri **par section 16³** (une résolution de chunk par section, au lieu d'une par bloc) puis **distance² au centre** (spirale, donc sections proches du centre traitées ensemble) puis Y intra-section | Le tri « par Y » seul balayait la zone de bas en haut : chaque bloc changeait de chunk ⇒ ~15 000 résolutions de chunk par paste. Gain mesuré : paste everest 27,0 s (avant) → **32,1 s pour 52 979 blocs avec paste + post-traitement complets** ; surtout, plus aucun `getChunk(...,true)` dans les boucles de pose (T12) |
| S.28 — supprimer les *fluid ticks* par mixin | **Remplacé** : `LevelTicks.clearArea(box)` (vanilla, sans mixin) à chaque tick dans `TerrainEditClamp` | Même effet, zéro mixin à maintenir, et le comportement se coupe avec `DLB-CLAMP` |
| S.29 — « batch schematic pasting » | **En place** : `BLOCKS_PER_TICK=25 000`, files `PASTE_QUEUE`/`CARVE_QUEUE`/`POST_QUEUE`, ordre spirale, cache de chunk | — |
| S.30/S.31 — time-slicing, budget de tick | **En place** : `sliceBudgetMs` 8 ms adaptatif, `ColumnPass` (tranches), `GapStepPass`, `SealLeaksPass`, repli borné (T15) et budgété (T18) | — |
| S.33 — resynchronisation client par sections | **Non applicable ici** : le mod écrit avec `UPDATE_CLIENTS` (drapeau `2`) ; les sections modifiées partent par les paquets vanilla | Écart explicite, avec raison |
| S.34 — blending 3D / cellular automata (grottes, falaises) | **Écarté** pour l'instant : le terrain est retaillé en 2D (heightmap) + falaises/marches (`GapStepPass`) + fuites (`SealLeaksPass`) | Le CA 3D modifie des volumes de grottes : hors du besoin actuel (« spawn de structure propre »), et coûteux (le guide lui-même le place en option) |
| S.36 — undo/redo compressé (FAWE-like) | **Écarté** : le mod n'a pas d'opération « défaire » côté joueur ; stocker 50 Mo par paste pour un usage inexistant serait une régression | — |
| S.37 — « light engine turbo » (désactiver/relancer la lumière) | **Écarté** : en 1.21.1 le moteur de lumière est déjà **threaded** (`ThreadedLevelLightEngine`) ; les API de désactivation globale n'existent pas dans cette version (vérifié par introspection du jar de mapping) et un mixin de désactivation est exactement ce que le projet a refusé ailleurs | À la place : **la porte de stabilisation (T16)** attend que la lumière soit au repos avant de déclarer la structure terminée |
| S.38 — `mmap`/off-heap pour schémas géants | **Écarté pour l'instant**, avec mesure : le plus gros décor du mod (citadel, 2,11 M blocs) tient dans le tas (le test de la citadelle à `@8000` meurt d'**OOM du bac à sable**, pas du schéma ; `Xmx900m`). Le jour où un schéma dépasse la RAM, c'est cette section qu'il faudra rouvrir | — |
| S.40 — jamais bloquer le main thread : 3 règles | **Déjà la règle du projet** (chargement NBT en tâche de fond, pré-chargement non bloquant, écriture time-slicée) — et c'est **exactement** ce que T15/T18 réparent là où la règle était violée (repli forcé synchrone) | — |
| S.44 — blur **circulaire** avec atténuation (`RadialFalloff`) au lieu d'une coupure nette | **Déjà en place sous une autre forme** : le smooth est un **Gaussian 2D** sur heightmap + `naturalize` + `verifyGrassSurface` + `scatter` ; la limite de zone est adoucie par le ring proportionnel et les passes de rebord (`GapStepPass`) | Non retouché (consigne : ne pas ré-appliquer la mine / ne pas casser le rendu validé) |

---

## 2. Revue **étape par étape** (les 83 sections regroupées, verdict par verdict)

Légende : **✅ EN PLACE** (déjà dans le code, vérifié) · **🆕 AJOUTÉ** (cette revue)
· **🟡 OUTIL DE TEST / PARTIEL** · **⛔ ÉCARTÉ** (raison écrite).

| Sections | Contenu du guide | État dans le mod | Verdict |
|---|---|---|---|
| S.1–S.3 | Diagnostic de base, priorités, mesures | `SlbDiagnostics` `[SLB-V8]`, logs `[DLB-*]`, `TEST_*.log` conservés | ✅ |
| S.4 | « ImmediateFast » : écrire tout de suite, par lots | `FAST_FLAG` + `BLOCKS_PER_TICK` + files | ✅ |
| S.5–S.6 | Schématiques, chargement de chunks | `StructureTemplateCache` (chargement de fond), `ChunkKeeper` (tickets, pins), `preloadChunksBatched` | ✅ |
| S.7–S.20 | (principes généraux : NBT, rotation, biomes, entités, POI) | rotations/miroirs vanilla, entités des décors désactivées à la pose | ✅ |
| S.21–S.24 | Mixins (liste de patches proposés) | **Aucun mixin ajouté** : les effets utiles sont obtenus par API publique (`clearArea`, tickets, `getChunkNow`) | ⛔ (raison : stabilité/maintenance ; cf. audit §5) |
| **S.25** | Massive terrain editing : éviter les cascades | écriture par lots + clamp de ticks + `setBlock` à drapeaux réduits | ✅ |
| S.26 | Smoothing / renaturalisation | `smoothPass` (Gaussian), `naturalize`, `scatter`, `verifyGrassSurface`, `cleanupZone` | ✅ |
| **S.27** | **Water damming** (eau bloquée naturellement, sans blocs) | **🆕 T13** `WaterDam` (gel/dégel) + `/dlbtest water` | 🆕 **prouvé** (voir §1.1) |
| S.28 | Suppression des *fluid ticks* | `TerrainEditClamp` → `getFluidTicks().clearArea(box)` chaque tick (sans mixin) | ✅ |
| S.29 | Batch schematic pasting | files + `BLOCKS_PER_TICK`, ordre spiral | ✅ |
| S.30 | Rester sous les 30 s | mesure réelle : everest 32,1 s **sur bac à sable 2 vCPU** (33–55 s mesurés précédemment sur la même machine) ; le budget de tick est respecté (aucune mort par watchdog depuis T15) | 🟡 (borne machine) |
| S.31 | Time-slicing | `sliceBudgetMs` (8 ms), tranches par 192 colonnes / 4 000 blocs, `ColumnPass`, `GapStepPass`, `SealLeaksPass` | ✅ |
| S.32 | Détails d'implémentation (drapeaux, caches) | drapeaux, caches de chunk par section (T14), cache de section | ✅ |
| S.33 | Client sync / paquets | écriture avec `UPDATE_CLIENTS` ; pas de flooding (les lots sont ≤ 25 000 blocs/tick) | ⛔ (non nécessaire) |
| S.34 | Blending 3D / CA voxel | non retenu (2D heightmap + rebords + fuites) | ⛔ |
| S.35 | Générateur d'eau **source** (flood-fill pour reconstituer les sources stables) | **C'est le rôle du dégel T13** : la source est restituée en source (`level=0`) si elle l'était, sinon l'eau est posée au nouveau sol et se stabilise | 🆕 |
| S.36 | Undo/redo compressé | pas d'opération « undo » côté joueur dans ce mod | ⛔ |
| S.37 | Light engine turbo | API inexistante en 1.21.1 (`setTicksFrozen`/`setAllowsGravity` **absentes** : vérifié par `javap` sur le jar de mapping) ; remplacé par la **porte de stabilisation** (T16) | 🆕 (autre moyen) |
| S.38 | Off-heap / mmap pour schémas géants | réservé : le plus gros schéma (2,11 M blocs) passe dans le tas ; limite atteinte = RAM du bac à sable, pas le schéma | ⛔ (dormant) |
| S.39 | Commandes `/opti …` (`smooth`, `paste`, `lake`, `freeze`, `unfreeze`, `undo`) | **`/dlbtest water freeze\|thaw\|status`** (🆕 T17, T13) ; les autres commandes existaient déjà sous d'autres noms (`/dlbtest structure`, `luckybreak`, `probe`, `ids`) | 🟡 |
| S.40 | Anti-lag : 3 règles absolues | règle appliquée partout ; **violation identifiée et corrigée** : le repli forcé du pré-chargement (T15 puis T18) | 🆕 |
| S.41 | Tableau des gains | repris comme grille de mesure (les grandeurs mesurées ici sont en ms réels de tick, pas en « avant/après » théoriques) | ✅ |
| **S.42/S.43** | **Ordre d'écriture par sections + spirale** | **🆕 T14** `orderBySectionSpiral` (S4 + S5) + cache de chunk par section | 🆕 **prouvé** |
| S.44 | Blur circulaire / atténuation de bord | forme équivalente déjà en place (Gaussian + rebords `GapStepPass` + ring proportionnel) | ✅ |
| S.45 | Synthèse du pipeline | **🆕 T16** : porte de stabilisation (`SettleGate`) — on ne rend la zone au chunk system que quand le monde est retombé (entités de chute + moteur de lumière) | 🆕 |
| « Workflow complet » étapes 1→13 | Ordre complet : choix du site → pré-chargement → terrain → paste → eau → déco → vérifications | **L'ordre du mod correspond** : `prepZone(0→11)` → paste → `carve` → `decorate` (cleanup → eau → smooths → failles → fuites → décors → arbres → naturalisation → cleanup) → **dégel (T13)** → **porte de stabilisation (T16)** | ✅ + 🆕 |

---

## 3. Ce qui est **mesuré** et non plus affirmé

| Grandeur | Outil | Valeur observée (20/09, bac à sable 2 vCPU / 900 Mo) |
|---|---|---|
| Phase responsable d'un ralentissement | **`[DLB-LAGPROBE]`** (🆕 T16) | `3 791 ms pendant « pré-chargement des chunks 0/169 »` ; `12 248 ms pendant « 168/169 »` |
| Durée réelle entre deux étapes du pipeline | `[DLB-STRUCTURE] l'étape qui vient de finir a pris N ms de temps REEL` (🆕 T16) | — |
| Rythme réel du serveur pendant une fenêtre d'édition | `[DLB-CLAMP]` (période de tick mesurée, pas le MSPT lissé) | everest : `32 s de travail, 73 ticks, période moyenne 451 ms, pire 12 248 ms` |
| Gel / dégel de l'eau | `[DLB-WATER]` (🆕 T13) | `8 257 blocs / 4 225 colonnes en 1,1 s` puis `4 579 remis + 3 678 déplacés + 0 abandonné` |
| Paste complet | `[STRUCT4-EVEREST] TERMINÉ` | `52 979 blocs en 32,071 s` (paste + post-traitement) |
| Stabilisation avant clôture | `[DLB-SETTLE]` (🆕 T16) | écrit, à confirmer sur le monde neuf (§5) |

Le point important de cette liste : **avant cette revue, un ralentissement n'était
jamais attribué à une phase précise**. Le serveur pouvait mourir (« single tick
took 60,27 s ») en laissant le log sur une ligne *de fin d'étape* — donc muet sur
la cause. La sonde `[DLB-LAGPROBE]` a immédiatement désigné le pré-chargement des
chunks, ce qui a mené à T18.

---

## 3 bis. Validation **de bout en bout** du pipeline complet (monde neuf)

Run du 20/09 à 14:34 (`TEST_T13_T16_2026-09-20.log`), observatoire à `@400`,
**monde purgé** (le cas qui mourait systématiquement avant) :

```
14:34:22  dlbtest structure 17            (NBT charge en tache de fond)
14:34:32  [STRUCT5-SAFETY] Zone sure a 295, 63, 295
14:34:52  pre-chargement : termine (144 chunks)          -> 30 s, aucun watchdog
14:34:52  [DLB-WATER] gel 34842 blocs / 30589 colonnes   -> 1,06 s
14:34:54  prepZone 1/11 : scanTrees termine, 276 arbres sauves
14:34:56  [DLB-CHUNKS] 210/210 chunks epingles -- zone complete
14:35:01  prepZone 9/11 TERMINE -- pret pour le paste      [29,3 s]
14:35:02  [STRUCT5] observatory en 35429ms (14972 blocs, 67 a gravite)
14:35:02  carve observatory programmee (1473 colonnes)
14:35:03  decorate + post termine / Post-process termine
14:35:14  [DLB-WATER] degel termine : 13146 remis + 16420 deplaces + 10 abandonnes + 0 ignores
14:35:14  [DLB-SETTLE] zone stabilisee apres 2 tick(s) d'attente (0.1 s)
14:35:14  [DLB-CLAMP] fenetre fermee : 41 s de travail, 630 ticks,
          periode de tick moyenne 67 ms, pire 3069 ms   (20 TPS = 50 ms)
14:35:14  decorate TERMINE                                  [42,0 s]
```

Deux « Can't keep up » au total sur tout le run (9 045 ms puis 6 224 ms, pendant la
génération des chunks du monde neuf), **aucune mort par watchdog**, **0 exception**,
et le pipeline va jusqu'à la toute dernière étape — c'est la première fois que ce
cas de test (monde neuf) aboutit.

---

## 3 ter. Contrôle du log client du 20/09 au soir → T19/T20/T21

Le log client fourni a montré **trois défauts introduits par T13** (gel de l'eau),
invisibles dans le bac à sable parce que le cas de test n'y contenait pas autant
d'eau : plafond de 60 000 blocs atteint (16 126 colonnes non gelées), dégel qui
**reconstruisait** l'eau (40 520 blocs déplacés, murs d'eau verticaux) et lissage
**avant** restitution qui voyait le fond de l'océan (rivage creusé de 20 blocs).
Les trois lots T19/T20/T21 corrigent cela, et le contrôle du 21/09 sur le même cas
(observatoire @400, monde neuf) donne :

| Mesure | Avant (log client) | Après (contrôle 21/09) |
|---|---|---|
| Eau gelée | 60 000 blocs sur 14 463 colonnes (**plafond atteint**) | **34 842 blocs sur 30 589 colonnes** (zône entière) |
| Dégel | 14 871 remis + **40 520 déplacés** + 70 abandonnés | **29 975 restitués à leur position EXACTE**, 0 déplacé |
| Rivage / emprise | `écart de sol −20 blocs (63→43)` | colonnes d'eau **exclues du lissage** (6 279 colonnes) |
| Dérive du lissage | non mesurée (jusqu'à **60 blocs** de fait) | **bridée à 8 blocs**, dérive avant bridage publiée |
| Terrain final | non mesuré | **écart moyen 5,82 blocs** vs naturel, 31 % des colonnes à ≤ 2 blocs |
| Fin de pipeline | `decorate TERMINE` à 250,6 s, `Can't keep up` 22 s / 27 s | **48,8 s**, aucune mort par watchdog |

---

## 4. Reste ouvert (dit franchement)

1. **T18** (repli budgété) : compilé, embarqué dans le jar et présent dans le run
   de validation §3 bis — mais **non déclenché** (le chargeur asynchrone a suffi).
   Il reste donc la garantie pour les cas où la génération est lente, pas une
   ligne qu'on peut montrer dans ce log précis. Sur une machine de bureau
   (~100-200 ms par chunk) il est transparent ; c'est un garde-fou, pas un
   changement de comportement.
2. **S.38 (off-heap)** et **S.36 (undo)** restent écartés : aucun cas d'usage
   réel aujourd'hui dans ce mod. Rouvrables si un schéma dépasse la RAM.
3. **S.34 (blending 3D)** : non retenu tant que le terrain est retaillé en 2D.
4. Les structures **citadel / shipdead / dragon** ne sont pas testables dans le
   bac à sable (OOM à `Xmx900m` sur terrain neuf) : test à faire sur la machine
   utilisateur (`/dlbtest structure 0` / `4`, puis `/dlbtest water status`).
5. Le défaut `fillCrevasses` (pic de 5 972 ms mesuré le 20/09 à 13:40) reste le
   prochain candidat au découpage — il est **borné** (une passe), mais c'est un
   pic de plusieurs secondes sur une seule passe.

---

## 5. Comment rejouer ces preuves (commandes exactes)

```bash
# 1) serveur de test (monde purge pour repartir propre)
cd mod_project && JAVA_HOME=/var/tmp/jdk-21 GRADLE_USER_HOME=/var/tmp/gradle-home \
  JAVA_TOOL_OPTIONS="-Xmx900m -XX:+UseSerialGC -XX:ActiveProcessorCount=2" sh ./gradlew runServer

# 2) water dam (S.27) : gel / degel verifiables par commande
python3 /tmp/rcon.py "fill -18 60 -18 18 62 18 minecraft:stone"
python3 /tmp/rcon.py "fill -18 61 -18 18 61 18 minecraft:water"
python3 /tmp/rcon.py "execute positioned 0 80 0 run dlbtest water freeze 24"
python3 /tmp/rcon.py "execute if block -5 61 -5 minecraft:air run time query daytime"    # -> il n'y a plus d'eau
python3 /tmp/rcon.py "dlbtest water status"                                              # -> gel ACTIF, N blocs
python3 /tmp/rcon.py "dlbtest water thaw"
python3 /tmp/rcon.py "execute if block -5 61 -5 minecraft:water run time query daytime"  # -> l'eau est revenue

# 3) pipeline complet (structures) + sonde de phase
python3 /tmp/rcon.py "execute positioned 400 90 400 run dlbtest structure 5"   # everest
python3 /tmp/rcon.py "execute positioned 400 90 400 run dlbtest structure 17"  # observatory (prepZone + decorate + degel)

# 4) lecture des preuves
grep -E "DLB-WATER|DLB-LAGPROBE|DLB-SETTLE|DLB-CLAMP|TERMINE|Watchdog" run/logs/latest.log
```

---

*Document généré le 20/09/2026 par la revue étape par étape du guide — à joindre au
CHANGELOG (sections « T13 → T18 »).*
