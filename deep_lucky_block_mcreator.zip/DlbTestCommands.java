package deepluckyblock.commands;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.common.util.FakePlayerFactory;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

import deepluckyblock.DeepLuckyBlockMod;
import deepluckyblock.blockentity.DeepLuckyBlockBlockEntity;
import deepluckyblock.init.DeepLuckyBlockModBlocks;
import deepluckyblock.procedures.Structures5Procedure;

/**
 * /dlbtest — outil de TEST headless du pipeline de structures.
 *
 * POURQUOI : les freezes du pipeline terrain (prepZone / decorate) ne peuvent
 * etre reproduits qu'en jeu, et les commandes existantes (/eventtest,
 * /crimsonlake, /dlbaudit) exigent un JOUEUR connecte
 * (getPlayerOrException) : elles sont donc inutilisables depuis la console
 * d'un serveur dedie -- seul moyen de tester sans affichage graphique.
 *
 * Cette commande fonctionne AVEC OU SANS joueur (elle cree un FakePlayer si
 * elle est lancee depuis la console) et rejoue EXACTEMENT le meme appel que
 * celui declenche par la casse d'un Deep Lucky Block :
 *     TestProcedure (recompense) -> Structures5Procedure.execute(level, player, id)
 *
 *   /dlbtest structure &lt;id&gt;      : force une structure (memes ids que
 *                                   Structures5Procedure : 0=citadel, 3=circus,
 *                                   4=shipdead, 5=everest, ...).
 *   /dlbtest luckybreak [nombre]  : pose un Deep Lucky Block avec luck=100 puis
 *                                   le CASSE (avec le fake player), ce qui
 *                                   reproduit exactement l'action du joueur.
 *   /dlbtest ids                  : rappelle la table des ids.
 *
 * Utilisation depuis la console (ou en jeu, position = celle de l'executant) :
 *   execute positioned 0 80 0 run dlbtest structure 0
 *   execute positioned 0 80 0 run dlbtest luckybreak 20
 */
@EventBusSubscriber(modid = DeepLuckyBlockMod.MODID)
public final class DlbTestCommands {

    private DlbTestCommands() {}

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(
            Commands.literal("dlbtest")
                .requires(src -> src.hasPermission(2))
                .then(Commands.literal("ids")
                        .executes(ctx -> {
                            ctx.getSource().sendSuccess(() -> Component.literal(
                                    "0..2,16..18 = structures standard | 3 = circus | 4 = shipdead | 5 = everest"), false);
                            return 1;
                        }))
                .then(Commands.literal("structure")
                        .then(Commands.argument("id", IntegerArgumentType.integer(0, 40))
                                .executes(ctx -> {
                                    int id = IntegerArgumentType.getInteger(ctx, "id");
                                    ServerLevel level = ctx.getSource().getLevel();
                                    ServerPlayer player = fakeOrReal(ctx.getSource().getPlayer(), level,
                                            ctx.getSource().getPosition().x, ctx.getSource().getPosition().z);
                                    DeepLuckyBlockMod.LOGGER.info("[DLBTEST] structure id={} a {} (fake={})",
                                            id, player.blockPosition().toShortString(), ctx.getSource().getPlayer() == null);
                                    Structures5Procedure.execute(level, player, id);
                                    return 1;
                                })))
                .then(Commands.literal("luckybreak")
                        .executes(ctx -> breakLucky(ctx.getSource().getLevel(), ctx.getSource().getPlayer(),
                                ctx.getSource().getPosition().x, ctx.getSource().getPosition().y,
                                ctx.getSource().getPosition().z, 1))
                        .then(Commands.argument("nombre", IntegerArgumentType.integer(1, 200))
                                .executes(ctx -> breakLucky(ctx.getSource().getLevel(), ctx.getSource().getPlayer(),
                                        ctx.getSource().getPosition().x, ctx.getSource().getPosition().y,
                                        ctx.getSource().getPosition().z,
                                        IntegerArgumentType.getInteger(ctx, "nombre")))))
        );
    }

    /** Un vrai joueur s'il y en a un, sinon un FakePlayer positionne au meme endroit. */
    private static ServerPlayer fakeOrReal(ServerPlayer real, ServerLevel level, double x, double z) {
        ServerPlayer p = real;
        if (p == null) {
            p = FakePlayerFactory.getMinecraft(level);
        }
        // On recale le faux joueur sur la position demandee : Structures5Procedure
        // s'en sert comme origine de la structure et pour l'orientation face au joueur.
        p.moveTo(x, p.getY(), z, 0.0F, 0.0F);
        return p;
    }

    /**
     * Reproduit l'action du joueur : pose un Deep Lucky Block porteur de luck=100,
     * puis le casse. `nombre` blocs sont casses, espaces de 20 ticks (1 s).
     * La structure eventuelle est ensuite posee par le mod lui-meme, comme en jeu.
     */
    private static int breakLucky(ServerLevel level, ServerPlayer real, double x, double y, double z, int nombre) {
        ServerPlayer player = fakeOrReal(real, level, x, z);
        try {
            player.setGameMode(GameType.SURVIVAL);
        } catch (Throwable ignored) { }
        for (int i = 0; i < nombre; i++) {
            final int bi = i;
            int delay = bi * 20;
            int px = (int) Math.floor(x) + (bi % 5);
            int pz = (int) Math.floor(z) + (bi / 5);
            int py = (int) Math.floor(y);
            deepluckyblock.procedures.TestProcedure.schedule(level,
                    deepluckyblock.procedures.TestProcedure.currentTick(level) + delay, () -> {
                BlockPos pos = new BlockPos(px, py, pz);
                level.setBlock(pos, DeepLuckyBlockModBlocks.DEEP_LUCKY_BLOCK.get().defaultBlockState(), 3);
                if (level.getBlockEntity(pos) instanceof DeepLuckyBlockBlockEntity be) {
                    be.setLuck(100);
                    be.setSlbLuckBonus(100);
                    be.setChanged();
                }
                DeepLuckyBlockMod.LOGGER.info("[DLBTEST] casse du lucky block {} (luck=100, n°{}/{})",
                        pos.toShortString(), bi + 1, nombre);
                player.moveTo(px + 0.5, py, pz + 0.5, 0.0F, 0.0F);
                BlockState state = level.getBlockState(pos);
                try {
                    // Meme chemin qu'un clic gauche de joueur : playerDestroy/onDestroyedByPlayer.
                    player.gameMode.destroyBlock(pos);
                } catch (Throwable t) {
                    DeepLuckyBlockMod.LOGGER.error("[DLBTEST] echec destroyBlock {}", pos, t);
                }
                if (!level.getBlockState(pos).equals(state)) {
                    DeepLuckyBlockMod.LOGGER.info("[DLBTEST] bloc casse OK {}", pos.toShortString());
                }
            });
        }
        return nombre;
    }
}
