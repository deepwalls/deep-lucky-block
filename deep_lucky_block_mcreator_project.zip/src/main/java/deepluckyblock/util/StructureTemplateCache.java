package deepluckyblock.util;

import com.mojang.logging.LogUtils;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplateManager;
import org.slf4j.Logger;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/**
 * FIX (rapporté en jeu : freeze serveur d'environ 78 secondes / "Can't keep up
 * ... Running 78183ms or 1563 ticks behind" au premier spawn de shipdead) :
 *
 * StructureTemplateManager.get()/.getOrCreate() ne conserve AUCUN cache entre
 * deux structures différentes tant qu'elles n'ont pas déjà été demandées une
 * première fois. La toute première fois qu'une structure du mod (ex :
 * shipdead.nbt, 4.9 Mo, ~1.7M entrées de blocs) est réclamée en jeu, le
 * serveur doit désérialiser tout le NBT de façon SYNCHRONE sur le thread
 * principal, AVANT même le calcul de la zone plate ou le placement des blocs
 * (qui, eux, sont bien répartis sur plusieurs ticks via PASTE_QUEUE). Pour un
 * fichier de plusieurs Mo, ce chargement à froid peut prendre plusieurs
 * dizaines de secondes pendant lesquelles AUCUN tick serveur ne peut avancer.
 *
 * FIX en deux parties :
 *  1) StructureTemplateCache.get(...) : un cache dédié au mod (persistant
 *     tant que le serveur tourne) partagé par toutes les procédures qui
 *     posent des structures (Structures4Procedure, Structures5Procedure,
 *     CrimsonLakeStructureSpawnProcedure, GenerateBadProcedure/hourglass) ;
 *     une structure n'est donc plus jamais désérialisée deux fois.
 *  2) StructureTemplateCache.preloadAll(...) : appelé une seule fois depuis
 *     DeepLuckyBlockMod#onServerStarted, AVANT que les joueurs ne soient
 *     connectés / ne tickent. Le coût de désérialisation de TOUTES les
 *     structures du mod (y compris shipdead et citadel, les deux plus
 *     grosses) est ainsi payé une fois pendant le démarrage du serveur --
 *     où un délai n'est jamais perçu comme un freeze en jeu -- au lieu
 *     d'être payé en une fois pendant une partie déjà en cours, quand un
 *     joueur ouvre un lucky block et se retrouve avec un serveur figé
 *     78 secondes ("Can't keep up").
 */
public final class StructureTemplateCache {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final Map<String, StructureTemplate> CACHE = new ConcurrentHashMap<>();

    /** Toutes les structures NBT du mod, à précharger au démarrage serveur. */
    public static final List<String> ALL_STRUCTURE_NAMES = List.of(
            "circus", "shipdead", "everest", "citadel", "observatory",
            "dragon", "crimsonlake", "sand_hourglass"
    );

    private StructureTemplateCache() {}

    /**
     * Retourne le template demandé, en le servant depuis le cache du mod si
     * déjà chargé, sinon en le chargeant (via le StructureTemplateManager
     * vanilla) et en le mettant en cache pour tous les appels futurs (toutes
     * procédures confondues). Retourne null en cas d'échec ou de template
     * vide (taille X == 0), comme le faisait le code appelant auparavant.
     */
    public static StructureTemplate get(ServerLevel level, String nbtName) {
        StructureTemplate cached = CACHE.get(nbtName);
        if (cached != null) return cached;
        ResourceLocation resLoc = ResourceLocation.tryParse("deep_lucky_block:" + nbtName);
        if (resLoc == null) return null;
        StructureTemplateManager mgr = level.getStructureManager();
        StructureTemplate template;
        try {
            Optional<StructureTemplate> opt = mgr.get(resLoc);
            template = opt.isPresent() ? opt.get() : mgr.getOrCreate(resLoc);
        } catch (Exception ex) {
            LOGGER.error("[STRUCT-CACHE] Échec chargement '{}'", nbtName, ex);
            return null;
        }
        if (template == null || template.getSize().getX() == 0) return null;
        CACHE.put(nbtName, template);
        return template;
    }

    /**
     * Précharge toutes les structures connues du mod. À appeler une seule
     * fois, sur le thread principal, avant que des joueurs ne soient
     * connectés (typiquement depuis ServerStartedEvent).
     */
    public static void preloadAll(ServerLevel level) {
        long t0 = System.currentTimeMillis();
        int ok = 0;
        for (String name : ALL_STRUCTURE_NAMES) {
            long ts = System.currentTimeMillis();
            StructureTemplate t = get(level, name);
            long dt = System.currentTimeMillis() - ts;
            if (t != null) {
                ok++;
                LOGGER.info("[STRUCT-CACHE] Préchargé '{}' en {}ms", name, dt);
            } else {
                LOGGER.warn("[STRUCT-CACHE] Échec préchargement '{}' ({}ms) -- sera rechargé (et pourra provoquer un freeze) au premier spawn en jeu", name, dt);
            }
        }
        LOGGER.info("[STRUCT-CACHE] Préchargement terminé : {}/{} structures en {}ms (avant connexion des joueurs)", ok, ALL_STRUCTURE_NAMES.size(), System.currentTimeMillis() - t0);
    }
}
