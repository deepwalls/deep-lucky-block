package deepluckyblock.util;

import com.mojang.logging.LogUtils;
import org.slf4j.Logger;

/**
 * DebugLog — point d'entree UNIQUE pour les logs de debug du mod.
 *
 * CONTEXTE (rapporte en jeu, log fourni) : l'ancien systeme de debug
 * ([SLB-DEBUG-TOOLTIP] / [SLB-DEBUG] / [SLB-DEBUG-ENCH]) spammait la console
 * en continu -- un seul log de session normale contenait 9705 lignes
 * [SLB-DEBUG-TOOLTIP] sur 10821 lignes totales (90%), rendant tout diagnostic
 * reel impossible (le vrai warning utile etait noye dans le bruit).
 *
 * Remplacement : UN SEUL flag togglable ({@link #ENABLED}, actuellement
 * {@code true}), qui ne couvre QUE deux categories utiles et CIBLEES :
 *   - {@link #structure} : le processus de generation de structure/terrain
 *     (smooth, clear, naturalize, mountain-wall...), utile pour diagnostiquer
 *     les bugs de spawn de structure.
 *   - {@link #heart} : les enchantements de coeur elementaires -- comment ils
 *     s'attachent (quel element, quel niveau, sur quel joueur), comment c'est
 *     vu cote joueur (HUD, regen, perte).
 *
 * Volontairement PAS d'equivalent pour le rendu de tooltip (appele a CHAQUE
 * frame ou le tooltip est visible -> spam garanti quel que soit le flag) : ce
 * genre de debug doit rester un println() temporaire retire avant de livrer,
 * jamais un flag permanent.
 */
public final class DebugLog {

    private DebugLog() {}

    private static final Logger LOGGER = LogUtils.getLogger();

    /** Flag unique. true = logs cibles actifs. false = silence total (hors erreurs/warnings reels). */
    public static boolean ENABLED = true;

    /** Categorie (a) : generation de structure / terrain (smooth, clear, naturalize...). */
    public static void structure(String fmt, Object... args) {
        if (ENABLED) LOGGER.info("[DLB-STRUCTURE] " + fmt, args);
    }

    /** Categorie (b) : enchantements de coeur (attache, niveau, regen, HUD cote joueur). */
    public static void heart(String fmt, Object... args) {
        if (ENABLED) LOGGER.info("[DLB-HEART] " + fmt, args);
    }
}
