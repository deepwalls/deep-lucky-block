package deepluckyblock.procedures;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.*;

/**
 * StructureTerrainPrep : preparation professionnelle du terrain avant/apres paste de structure.
 *
 * Phases (toutes batchees via TestProcedure.schedule) :
 *   1. SCAN TREES : detecte et sauvegarde les arbres (type + forme exacte) dans un rayon.
 *   2. CLEAR     : efface tout de Y=1 au sommet (bedrock preserve).
 *   3. SMOOTH    : Gaussian blur sur la heightmap (style Axiom), reconstruction du terrain.
 *   4. [PASTE]   : la structure est paste par le code appelant (callback onCleared).
 *   5. REPLANT   : re-colle les arbres sauves a leurs nouvelles hauteurs, par zone/type.
 *   6. NATURALIZE: herbe, fleurs, fougeres, bonemeal sur le terrain smooth.
 *
 * Bedrock (Y<=0) JAMAIS touche. La structure n'est pas touchee par le smooth/replant.
 */
public class StructureTerrainPrep {

    private static final org.slf4j.Logger LOGGER = com.mojang.logging.LogUtils.getLogger();

    private static final int RING = 10;
    // Ring de modification du terrain : PROPORTIONNEL a la taille de la structure
    // (petit pour les petits builds, gros pour les gros), clampe. Plus de zone
    // titanesque carree quand le build est petit et rectangulaire : la zone suit
    // la taille et la forme (footprint rectangulaire) du build.
    private static final int SMOOTH_RING_MIN = 14;
    private static final int SMOOTH_RING_MAX = 48;
    // Marge supplement pour que le lissage englobe aussi les spheres eloignees.
    private static final int SMOOTH_EXTRA_RING = 32;
    /** Pourcentage de taille de l'anneau : 100 = normal, 40 = -60%, 120 = +20%. */
    public static int TERRAIN_RING_SCALE_PERCENT = 100;
    // La vegetation depasse legerement la zone de terrain, d'environ un chunk.
    private static final int NATURALIZE_EXTRA_RING = 16;

    public static void setTerrainRingScalePercent(int percent) {
        TERRAIN_RING_SCALE_PERCENT = Math.max(10, Math.min(200, percent));
    }
    private static int SMOOTH_RING = SMOOTH_RING_MAX;
    private static final int CLEAR_BATCH_COLS = 600;
    // Rayon (en sphere) du barrage en grass block autour d'un point de fuite d'eau.
    private static final int DAM_RADIUS = 8;
    // Amplitude du zigzag du barrage (en blocs) : decale le centre de chaque sphere
    // pour ne jamais faire une ligne droite rectangulaire.
    private static final int DAM_OFFSET = 2;
    // setBlock rapide : pas d'update observer/lumiere (rebuild terrain beaucoup plus rapide).
    private static final int FAST_FLAG = 2 | 16 | 64;
    private static final int SMOOTH_PASSES = 3;
    // Kernel gaussien 5x5 (total = 273)
    private static final int[][] GAUSSIAN_5x5 = {
        {1, 4, 7, 4, 1}, {4, 16, 26, 16, 4}, {7, 26, 41, 26, 7},
        {4, 16, 26, 16, 4}, {1, 4, 7, 4, 1}
    };

    // =========================================================================
    // RECORDS
    // =========================================================================
    private record SavedBlock(int rx, int ry, int rz, BlockState state) {}
    private record SavedTree(int baseX, int baseZ, int groundY, String type, List<SavedBlock> blocks) {}

    // =========================================================================
    // ENTRY POINT
    // =========================================================================

    /**
     * Lance la preparation complete du terrain.
     *
     * @param level     Le monde serveur
     * @param min       Coin min de l'emprise de la structure
     * @param max       Coin max de l'emprise
     * @param onCleared Callback appele quand le terrain est pret (pour lancer le paste)
     * @param onDone    Callback appele quand TOUT est termine (apres replant + naturalize)
     */
    public static void prepare(ServerLevel level, BlockPos min, BlockPos max,
                                Runnable onCleared, Runnable onDone) {
        RandomSource random = level.getRandom();

        // Zone etendue (structure + ring)
        int x0 = min.getX() - RING, x1 = max.getX() + RING;
        int z0 = min.getZ() - RING, z1 = max.getZ() + RING;
        int topY = Math.min(max.getY() + 10, level.getMaxBuildHeight() - 1);

        // === PHASE 1 : SCAN TREES ===
        List<SavedTree> trees = scanTrees(level, x0, z0, x1, z1, topY);

        // === PHASE 2 : CLEAR (batche) ===
        clearArea(level, x0, z0, x1, z1, topY, () -> {
            // Terrain vide. Lancer le paste.
            if (onCleared != null) onCleared.run();

            // === PHASE 3a : SMOOTH 5x5, 3 passes ===
            smoothPass(level, min, max, 5, 3, () -> {

                // === PHASE 3b : CLEANUP - supprime le terrain qui a deborde dans la structure ===
                // (skip les chunks majoritairement air = JAMAIS vider l'air)
                cleanupOverlap(level, min, max, () -> {

                    // === PHASE 3c : SMOOTH 15x15, 2 passes ===
                    smoothPass(level, min, max, 15, 2, () -> {

                        // === PHASE 3d : VERIFY GRASS BLOCK en surface ===
                        verifyGrassSurface(level, min, max);

                        // === PHASE 5 : REPLANT TREES ===
                        replantTrees(level, trees, min, max, () -> {

                            // === PHASE 6 : NATURALIZE ===
                            naturalize(level, min, max, random);
                            if (onDone != null) onDone.run();
                        });
                    });
                });
            });
        });
    }

    /**
     * Lissage + herbe + replant + naturalize AUTOUR d'une structure deja poseee et carvee.
     * Pas de clearArea (le carve a deja nettoye l'interieur). L'emprise est preserveee
     * (surface mesuree), seul l'anneau est lisse pour fondre la structure dans le terrain.
     * Synchronne : peut freezer 1 tick sur les grosses structures.
     */
    public static void smoothAround(ServerLevel level, BlockPos min, BlockPos max, Runnable onDone) {
        RandomSource random = level.getRandom();
        int topY = Math.min(max.getY() + 10, level.getMaxBuildHeight() - 1);
        List<SavedTree> trees = scanTrees(level, min.getX() - RING, min.getZ() - RING, max.getX() + RING, max.getZ() + RING, topY);
        smoothPass(level, min, max, 5, 1, () -> {
            verifyGrassSurface(level, min, max);
            replantTrees(level, trees, min, max, () -> {
                naturalize(level, min, max, random);
                if (onDone != null) onDone.run();
            });
        });
    }

    // Trees sauves pendant prepZone, utilises par decorate (replant).
    private static List<SavedTree> LAST_TREES = new ArrayList<>();

    // Colonnes de barrage d'eau : le smooth les IGNORE (ne les aplatit pas) pour que
    // les spheres completes de grass_block survivent. Sinon le smooth (heightmap,
    // 1 hauteur/colonne) ecrase les spheres en cylindres plats. Rempli par placeWaterDams.
    private static Set<Long> DAM_COLS = new HashSet<>();

    private static long colKey(int x, int z) { return (Integer.toUnsignedLong(x) << 32) | Integer.toUnsignedLong(z); }

    // Ring de smooth proportionnel a la taille du build : la moitie de la plus
    // grande dimension, clampee entre SMOOTH_RING_MIN et MAX. Les petits builds
    // rectangulaires ne declenchent plus une modification titanesque carree : la
    // zone de terrain modifiee suit la taille (et la forme) du build.
    private static int terrainRing() {
        int baseRing = SMOOTH_RING + SMOOTH_EXTRA_RING;
        return Math.max(8, Math.round(baseRing * TERRAIN_RING_SCALE_PERCENT / 100.0f));
    }

    private static int computeSmoothRing(BlockPos min, BlockPos max) {
        int w = max.getX() - min.getX() + 1;
        int d = max.getZ() - min.getZ() + 1;
        return Math.max(SMOOTH_RING_MIN, Math.min(SMOOTH_RING_MAX, Math.max(w, d) / 2));
    }

    /**
     * Preparation AVANT paste (ordre demande) :
     *   1. scan arbres du ring (memorisation)
     *   2. clear footprint (au-dessus du sol, sans cratere)
     *   3. smooth ring (sur terrain NATUREL, donc la structure n'est pas perturbee)
     *   4. onReady -> le code appelant lance le paste
     */
    public static void prepZone(ServerLevel level, BlockPos min, BlockPos max, int foundationBaseY, Runnable onReady) {
        // Ring PROPORTIONNEL au build : petit pour les petites structures (fini la
        // zone titanesque carree), gros pour les grosses. La forme suit le footprint
        // rectangulaire du build (min/max + ring).
        SMOOTH_RING = computeSmoothRing(min, max);
        int topY = Math.min(max.getY() + 10, level.getMaxBuildHeight() - 1);
        LAST_TREES = scanTrees(level, min.getX() - terrainRing(), min.getZ() - terrainRing(), max.getX() + terrainRing(), max.getZ() + terrainRing(), topY);
        int buildW = max.getX() - min.getX() + 1, buildD = max.getZ() - min.getZ() + 1;
        deepluckyblock.util.DebugLog.structure("prepZone : build {}x{}, ring={} -> zone {}x{}, {} arbres sauves (prep AVANT paste)", buildW, buildD, SMOOTH_RING, buildW + 2 * SMOOTH_RING, buildD + 2 * SMOOTH_RING, LAST_TREES.size());
        // 0. Pre-fill : remplit les vides SOUS la structure (emprise + 3) avec du grass
        //    block, pour garantir un sol solide (pas de structure qui flotte sur un trou).
        prefillFoundation(level, min, max, foundationBaseY, () ->
            clearSurfaceDecor(level, min, max, () ->
                clearFootprint(level, min, max, topY, () -> {
                    // RETABLI (l'utilisateur a confirme par test en jeu que ce n'etait
                    // PAS la cause du "mur/montagne" - le vrai bug etait dans
                    // despeckleHeightmap(), voir le fix + commentaire au-dessus de
                    // cette methode). placeWaterDams() comble les fuites d'eau AVANT
                    // le smooth pour que le lissage ne fige pas un plan d'eau perce ;
                    // les colonnes de barrage sont enregistrees dans DAM_COLS.
                    placeWaterDams(level, min, max);
                    smoothPass(level, min, max, 7, 50, () -> {
                        // Lissage final : les spheres restent incluses dans la heightmap.
                        // Leurs bords sont fondus vers l'interieur du terrain avant
                        // la vegetation et les arbres.
                        smoothPass(level, min, max, 15, 12, () -> {
                            // Le smooth peut laisser une poche d'eau a Y+1 ou dans
                            // une colonne voisine. On la retire apres le dernier
                            // smooth, avant de remettre l'herbe et la vegetation.
                            clearWaterPockets(level, min, max);
                            fixWaterNearStructure(level, min, max, 20);

                            // TOUTES les modifs de terrain AVANT le paste : grass, vegetation, cleanup.
                            // Le paste doit etre ABSOLUMENT le dernier pour ne pas ecraser les blocs.
                            verifyGrassSurface(level, min, max);
                            naturalize(level, min, max, level.getRandom());
                            cleanupZone(level, min, max);
                            deepluckyblock.util.DebugLog.structure("terrain pret (double smooth + grass + veg + cleanup) AVANT paste");
                            onReady.run();
                        });
                    });
                })));
    }

    /**
     * Retire les poches d'eau residuelles dans le trou de la structure et dans
     * une couronne de securite de 6 blocs. On scanne toute la hauteur, et pas
     * seulement la surface : cela corrige les poches situees a Y+1, Y+2, etc.
     */
    private static void clearWaterPockets(ServerLevel level, BlockPos min, BlockPos max) {
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        int margin = 6;
        int removed = 0;
        int x0 = min.getX() - margin;
        int x1 = max.getX() + margin;
        int z0 = min.getZ() - margin;
        int z1 = max.getZ() + margin;
        int y0 = Math.max(level.getMinBuildHeight(), min.getY() - 8);
        int y1 = Math.min(level.getMaxBuildHeight() - 1, max.getY() + 8);

        for (int x = x0; x <= x1; x++) {
            for (int z = z0; z <= z1; z++) {
                for (int y = y1; y >= y0; y--) {
                    pos.set(x, y, z);
                    BlockState state = level.getBlockState(pos);
                    if (state.getFluidState().is(net.minecraft.tags.FluidTags.WATER)) {
                        level.setBlock(pos, Blocks.AIR.defaultBlockState(), FAST_FLAG);
                        removed++;
                    }
                }
            }
        }

        if (removed > 0) {
            deepluckyblock.util.DebugLog.structure("clearWaterPockets : {} blocs d'eau retires dans la zone structure", removed);
        }
    }

    // Clear le footprint : supprime le terrain naturel AU-DESSUS du sol (pas de cratere,
    // on ne creuse jamais sous la surface). Batche via schedule.
    private static void clearFootprint(ServerLevel level, BlockPos min, BlockPos max, int topY, Runnable onDone) {
        List<int[]> cols = new ArrayList<>();
        for (int x = min.getX(); x <= max.getX(); x++)
            for (int z = min.getZ(); z <= max.getZ(); z++)
                cols.add(new int[]{x, z});
        int total = (cols.size() + CLEAR_BATCH_COLS - 1) / CLEAR_BATCH_COLS;
        if (total == 0) { if (onDone != null) onDone.run(); return; }
        BlockPos.MutableBlockPos mut = new BlockPos.MutableBlockPos();
        for (int b = 0; b < total; b++) {
            final int bi = b, bt = total;
            TestProcedure.schedule(level, TestProcedure.currentTick(level) + b + 1, () -> {
                int start = bi * CLEAR_BATCH_COLS, end = Math.min(start + CLEAR_BATCH_COLS, cols.size());
                for (int i = start; i < end; i++) {
                    int cx = cols.get(i)[0], cz = cols.get(i)[1];
                    int surfY = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, cx, cz);
                    for (int y = topY; y > surfY; y--) {
                        BlockState s = level.getBlockState(mut.set(cx, y, cz));
                        if (!s.isAir() && isNaturalTerrain(s)) level.setBlock(mut, Blocks.AIR.defaultBlockState(), 2);
                    }
                }
                if (bi == bt - 1 && onDone != null) onDone.run();
            });
        }
    }

    // Avant le smooth : remplit les vides SOUS la structure (emprise + 3 radius)
    // avec du grass block, du niveau de base de la structure jusqu'au premier bloc
    // solide. Garantit qu'il n'y a aucun vide sous la structure (pas de flottaison).
    // Batche via schedule.
    private static void prefillFoundation(ServerLevel level, BlockPos min, BlockPos max, int foundationBaseY, Runnable onDone) {
        List<int[]> cols = new ArrayList<>();
        for (int x = min.getX() - 3; x <= max.getX() + 3; x++)
            for (int z = min.getZ() - 3; z <= max.getZ() + 3; z++)
                cols.add(new int[]{x, z});
        int total = (cols.size() + CLEAR_BATCH_COLS - 1) / CLEAR_BATCH_COLS;
        if (total == 0) { if (onDone != null) onDone.run(); return; }
        BlockPos.MutableBlockPos mut = new BlockPos.MutableBlockPos();
        int minBuild = level.getMinBuildHeight();
        for (int b = 0; b < total; b++) {
            final int bi = b, bt = total;
            TestProcedure.schedule(level, TestProcedure.currentTick(level) + b + 1, () -> {
                int start = bi * CLEAR_BATCH_COLS, end = Math.min(start + CLEAR_BATCH_COLS, cols.size());
                int filled = 0;
                for (int i = start; i < end; i++) {
                    int cx = cols.get(i)[0], cz = cols.get(i)[1];
                    int surfaceY = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, cx, cz) - 1;
                    if (foundationBaseY > surfaceY) continue; // base au-dessus du sol -> pas de pilier
                    int y = foundationBaseY;
                    int depth = 0;
                    while (y >= minBuild && depth < 64) {
                        BlockState cur = level.getBlockState(mut.set(cx, y, cz));
                        if (!cur.isAir() && cur.blocksMotion()) break;
                        level.setBlock(mut, Blocks.GRASS_BLOCK.defaultBlockState(), FAST_FLAG);
                        filled++; y--; depth++;
                    }
                }
                if (bi == bt - 1) {
                    if (filled > 0) deepluckyblock.util.DebugLog.structure("prefillFoundation : {} blocs de grass_block (vides remplis)", filled);
                    if (onDone != null) onDone.run();
                }
            });
        }
    }

    // FIX CRITIQUE (rapporte en jeu : structure "Sylvan Citadel" spawnee a
    // moitie dans le vide, log "deltaY anormal apres smooth ... BORNE a -4").
    // Appelee en tout DERNIER recours, juste avant le paste reel, quand le
    // garde-fou MAX_POST_SMOOTH_DELTA_Y a du borner un effondrement de terrain
    // plus important que ce qu'il autorise a suivre (ravin/grotte/falaise
    // demasque par le smooth SEULEMENT APRES que verifyGrassSurface/
    // naturalize/cleanupZone de prepZone() aient deja tourne -- donc AUCUNE
    // des passes automatiques normales ne traite plus cette zone).
    //
    // CORRECTIF DEMANDE (retour utilisateur, ancien correctif juge
    // insuffisant : "il faut en dessous bien aplanir et creer la plateforme,
    // smooth le terrain en grand pour que le nouveau terrain soit
    // parfaitement blend, avec sur la stone des grass block pour rendre la
    // stone invisible, replanter si necessaire") : l'ancien backfillVoidGap
    // se contentait de boucher le trou EXACT sous l'emprise avec de la pierre
    // brute -- aucun raccord avec le relief environnant (mur vertical de
    // pierre nue a la limite de l'emprise), aucune herbe, aucune
    // replantation. Remplace par une VRAIE construction de plateforme :
    //   1. Sous l'emprise complete de la structure (+ marge de securite) :
    //      plateau plat solide (pierre en profondeur, terre pres de la
    //      surface, herbe en surface) au niveau ou la structure va etre
    //      posee -- garantit qu'aucune colonne du footprint ne reste creuse.
    //   2. Une COURONNE DE RACCORD (rampe en pente lineaire) autour du
    //      plateau, sur RAMP_RING blocs, qui descend/monte progressivement
    //      du niveau du plateau JUSQU'AU niveau REEL du terrain naturel deja
    //      mesure (realTerrainY) -- exactement le "smooth le terrain en
    //      grand pour blend" demande : plus de falaise nette, un talus doux.
    //   3. Chaque colonne traitee recoit un CAPPING D'HERBE explicite en
    //      surface (grass_block, ou neige si biome enneige) : la pierre
    //      utilisee pour combler/soutenir n'est donc JAMAIS visible.
    //   4. La replantation des arbres et la re-vegetalisation (fleurs,
    //      herbes hautes, champignons) de cette zone sont deja garanties
    //      ENSUITE par decorate() (naturalize + replantTrees, appeles apres
    //      le carve sur min/max reels de la structure + terrainRing() +
    //      NATURALIZE_EXTRA_RING, qui englobe cette couronne de raccord tant
    //      que RAMP_RING <= terrainRing()).
    private static final int PLATFORM_MAX_FILL_DEPTH = 64;
    // Largeur de la rampe de raccord (blocs) entre le plateau plat sous la
    // structure et le terrain naturel deja mesure. Volontairement <=
    // terrainRing() (14 a 48 selon la taille du build) pour que la
    // re-vegetalisation automatique de decorate() couvre bien toute la zone.
    private static final int RAMP_RING = 16;

    public static void backfillVoidGap(ServerLevel level, BlockPos pasteMin, BlockPos pasteMax, int realTerrainY) {
        BlockPos.MutableBlockPos mut = new BlockPos.MutableBlockPos();
        int platformFloorY = pasteMin.getY() - 1;
        int minBuild = level.getMinBuildHeight();
        int maxBuild = level.getMaxBuildHeight() - 1;
        int ring = Math.min(RAMP_RING, terrainRing());

        int x0 = pasteMin.getX() - ring, x1 = pasteMax.getX() + ring;
        int z0 = pasteMin.getZ() - ring, z1 = pasteMax.getZ() + ring;

        // Pre-chargement des chunks de la zone (comme smoothPass) : sans ca,
        // getHeight() sur un chunk non genere renverrait une hauteur fantome.
        for (int ccx = x0 >> 4; ccx <= x1 >> 4; ccx++)
            for (int ccz = z0 >> 4; ccz <= z1 >> 4; ccz++)
                level.getChunkSource().getChunk(ccx, ccz, net.minecraft.world.level.chunk.status.ChunkStatus.FULL, true);

        int filled = 0, capped = 0, cleared = 0;
        for (int x = x0; x <= x1; x++) {
            for (int z = z0; z <= z1; z++) {
                // Distance (en anneau carre, coherente avec le reste du fichier,
                // cf. sc()/smoothPass()) au bord de l'emprise de la structure.
                int dx = x < pasteMin.getX() ? pasteMin.getX() - x : (x > pasteMax.getX() ? x - pasteMax.getX() : 0);
                int dz = z < pasteMin.getZ() ? pasteMin.getZ() - z : (z > pasteMax.getZ() ? z - pasteMax.getZ() : 0);
                int dist = Math.max(dx, dz);

                int targetY;
                if (dist <= 0) {
                    targetY = platformFloorY; // plateau plat, exactement sous la structure
                } else if (dist >= ring) {
                    targetY = realTerrainY; // deja raccorde au terrain naturel
                } else {
                    double t = dist / (double) ring;
                    targetY = (int) Math.round(platformFloorY + (realTerrainY - platformFloorY) * t);
                }
                targetY = Math.max(minBuild + 1, Math.min(maxBuild - 1, targetY));

                boolean snowy = isSnowy(level, mut.set(x, targetY, z));
                BlockState capBlock = Blocks.GRASS_BLOCK.defaultBlockState();

                int curSurfaceY = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z) - 1;
                if (curSurfaceY < targetY) {
                    // Trou/vide sous le niveau vise : on remonte (pierre en
                    // profondeur, terre pres du sommet, herbe en surface).
                    int y = Math.max(curSurfaceY + 1, minBuild);
                    int depth = 0;
                    while (y <= targetY && depth < PLATFORM_MAX_FILL_DEPTH) {
                        BlockState fill = (y == targetY) ? capBlock
                                : (y >= targetY - 3 ? Blocks.DIRT.defaultBlockState() : Blocks.STONE.defaultBlockState());
                        level.setBlock(mut.set(x, y, z), fill, FAST_FLAG);
                        filled++; y++; depth++;
                    }
                } else if (curSurfaceY > targetY) {
                    // Terrain qui deborde au-dessus du niveau vise (bord de
                    // falaise cote plateau) : on degage jusqu'a targetY puis
                    // on recouvre d'herbe, exactement comme rebuildColumn().
                    for (int y = targetY + 1; y <= curSurfaceY; y++) {
                        BlockState s = level.getBlockState(mut.set(x, y, z));
                        if (!s.isAir() && !s.is(Blocks.BEDROCK)) { level.setBlock(mut, Blocks.AIR.defaultBlockState(), FAST_FLAG); cleared++; }
                    }
                    level.setBlock(mut.set(x, targetY, z), capBlock, FAST_FLAG);
                    capped++;
                } else {
                    // Deja au bon niveau : on s'assure juste que la pierre/terre
                    // n'est jamais visible en surface (demande explicite).
                    BlockState top = level.getBlockState(mut.set(x, targetY, z));
                    if (top.is(Blocks.STONE) || top.is(Blocks.DIRT) || top.is(Blocks.COBBLESTONE)
                            || top.is(Blocks.DEEPSLATE) || top.is(Blocks.ANDESITE) || top.is(Blocks.DIORITE) || top.is(Blocks.GRANITE)) {
                        level.setBlock(mut, capBlock, FAST_FLAG);
                        capped++;
                    }
                }

                if (snowy && level.getBlockState(mut.set(x, targetY + 1, z)).isAir()) {
                    level.setBlock(mut, Blocks.SNOW.defaultBlockState(), FAST_FLAG);
                }
            }
        }
        if (filled > 0 || capped > 0 || cleared > 0) {
            LOGGER.warn("[STRUCT5-VOID] plateforme de secours construite (raccord blend sur {} blocs) : {} blocs combles, {} blocs herbe/neige poses en surface, {} blocs de surplomb retires",
                    ring, filled, capped, cleared);
        }
    }


    // Avant le smooth : retire TOUS les decors de surface (feuilles, herbe, fleurs,
    // neige, vignes...) sur toute la zone GIGA. Sinon le smooth abaisse le terrain
    // et ces decors se retrouvent a flotter a leur ancienne position. Batche.
    private static void clearSurfaceDecor(ServerLevel level, BlockPos min, BlockPos max, Runnable onDone) {
        int x0 = min.getX() - terrainRing(), x1 = max.getX() + terrainRing();
        int z0 = min.getZ() - terrainRing(), z1 = max.getZ() + terrainRing();
        List<int[]> cols = new ArrayList<>();
        for (int x = x0; x <= x1; x++)
            for (int z = z0; z <= z1; z++)
                cols.add(new int[]{x, z});
        int total = (cols.size() + CLEAR_BATCH_COLS - 1) / CLEAR_BATCH_COLS;
        if (total == 0) { if (onDone != null) onDone.run(); return; }
        BlockPos.MutableBlockPos mut = new BlockPos.MutableBlockPos();
        for (int b = 0; b < total; b++) {
            final int bi = b, bt = total;
            TestProcedure.schedule(level, TestProcedure.currentTick(level) + b + 1, () -> {
                int start = bi * CLEAR_BATCH_COLS, end = Math.min(start + CLEAR_BATCH_COLS, cols.size());
                for (int i = start; i < end; i++) {
                    int cx = cols.get(i)[0], cz = cols.get(i)[1];
                    int surfY = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, cx, cz);
                    // On scanne large en hauteur : canopie au-dessus + tronc en dessous.
                    for (int y = surfY + 18; y >= surfY - 25; y--) {
                        if (y < level.getMinBuildHeight()) break;
                        BlockState s = level.getBlockState(mut.set(cx, y, cz));
                        if (!s.isAir() && isSurfaceDecor(s)) level.setBlock(mut, Blocks.AIR.defaultBlockState(), FAST_FLAG);
                    }
                }
                if (bi == bt - 1 && onDone != null) onDone.run();
            });
        }
    }

    /**
     * Decoration APRES paste + carve : herbe + replant des arbres sauves + naturalize
     * + cleanup (lave, eau courante fixee, feuilles volantes).
     */
    public static void decorate(ServerLevel level, BlockPos min, BlockPos max) {
        // APRES paste + carve : on naturalise une seconde fois avec la bounding box
        // exacte de la structure deja posee. Cette passe est indispensable : le
        // terrain directement contre les murs peut avoir ete modifie ou revele par
        // le carve apres le naturalize AVANT paste.
        naturalize(level, min, max, level.getRandom());

        // FIX (rapporte en jeu : "je vois de l'herbe/des fleurs flottantes apres
        // la pose d'une structure" -- capture d'ecran "herbe" flottante, PAS des
        // blocs de terre) : cleanupZone() (qui retire precisement les feuilles/
        // fleurs/herbes SANS support solide dans les 3 blocs du dessous, voir
        // isFloatingFoliage) n'etait appele que DANS prepZone(), donc UNIQUEMENT
        // AVANT le paste. Or le paste lui-meme (carve du sol sous la structure,
        // suppression de blocs techniques souterrains, naturalize() ci-dessus
        // qui vient de re-semer de la vegetation sur la surface fraichement
        // exposee) peut laisser -- ou creer -- des brins d'herbe/fleurs sans
        // aucun support en dessous, jamais balayes depuis. Rejouer cleanupZone()
        // ICI, apres le second naturalize() et avant le replant des arbres,
        // supprime cette vegetation flottante residuelle sans toucher aux
        // blocs de structure (isDecoration() ne cible que feuilles/neige/herbe/
        // fleurs/vigne/algues/BushBlock, jamais un bloc de construction).
        cleanupZone(level, min, max);

        // Puis on replante les arbres sauves sur leur nouvelle surface.
        replantTrees(level, LAST_TREES, min, max, () -> {
            deepluckyblock.util.DebugLog.structure("decorate termine (naturalize bord exact + cleanup vegetation flottante + replant arbres)");
        });
    }


    /** Cleanup final sur la zone GIGA : retire la lave, fixe l'eau courante en
     *  source (fixwater), supprime les feuilles/bois volants laisses par le smooth. */
    public static void cleanupZone(ServerLevel level, BlockPos min, BlockPos max) {
        BlockPos.MutableBlockPos mut = new BlockPos.MutableBlockPos();
        int x0 = min.getX() - terrainRing(), x1 = max.getX() + terrainRing();
        int z0 = min.getZ() - terrainRing(), z1 = max.getZ() + terrainRing();
        int removed = 0, waterFixed = 0;
        int minB = level.getMinBuildHeight();
        for (int x = x0; x <= x1; x++) {
            for (int z = z0; z <= z1; z++) {
                int surfY = level.getHeight(Heightmap.Types.WORLD_SURFACE, x, z);
                int top = Math.min(surfY + 25, level.getMaxBuildHeight() - 1);
                int bot = Math.max(surfY - 25, minB);
                for (int y = top; y >= bot; y--) {
                    BlockState s = level.getBlockState(mut.set(x, y, z));
                    if (s.isAir()) continue;
                    if (s.is(Blocks.LAVA)) { level.setBlock(mut, Blocks.AIR.defaultBlockState(), FAST_FLAG); removed++; continue; }
                    if (s.is(Blocks.WATER)) {
                        int lvl = s.getOptionalValue(net.minecraft.world.level.block.state.properties.BlockStateProperties.LEVEL).orElse(0);
                        if (lvl > 0) { level.setBlock(mut, Blocks.WATER.defaultBlockState(), FAST_FLAG); waterFixed++; }
                        continue;
                    }
                    if (isDecoration(s) && isFloatingFoliage(level, mut, x, y, z)) {
                        level.setBlock(mut, Blocks.AIR.defaultBlockState(), FAST_FLAG); removed++;
                    }
                }
            }
        }
        if (removed > 0 || waterFixed > 0)
            deepluckyblock.util.DebugLog.structure("cleanupZone : {} blocs retires (lave/feuilles volantes), {} eau fixee", removed, waterFixed);
    }

    // Sphere PLEINE de grass_block radius DAM_RADIUS, centree avec un decalage en
    // ZIGZAG (cellules de 4 blocs). COMPLETE : remplit l'air ET l'eau dans la sphere
    // (0 poche d'eau = 0 fuite). Au-dessus de la ligne d'eau on ne bouche pas le ciel
    // au-dessus du lac. Posee AVANT le smooth : le smooth IGNORE ces colonnes (DAM_COLS)
    // pour ne PAS ecraser les spheres en cylindres plats.
    private static int placeDamBank(ServerLevel level, int cx, int cy, int cz) {

        // Spheres de barrage placees deux blocs plus haut.
        int centerY = cy + 5;
        int placed = placeFullSphere(level, cx, centerY, cz, DAM_RADIUS);

        // Entre 1 et 6 spheres secondaires de rayon 5, collees a la sphere principale.
        int secondaryCount = 1 + level.getRandom().nextInt(6);
        int[] directions = new int[]{0, 1, 2, 3, 4, 5};
        shuffleDirections(directions, level.getRandom());

        int touchingDistance = DAM_RADIUS + 5;

        for (int i = 0; i < secondaryCount; i++) {
            int direction = directions[i];
            int sx = cx;
            int sz = cz;

            switch (direction) {
                case 0 -> sx += touchingDistance;
                case 1 -> sx -= touchingDistance;
                case 2 -> sz += touchingDistance;
                case 3 -> sz -= touchingDistance;
                case 4 -> {
                    sx += 10;
                    sz += 5;
                }
                case 5 -> {
                    sx -= 10;
                    sz -= 5;
                }
                default -> { }
            }

            placed += placeFullSphere(level, sx, centerY, sz, 5);
        }

        return placed;
    }

    /** Place une sphere pleine voxelisee, comme WorldEdit //br sphere. */
    private static int placeFullSphere(ServerLevel level, int cx, int cy, int cz, int radius) {
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        int radiusSquared = radius * radius;
        int count = 0;
        int minBuild = level.getMinBuildHeight();
        int maxBuild = level.getMaxBuildHeight() - 1;

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = -radius; dy <= radius; dy++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    if (dx * dx + dy * dy + dz * dz > radiusSquared) continue;

                    int x = cx + dx;
                    int y = cy + dy;
                    int z = cz + dz;

                    if (y < minBuild || y > maxBuild) continue;

                    pos.set(x, y, z);
                    level.setBlock(pos, Blocks.GRASS_BLOCK.defaultBlockState(), FAST_FLAG);
                    DAM_COLS.add(colKey(x, z));
                    count++;
                }
            }
        }

        return count;
    }

    private static void shuffleDirections(int[] values, RandomSource random) {
        for (int i = values.length - 1; i > 0; i--) {
            int j = random.nextInt(i + 1);
            int temp = values[i];
            values[i] = values[j];
            values[j] = temp;
        }
    }

    // Barrages d'eau : AVANT le smooth. Scanne la zone pour les points de fuite (eau
    // qui touche de l'air) et place des spheres PLEINES de grass_block. Comme c'est
    // avant le smooth, le smooth passe ensuite dessus et arrondit les spheres en
    // berges naturelles (au lieu de domes crus trop spheriques).
    public static void placeWaterDams(ServerLevel level, BlockPos min, BlockPos max) {
        BlockPos.MutableBlockPos mut = new BlockPos.MutableBlockPos();
        BlockPos.MutableBlockPos mut2 = new BlockPos.MutableBlockPos();
        int damRing = terrainRing();
        int x0 = min.getX() - damRing, x1 = max.getX() + damRing;
        int z0 = min.getZ() - damRing, z1 = max.getZ() + damRing;
        int minB = level.getMinBuildHeight();
        int placed = 0;
        DAM_COLS.clear();  // reset des colonnes de barrage (le smooth les ignorera)
        for (int x = x0; x <= x1; x++) {
            for (int z = z0; z <= z1; z++) {
                int surfY = level.getHeight(Heightmap.Types.WORLD_SURFACE, x, z);
                int top = Math.min(surfY + 25, level.getMaxBuildHeight() - 1);
                int bot = Math.max(surfY - 25, minB);
                for (int y = top; y >= bot; y--) {
                    BlockState waterState = level.getBlockState(mut.set(x, y, z));
                    if (!waterState.getFluidState().is(net.minecraft.tags.FluidTags.WATER)) continue;
                    boolean leak = false;
                    for (int[] dir : new int[][]{{1,0},{-1,0},{0,1},{0,-1}}) {
                        if (level.getBlockState(mut2.set(x + dir[0], y, z + dir[1])).isAir()) { leak = true; break; }
                    }
                    if (leak) placed += placeDamBank(level, x, y, z);
                }
            }
        }
        if (placed > 0) deepluckyblock.util.DebugLog.structure("placeWaterDams (AVANT smooth, zone elargie ring={}) : {} blocs de grass_block places", damRing, placed);
    }

    // Feuilles/bois volants : rien de solide dans les 3 blocs en dessous.
    private static boolean isFloatingFoliage(ServerLevel level, BlockPos.MutableBlockPos m, int x, int y, int z) {
        for (int dy = 1; dy <= 3; dy++) {
            BlockState b = level.getBlockState(m.set(x, y - dy, z));
            if (!b.isAir() && b.blocksMotion()) return false;
        }
        return true;
    }

    // =========================================================================
    // PHASE 1 : SCAN TREES
    // =========================================================================

    private static List<SavedTree> scanTrees(ServerLevel level, int x0, int z0, int x1, int z1, int topY) {
        List<SavedTree> trees = new ArrayList<>();
        Set<Long> visited = new HashSet<>();
        BlockPos.MutableBlockPos mut = new BlockPos.MutableBlockPos();

        for (int x = x0; x <= x1; x++) {
            for (int z = z0; z <= z1; z++) {
                for (int y = topY; y >= 1; y--) {
                    long key = BlockPos.asLong(x, y, z);
                    if (visited.contains(key)) continue;

                    BlockState s = level.getBlockState(mut.set(x, y, z));
                    if (!isLog(s)) continue;

                    // Trouve un arbre : flood-fill depuis le bas du tronc
                    int trunkBaseY = y;
                    while (trunkBaseY > 1 && isLog(level.getBlockState(mut.set(x, trunkBaseY - 1, z)))) {
                        trunkBaseY--;
                    }

                    // Flood-fill pour recuperer tous les blocs de l'arbre
                    List<SavedBlock> treeBlocks = new ArrayList<>();
                    Set<Long> treeSet = new HashSet<>();
                    Queue<int[]> queue = new ArrayDeque<>();
                    queue.add(new int[]{x, trunkBaseY, z});

                    while (!queue.isEmpty() && treeBlocks.size() < 500) {
                        int[] p = queue.poll();
                        long pk = BlockPos.asLong(p[0], p[1], p[2]);
                        if (treeSet.contains(pk)) continue;
                        treeSet.add(pk);
                        visited.add(pk);

                        BlockState bs = level.getBlockState(mut.set(p[0], p[1], p[2]));
                        if (!isLog(bs) && !isLeaf(bs)) continue;

                        treeBlocks.add(new SavedBlock(p[0] - x, p[1] - trunkBaseY, p[2] - z, bs));

                        for (int dx = -2; dx <= 2; dx++)
                            for (int dy = -1; dy <= 2; dy++)
                                for (int dz = -2; dz <= 2; dz++) {
                                    if (dx == 0 && dy == 0 && dz == 0) continue;
                                    queue.add(new int[]{p[0] + dx, p[1] + dy, p[2] + dz});
                                }
                    }

                    String type = treeTypeOf(treeBlocks.isEmpty() ? Blocks.OAK_LOG.defaultBlockState()
                            : treeBlocks.get(0).state());
                    trees.add(new SavedTree(x, z, trunkBaseY, type, treeBlocks));
                }
            }
        }
        return trees;
    }

    // =========================================================================
    // PHASE 2 : CLEAR (batche)
    // =========================================================================

    private static void clearArea(ServerLevel level, int x0, int z0, int x1, int z1, int topY, Runnable onDone) {
        List<int[]> cols = new ArrayList<>();
        for (int x = x0; x <= x1; x++)
            for (int z = z0; z <= z1; z++)
                cols.add(new int[]{x, z});

        int total = (cols.size() + CLEAR_BATCH_COLS - 1) / CLEAR_BATCH_COLS;
        if (total == 0) { if (onDone != null) onDone.run(); return; }

        BlockPos.MutableBlockPos mut = new BlockPos.MutableBlockPos();
        for (int b = 0; b < total; b++) {
            final int bi = b, bt = total;
            TestProcedure.schedule(level, TestProcedure.currentTick(level) + b + 1, () -> {
                int start = bi * CLEAR_BATCH_COLS, end = Math.min(start + CLEAR_BATCH_COLS, cols.size());
                for (int i = start; i < end; i++) {
                    int cx = cols.get(i)[0], cz = cols.get(i)[1];
                    for (int y = 1; y <= topY; y++) {
                        BlockState s = level.getBlockState(mut.set(cx, y, cz));
                        if (!s.isAir() && !s.is(Blocks.BEDROCK))
                            level.setBlock(mut, Blocks.AIR.defaultBlockState(), 2);
                    }
                }
                if (bi == bt - 1 && onDone != null) onDone.run();
            });
        }
    }

    // =========================================================================
    // PHASE 3a/3c : SMOOTH PASS (Gaussian sur heightmap, taille et passes parametrables)
    // =========================================================================

    /**
     * Smooth la heightmap en anneau autour de la structure.
     * @param kernelSize Taille du kernel (5 ou 15). La zone de la structure reste fixe.
     * @param passes Nombre de passes de lissage.
     */
    private static void smoothPass(ServerLevel level, BlockPos structMin, BlockPos structMax,
                                    int kernelSize, int passes, Runnable onDone) {
        int half = kernelSize / 2;
        // Zone elargie : structure + ring habituel + marge supplementaire.
        // Cette marge est necessaire pour atteindre les spheres situees
        // plus loin dans le paysage.
        int smoothRing = terrainRing();
        int x0 = structMin.getX() - smoothRing, x1 = structMax.getX() + smoothRing;
        int z0 = structMin.getZ() - smoothRing, z1 = structMax.getZ() + smoothRing;
        int w = x1 - x0 + 1, h = z1 - z0 + 1;

        // PRE-CHARGEMENT de TOUS les chunks de la zone (force-gen). Sans ça, getHeight
        // sur un chunk non généré renvoie une hauteur fantôme -> fossés / chunks lisses
        // d'un côté et pas de l'autre / paysage détruit. C'est LA cause racine.
        int chunkCount = 0;
        for (int ccx = x0 >> 4; ccx <= x1 >> 4; ccx++)
            for (int ccz = z0 >> 4; ccz <= z1 >> 4; ccz++) {
                if (level.getChunkSource().getChunk(ccx, ccz, net.minecraft.world.level.chunk.status.ChunkStatus.FULL, true) != null) chunkCount++;
            }
        deepluckyblock.util.DebugLog.structure("smooth : pré-chargement de {} chunks (zone {}x{})", chunkCount, w, h);

        // Heightmap d'origine (terrain naturel, servira pour le fade en bordure).
        int[][] orig = new int[w][h];
        for (int i = 0; i < w; i++)
            for (int j = 0; j < h; j++)
                orig[i][j] = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x0 + i, z0 + j) - 1;
        // Despeckle : sur certaines colonnes (typiquement le coin min/min de chaque
        // chunk) la heightmap renvoie une valeur corrompue (souvent le minBuildHeight).
        // Sans correction, le blur tire la cible vers le bas et rebuildColumn remonte
        // la colonne en stone+dirt+grass = une tour par coin de chunk. On remplace
        // toute valeur absurde par la mediane des 8 voisins.
        orig = despeckleHeightmap(orig, w, h, level.getMinBuildHeight());

        int sMinI = structMin.getX() - x0, sMaxI = structMax.getX() - x0;
        int sMinJ = structMin.getZ() - z0, sMaxJ = structMax.getZ() - z0;

        // Blur global sur TOUTE la zone (l'emprise n'est plus figee).
        int[][] hm = orig;
        for (int pass = 0; pass < passes; pass++) {
            int[][] blurred = new int[w][h];
            for (int i = 0; i < w; i++) {
                for (int j = 0; j < h; j++) {
                    long sum = 0, count = 0;
                    for (int ki = -half; ki <= half; ki++) {
                        for (int kj = -half; kj <= half; kj++) {
                            if (ki*ki + kj*kj > half*half) continue; // masque circulaire (pas carre)
                            int si = i + ki, sj = j + kj;
                            if (si < 0 || si >= w || sj < 0 || sj >= h) continue;
                            sum += hm[si][sj]; count++;
                        }
                    }
                    blurred[i][j] = count > 0 ? Math.max(1, (int)(sum / count)) : hm[i][j];
                }
            }
            hm = blurred;
        }

        // Fade : bande de lissage. ANCIEN comportement (bug) : fade=1 (100% flou)
        // PILE sur l'emprise de la structure et decroissant vers le bord -> le sol
        // sous la structure devenait la moyenne floutee d'un disque de ~80 blocs,
        // qui peut etre tres different (souvent plus haut : montagne) du sol PLAT
        // deja detecte par findFlat/findFlatArea AVANT le smooth. Consequence :
        // rebuildColumn remontait tout le terrain sous le batiment -> deltaY de
        // reancrage enorme (mur/montagne, decalage Y absurde), alors que le terrain
        // etait deja plat et n'avait besoin que du lissage de la couronne autour.
        //
        // NOUVEAU comportement : on ANCRE l'emprise (+ marge de securite) sur la
        // hauteur d'ORIGINE (fade=0, aucun flou) puisque findFlat/findFlatArea ont
        // deja garanti un sol plat a cet endroit precis. Le flou monte ensuite en
        // s'eloignant (bande mediane a fade=1 = lissage plein, INCHANGE) puis
        // redescend vers 0 au bord exterieur de la zone pour se raccorder au
        // terrain naturel (comportement de raccord deja existant, conserve).
        int[][] target = new int[w][h];
        double maxFade = smoothRing;
        // Marge d'ancrage : rayon (en blocs, au-dela de l'emprise) laisse a la
        // hauteur d'origine. Couvre l'emprise elle-meme + une petite bordure pour
        // que les fondations/abords immediats de la structure ne bougent jamais.
        double anchorMargin = Math.min(4.0, maxFade * 0.2);
        // Le pic de flou (fade=1) est atteint a mi-couronne : le lissage du
        // paysage environnant reste donc plein, seule la zone pres du batiment
        // est desormais protegee.
        double peakDist = anchorMargin + Math.max(1.0, (maxFade - anchorMargin) * 0.5);
        for (int i = 0; i < w; i++) {
            for (int j = 0; j < h; j++) {
                int dx = (i < sMinI) ? (sMinI - i) : ((i > sMaxI) ? (i - sMaxI) : 0);
                int dz = (j < sMinJ) ? (sMinJ - j) : ((j > sMaxJ) ? (j - sMaxJ) : 0);
                double dist = Math.max(dx, dz);
                double fade;
                if (dist <= anchorMargin) {
                    fade = 0.0; // sous/pres de la structure : hauteur d'origine intacte
                } else if (dist <= peakDist) {
                    fade = (dist - anchorMargin) / (peakDist - anchorMargin); // montee vers plein flou
                } else {
                    fade = 1.0 - Math.min(1.0, (dist - peakDist) / (maxFade - peakDist)); // redescente vers terrain naturel
                }
                target[i][j] = (int) Math.round(orig[i][j] + (hm[i][j] - orig[i][j]) * fade);
            }
        }

        // Reconstruire en batch (toute la zone ; les cols sans changement sont skipees).
        // On passe aussi la heightmap CAPTUREE (despecklee) pour que rebuildColumn ne
        // re-interroge pas getHeight() : sur les colonnes corrompues ça remonterait
        // des tours. La hauteur de reference devient deterministe.
        rebuildTerrainBatched(level, target, orig, x0, z0, w, h, onDone);
    }

    private static void rebuildTerrainBatched(ServerLevel level, int[][] hm, int[][] orig, int x0, int z0,
                                              int w, int h, Runnable onDone) {
        // Toutes les colonnes de la zone (l'emprise n'est plus figee : le fade
        // la fait passer en douceur vers le terrain naturel).
        // cols = { x, z, targetY, origY } : origY est la hauteur capturee (despecklee)
        // au debut du smooth. On la donne a rebuildColumn au lieu de laisser
        // re-interroger getHeight() (corrompue sur les coins de chunk).
        List<int[]> cols = new ArrayList<>();
        for (int i = 0; i < w; i++)
            for (int j = 0; j < h; j++) {
                // IMPORTANT : les colonnes des spheres ne sont PAS exclues.
                // Leur heightmap est donc luissee avec le terrain general.
                cols.add(new int[]{x0 + i, z0 + j, hm[i][j], orig[i][j]});
            }
        int total = (cols.size() + CLEAR_BATCH_COLS - 1) / CLEAR_BATCH_COLS;
        if (total == 0) { if (onDone != null) onDone.run(); return; }
        BlockPos.MutableBlockPos mut = new BlockPos.MutableBlockPos();
        for (int b = 0; b < total; b++) {
            final int bi = b, bt = total;
            TestProcedure.schedule(level, TestProcedure.currentTick(level) + b + 1, () -> {
                int start = bi * CLEAR_BATCH_COLS, end = Math.min(start + CLEAR_BATCH_COLS, cols.size());
                for (int i = start; i < end; i++) {
                    int[] c = cols.get(i);
                    rebuildColumn(level, mut, c[0], c[1], c[2], c[3]);
                }
                if (bi == bt - 1 && onDone != null) onDone.run();
            });
        }
    }

    // Despeckle de la heightmap capturee : remplace toute valeur aberrante (coins
    // de chunk ou la heightmap est corrompue et renvoie le minBuildHeight) par la
    // mediane des 8 voisins.
    //
    // BUG TROUVE (trace litterale, logs a l'appui - voir dernierslogs3.txt) : le
    // critere additionnel "Math.abs(v - med) > 40" ne detecte PAS que la
    // corruption de coin de chunk, il declenche aussi sur tout relief NATUREL et
    // REEL (falaise, colline, pente) des que deux colonnes voisines different de
    // plus de 40 blocs, ce qui est courant en terrain accidente. Preuve chiffree :
    // pour la citadelle (zone 216x232 = 50112 colonnes), ce critere a "corrige"
    // 49362 colonnes (98.5% de la zone) en un seul passage. Une vraie corruption
    // de coin de chunk ne touche qu'~1 colonne par chunk (224 chunks preloades
    // ici -> ~224 attendues, pas 49362 : facteur ~220x trop eleve). Ce despeckle
    // ecrasait donc du relief reel vers la mediane locale AVANT les passes de flou
    // (7x7 x50 puis 15x15 x12), qui diffusaient ensuite cette heightmap deja
    // aplatie sur toute la couronne (jusqu'a 74-80 blocs de rayon) -> plateau
    // artificiel uniforme = le "mur/montagne au sommet plat" rapporte en jeu.
    //
    // FIX : on ne corrige plus que le vrai signal de corruption (valeur au ras du
    // bedrock, "v < floor"), qui est le seul cas documente de heightmap corrompue
    // aux coins de chunk. Le relief reel n'est plus touche ici : c'est le fade
    // (anchor/peak/decroissance) de smoothPass() qui a deja la charge de fondre
    // la structure dans le terrain reel, quelle que soit sa forme.
    private static int[][] despeckleHeightmap(int[][] src, int w, int h, int minBuild) {
        int[][] out = new int[w][h];
        int fixed = 0;
        int floor = minBuild + 8; // aucune surface reelle n'est au niveau du bedrock
        int[] nb = new int[8];
        for (int i = 0; i < w; i++) {
            for (int j = 0; j < h; j++) {
                int v = src[i][j];
                if (v < floor) {
                    int n = 0;
                    for (int di = -1; di <= 1; di++) {
                        for (int dj = -1; dj <= 1; dj++) {
                            if (di == 0 && dj == 0) continue;
                            int ni = i + di, nj = j + dj;
                            if (ni < 0 || ni >= w || nj < 0 || nj >= h) continue;
                            nb[n++] = src[ni][nj];
                        }
                    }
                    if (n > 0) {
                        java.util.Arrays.sort(nb, 0, n);
                        out[i][j] = nb[n / 2];
                        fixed++;
                        continue;
                    }
                }
                out[i][j] = v;
            }
        }
        if (fixed > 0)
            deepluckyblock.util.DebugLog.structure("despeckle : {} colonnes de heightmap corrigees (coins de chunk corrompus, sous floor={})", fixed, floor);
        return out;
    }

    // Reconstruit une colonne : remet le terrain a la hauteur cible (targetY).
    // currentY = hauteur CAPTUREE (origY, despecklee) au debut du smooth. On ne
    // re-interroge PAS getHeight() : sur certaines colonnes (coins de chunk) la
    // heightmap renvoie une valeur corrompue, ce qui ferait monter une tour de
    // stone+dirt+grass a chaque coin de chunk.
    private static void rebuildColumn(ServerLevel level, BlockPos.MutableBlockPos mut, int cx, int cz, int targetY, int origY) {
        int currentY = origY;
        if (currentY < targetY) {
            for (int y = currentY + 1; y <= targetY; y++) {
                BlockState fill = (y == targetY) ? Blocks.GRASS_BLOCK.defaultBlockState()
                        : (y >= targetY - 3 ? Blocks.DIRT.defaultBlockState() : Blocks.STONE.defaultBlockState());
                level.setBlock(mut.set(cx, y, cz), fill, FAST_FLAG);
            }
        } else if (currentY > targetY) {
            for (int y = targetY + 1; y <= currentY; y++) {
                BlockState s = level.getBlockState(mut.set(cx, y, cz));
                if (!s.isAir() && !s.is(Blocks.BEDROCK)) level.setBlock(mut, Blocks.AIR.defaultBlockState(), FAST_FLAG);
            }
            BlockState surf = level.getBlockState(mut.set(cx, targetY, cz));
            if (surf.isAir() || !surf.blocksMotion()) level.setBlock(mut, Blocks.GRASS_BLOCK.defaultBlockState(), FAST_FLAG);
        }
    }

    // =========================================================================
    // PHASE 3b : CLEANUP OVERLAP (supprime le terrain dans l'emprise structure)
    // Skip les chunks majoritairement air (JAMAIS vider l'air).
    // =========================================================================

    private static void cleanupOverlap(ServerLevel level, BlockPos structMin, BlockPos structMax, Runnable onDone) {
        BlockPos.MutableBlockPos mut = new BlockPos.MutableBlockPos();
        int maxY = structMax.getY() + 3;
        int deleted = 0;

        for (int x = structMin.getX(); x <= structMax.getX(); x++) {
            for (int z = structMin.getZ(); z <= structMax.getZ(); z++) {
                // Compter les blocs solides dans cette colonne (de Y=1 a maxY)
                int solidCount = 0;
                for (int y = 1; y <= maxY; y++) {
                    BlockState s = level.getBlockState(mut.set(x, y, z));
                    if (!s.isAir() && s.blocksMotion()) solidCount++;
                }
                // Skip si la colonne est majoritairement air (< 3 blocs solides sur toute la hauteur)
                // = on ne vide PAS les chunks a air. JAMAIS.
                if (solidCount < 3) continue;

                // Sinon : supprimer les blocs solides AU-DESSUS du sol de la structure
                // (terrain qui a deborde dans l'emprise pendant le smooth)
                int baseY = structMin.getY();
                for (int y = baseY + 1; y <= maxY; y++) {
                    BlockState s = level.getBlockState(mut.set(x, y, z));
                    if (!s.isAir() && s.blocksMotion()
                            && !s.is(Blocks.BEDROCK) && !s.is(Blocks.GRASS_BLOCK)) {
                        // Verifier que ce n'est pas un bloc de structure (pierre taille, brique, bois, etc.)
                        // On ne supprime que les blocs de terrain naturel (dirt, stone, grass, sand, gravel, etc.)
                        if (isNaturalTerrain(s)) {
                            level.setBlock(mut, Blocks.AIR.defaultBlockState(), 2);
                            deleted++;
                        }
                    }
                }
            }
        }
        if (deleted > 0)
            deepluckyblock.util.DebugLog.structure("cleanupOverlap : {} blocs de terrain supprimes dans l'emprise", deleted);
        if (onDone != null) onDone.run();
    }

    private static boolean isNaturalTerrain(BlockState s) {
        if (isLog(s) || isLeaf(s)) return true;
        return s.is(Blocks.DIRT) || s.is(Blocks.STONE) || s.is(Blocks.GRASS_BLOCK)
            || s.is(Blocks.SAND) || s.is(Blocks.GRAVEL) || s.is(Blocks.COARSE_DIRT)
            || s.is(Blocks.PODZOL) || s.is(Blocks.MYCELIUM) || s.is(Blocks.RED_SAND)
            || s.is(Blocks.TERRACOTTA) || s.is(Blocks.SANDSTONE) || s.is(Blocks.RED_SANDSTONE)
            || s.is(Blocks.GRANITE) || s.is(Blocks.DIORITE) || s.is(Blocks.ANDESITE)
            || s.is(Blocks.DEEPSLATE) || s.is(Blocks.TUFF) || s.is(Blocks.CALCITE)
            || s.is(Blocks.MOSS_BLOCK) || s.is(Blocks.MUD) || s.is(Blocks.CLAY)
            || s.is(Blocks.SNOW_BLOCK) || s.is(Blocks.ICE) || s.is(Blocks.PACKED_ICE)
            || s.is(Blocks.COAL_ORE) || s.is(Blocks.IRON_ORE) || s.is(Blocks.COPPER_ORE) || s.is(Blocks.GOLD_ORE)
            || s.is(Blocks.REDSTONE_ORE) || s.is(Blocks.LAPIS_ORE) || s.is(Blocks.DIAMOND_ORE) || s.is(Blocks.EMERALD_ORE)
            || s.is(Blocks.DEEPSLATE_COAL_ORE) || s.is(Blocks.DEEPSLATE_IRON_ORE) || s.is(Blocks.DEEPSLATE_COPPER_ORE)
            || s.is(Blocks.DEEPSLATE_GOLD_ORE) || s.is(Blocks.DEEPSLATE_REDSTONE_ORE) || s.is(Blocks.DEEPSLATE_LAPIS_ORE)
            || s.is(Blocks.DEEPSLATE_DIAMOND_ORE) || s.is(Blocks.DEEPSLATE_EMERALD_ORE);
    }

    // =========================================================================
    // PHASE 3d : VERIFY GRASS BLOCK (surface en herbe)
    // =========================================================================

    private static void verifyGrassSurface(ServerLevel level, BlockPos structMin, BlockPos structMax) {
        BlockPos.MutableBlockPos mut = new BlockPos.MutableBlockPos();
        int grass = 0, snow = 0;
        // Toute la zone GIGA lissée : grass en surface, + snow layer si biome enneigé
        // (sinon les blocs d'herbe en zone de neige ont une texture buggée).
        for (int x = structMin.getX() - terrainRing(); x <= structMax.getX() + terrainRing(); x++) {
            for (int z = structMin.getZ() - terrainRing(); z <= structMax.getZ() + terrainRing(); z++) {
                int surfY = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z) - 1;
                if (surfY < 1) continue;
                BlockState s = level.getBlockState(mut.set(x, surfY, z));
                if (s.isAir()) continue;
                boolean snowy = isSnowy(level, mut);
                if (s.is(Blocks.SNOW_BLOCK) || s.is(Blocks.PACKED_ICE) || s.is(Blocks.BLUE_ICE)) {
                    if (level.getBlockState(mut.set(x, surfY + 1, z)).isAir()) {
                        level.setBlock(mut, Blocks.SNOW.defaultBlockState(), 3); snow++;
                    }
                } else if (snowy) {
                    // Biome enneigé : sol en herbe + snow layer (sinon texture buggée).
                    if (s.blocksMotion() && isNaturalTerrain(s) && !s.is(Blocks.GRASS_BLOCK)
                            && !s.is(Blocks.SAND) && !s.is(Blocks.SANDSTONE) && !s.is(Blocks.RED_SAND)) {
                        level.setBlock(mut.set(x, surfY, z), Blocks.GRASS_BLOCK.defaultBlockState(), 2); grass++;
                    }
                    if (level.getBlockState(mut.set(x, surfY + 1, z)).isAir()) {
                        level.setBlock(mut, Blocks.SNOW.defaultBlockState(), 3); snow++;
                    }
                } else if (s.blocksMotion() && isNaturalTerrain(s) && !s.is(Blocks.GRASS_BLOCK)
                        && !s.is(Blocks.SAND) && !s.is(Blocks.SANDSTONE) && !s.is(Blocks.RED_SAND)) {
                    level.setBlock(mut.set(x, surfY, z), Blocks.GRASS_BLOCK.defaultBlockState(), 2); grass++;
                }
            }
        }
        if (grass > 0 || snow > 0)
            deepluckyblock.util.DebugLog.structure("verifyGrassSurface : {} grass, {} snow layers", grass, snow);
    }

    /** True si le biome a la position est enneigé. On vérifie via le nom du biome
     *  (snow/ice/frozen) car getPrecipitation() n'existe pas dans cette version de Forge. */
    private static boolean isSnowy(ServerLevel level, BlockPos pos) {
        try {
            var biomeKey = level.getBiome(pos).unwrapKey();
            if (biomeKey.isEmpty()) return false;
            String path = biomeKey.get().location().getPath().toLowerCase();
            return path.contains("snow") || path.contains("ice") || path.contains("frozen");
        } catch (Exception e) {
            return false;
        }
    }

    // =========================================================================
    // PHASE 5 : REPLANT TREES
    // =========================================================================

    private static void replantTrees(ServerLevel level, List<SavedTree> trees,
                                      BlockPos structMin, BlockPos structMax, Runnable onDone) {
        RandomSource random = level.getRandom();
        int count = 0;

        for (SavedTree tree : trees) {
            int tx = tree.baseX(), tz = tree.baseZ();

            // Skip si dans l'emprise de la structure (on ne replante pas dessus)
            if (tx >= structMin.getX() && tx <= structMax.getX()
                    && tz >= structMin.getZ() && tz <= structMax.getZ()) continue;

            // VRAI arbre : on fait pousser une feature d'arbre vanilla a la nouvelle
            // surface. Fini les demi-arbres inventes dont les feuilles pourrissent.
            int newSurfaceY = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, tx, tz);
            BlockPos pos = new BlockPos(tx, newSurfaceY, tz);
            if (placeRealTree(level, tree.type(), pos, random)) count++;
        }
        if (count > 0) deepluckyblock.util.DebugLog.structure("replant : {} arbres reels replantes", count);

        if (onDone != null) onDone.run();
    }

    /** Fait pousser un VRAI arbre : pose une bouture (sapling) au stage 1 puis
     *  declenche sa croissance via performBonemeal. C'est le chemin canonique du
     *  jeu (identique a la poudre d'os) -> arbres complets et stables, finis les
     *  demi-arbres dont les feuilles pourrissent. */
    private static boolean placeRealTree(ServerLevel level, String type, BlockPos pos, RandomSource random) {
        net.minecraft.world.level.block.SaplingBlock sapling = saplingFor(type);
        // Sol valide (grass/dirt) sous la bouture, sinon l'arbre ne pousse pas.
        BlockState ground = level.getBlockState(pos.below());
        if (!ground.is(Blocks.GRASS_BLOCK) && !ground.is(Blocks.DIRT) && !ground.is(Blocks.COARSE_DIRT)
                && !ground.is(Blocks.PODZOL) && !ground.is(Blocks.MOSS_BLOCK) && !ground.is(Blocks.ROOTED_DIRT)) {
            level.setBlock(pos.below(), Blocks.GRASS_BLOCK.defaultBlockState(), 2);
        }
        // Forcer l'air au-dessus (espace pour le tronc + feuilles).
        level.setBlock(pos, Blocks.AIR.defaultBlockState(), 2);
        BlockState saplingState = sapling.defaultBlockState().setValue(net.minecraft.world.level.block.SaplingBlock.STAGE, 1);
        level.setBlock(pos, saplingState, 3);
        sapling.performBonemeal(level, random, pos, saplingState);
        return true;
    }

    private static net.minecraft.world.level.block.SaplingBlock saplingFor(String type) {
        if (type == null) return (net.minecraft.world.level.block.SaplingBlock) Blocks.OAK_SAPLING;
        switch (type) {
            case "oak" -> { return (net.minecraft.world.level.block.SaplingBlock) Blocks.OAK_SAPLING; }
            case "birch" -> { return (net.minecraft.world.level.block.SaplingBlock) Blocks.BIRCH_SAPLING; }
            case "spruce" -> { return (net.minecraft.world.level.block.SaplingBlock) Blocks.SPRUCE_SAPLING; }
            case "jungle" -> { return (net.minecraft.world.level.block.SaplingBlock) Blocks.JUNGLE_SAPLING; }
            case "acacia" -> { return (net.minecraft.world.level.block.SaplingBlock) Blocks.ACACIA_SAPLING; }
            case "dark_oak" -> { return (net.minecraft.world.level.block.SaplingBlock) Blocks.OAK_SAPLING; }
            case "cherry" -> { return (net.minecraft.world.level.block.SaplingBlock) Blocks.CHERRY_SAPLING; }
            default -> { }
        }

        ResourceLocation logId = ResourceLocation.tryParse(type);
        if (logId != null) {
            String path = logId.getPath();
            String family = path.replaceAll("(_stripped)?_(log|wood|stem|hyphae)$", "");
            for (Block block : net.minecraft.core.registries.BuiltInRegistries.BLOCK) {
                ResourceLocation id = net.minecraft.core.registries.BuiltInRegistries.BLOCK.getKey(block);
                if (id == null || !id.getNamespace().equals(logId.getNamespace())) continue;
                String candidate = id.getPath();
                if (candidate.equals(family + "_sapling")
                        && block instanceof net.minecraft.world.level.block.SaplingBlock sapling) {
                    return sapling;
                }
            }
        }
        return (net.minecraft.world.level.block.SaplingBlock) Blocks.OAK_SAPLING;
    }

    // =========================================================================
    // PHASE 6 : NATURALIZE (herbe, fleurs, bonemeal)
    // =========================================================================

    /** Fixe l'eau autour de la structure, equivalent pratique d'un //fixwater 20. */
    private static void fixWaterNearStructure(ServerLevel level, BlockPos min, BlockPos max, int radius) {
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        int x0 = min.getX() - radius, x1 = max.getX() + radius;
        int z0 = min.getZ() - radius, z1 = max.getZ() + radius;
        int changed = 0;

        // Plusieurs passes permettent de stabiliser les poches et les filets
        // d'eau qui se trouvent a des hauteurs differentes.
        for (int pass = 0; pass < 4; pass++) {
            for (int x = x0; x <= x1; x++) {
                for (int z = z0; z <= z1; z++) {
                    int surface = level.getHeight(Heightmap.Types.WORLD_SURFACE, x, z);
                    int y0 = Math.max(level.getMinBuildHeight(), surface - 20);
                    int y1 = Math.min(level.getMaxBuildHeight() - 1, surface + 20);

                    for (int y = y1; y >= y0; y--) {
                        pos.set(x, y, z);
                        BlockState state = level.getBlockState(pos);
                        if (state.getFluidState().is(net.minecraft.tags.FluidTags.WATER)) {
                            int fluidLevel = state.getOptionalValue(
                                    net.minecraft.world.level.block.state.properties.BlockStateProperties.LEVEL
                            ).orElse(0);

                            // Dans Minecraft, l'eau source et l'eau courante
                            // utilisent toutes deux Blocks.WATER. La propriété
                            // LEVEL permet de distinguer les deux.
                            if (fluidLevel > 0) {
                                level.setBlock(pos, Blocks.WATER.defaultBlockState(), FAST_FLAG);
                                changed++;
                            }
                        }
                    }
                }
            }
        }

        if (changed > 0) {
            deepluckyblock.util.DebugLog.structure("fixWaterNearStructure : {} blocs d'eau courante convertis en sources (rayon {})", changed, radius);
        }
    }

    private static void naturalize(ServerLevel level, BlockPos structMin, BlockPos structMax, RandomSource random) {
        BlockPos.MutableBlockPos mut = new BlockPos.MutableBlockPos();
        int naturalizeRing = terrainRing() + NATURALIZE_EXTRA_RING;
        int x0 = structMin.getX() - naturalizeRing, x1 = structMax.getX() + naturalizeRing;
        int z0 = structMin.getZ() - naturalizeRing, z1 = structMax.getZ() + naturalizeRing;

        int placedFlowers = 0, placedMushrooms = 0, placedGrass = 0;

        for (int x = x0; x <= x1; x++) {
            for (int z = z0; z <= z1; z++) {
                // Ne pas exclure l'emprise : apres le paste, les grass_blocks
                // presents dans la structure doivent eux aussi etre analyses.
                // Si un bloc de structure est au-dessus, above.isAir() empeche
                // automatiquement de poser une plante dessus.
                int surfaceY = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
                BlockState surface = level.getBlockState(mut.set(x, surfaceY - 1, z));

                // Couronne directement collee a la structure : les colonnes
                // exterieures commencent a 1 bloc du bord du build.
                int dxToBuild = x < structMin.getX() ? structMin.getX() - x
                        : (x > structMax.getX() ? x - structMax.getX() : 0);
                int dzToBuild = z < structMin.getZ() ? structMin.getZ() - z
                        : (z > structMax.getZ() ? z - structMax.getZ() : 0);
                boolean nearStructure = dxToBuild <= 12 && dzToBuild <= 12;

                // Si la surface est de l'herbe, on naturalize
                if (surface.is(Blocks.GRASS_BLOCK)) {
                    BlockState above = level.getBlockState(mut.set(x, surfaceY, z));
                    if (!above.isAir()) continue;

                    // FIX (demande utilisateur, "reduire de 50% la densite de
                    // nature au sol et rendre le placement plus aleatoire") :
                    // fenetre de couverture divisee par 2 (etait 5-70%, devient
                    // 2-35%), et on rajoute un second jet aleatoire INDEPENDANT
                    // (independent thinning) pour casser les motifs previsibles
                    // colonne-par-colonne -- le resultat est plus clairsemee ET
                    // moins "en bloc" que l'ancien calcul.
                    int coverageChance = 2 + random.nextInt(34); // ~ moitie de l'ancien 5-70
                    if (random.nextInt(100) >= coverageChance) continue;
                    if (random.nextInt(100) >= 50) continue; // thinning independant supplementaire (-50% de plus)

                    int r = random.nextInt(100);
                    int grassChance = nearStructure ? 58 : 50;
                    int fernChance = nearStructure ? 76 : 72;
                    int mushroomChance = fernChance + 1; // ~1/30 des tuiles vegetalisees -> voir MUSHROOM_ODDS ci-dessous
                    if (r < grassChance) {
                        // FIX (rapporte en jeu : "la naturalisation pose un
                        // grass_block plein au lieu de la petite touffe
                        // d'herbe deco") : Blocks.GRASS_BLOCK est le bloc de
                        // TERRE herbeuse pleine (le sol), PAS une plante -- la
                        // petite deco vanilla est Blocks.SHORT_GRASS (nom
                        // 1.20.3+, ex-"grass"). L'ancien code posait donc un
                        // second bloc de terre solide flottant au-dessus du
                        // sol au lieu d'un brin d'herbe traversable.
                        int grassH = random.nextInt(2);
                        BlockState grass = grassH == 0 ? Blocks.SHORT_GRASS.defaultBlockState() : Blocks.TALL_GRASS.defaultBlockState();
                        level.setBlock(mut, grass, 2);
                        if (grassH == 1) level.setBlock(mut.set(x, surfaceY + 1, z), Blocks.TALL_GRASS.defaultBlockState().setValue(net.minecraft.world.level.block.DoublePlantBlock.HALF, net.minecraft.world.level.block.state.properties.DoubleBlockHalf.UPPER), 2);
                        placedGrass++;
                    } else if (r < fernChance) {
                        level.setBlock(mut, Blocks.FERN.defaultBlockState(), 2);
                    } else if (r < mushroomChance) {
                        // Pool de champignons (vanilla + mods, voir mushroomPool()) :
                        // ~1/30 de "champignon pousse" (bloc geant, cap+stem)
                        // parmi les tuiles qui tombent dans cette tranche, le
                        // reste = petit champignon simple (brown/red/mod).
                        Block small = pickWeighted(mushroomPool(), random);
                        if (small != null) {
                            if (random.nextInt(30) == 0) {
                                placeGrownMushroom(level, mut, x, surfaceY, z, small, random);
                            } else {
                                level.setBlock(mut, small.defaultBlockState(), 2);
                            }
                            placedMushrooms++;
                        }
                    } else {
                        // Pool de fleurs (vanilla 1.21.1 complete + mods, ponderee
                        // par rarete realiste, voir flowerPool()) : jamais d'eau
                        // (aucune fleur/plante n'implique de placer de fluide).
                        Block flower = pickWeighted(flowerPool(), random);
                        if (flower != null) {
                            level.setBlock(mut, flower.defaultBlockState(), 2);
                            placedFlowers++;
                        }
                    }
                }
            }
        }
        if (placedFlowers > 0 || placedMushrooms > 0 || placedGrass > 0) {
            deepluckyblock.util.DebugLog.structure(
                    "naturalize : {} herbes, {} fleurs, {} champignons places (zone {}x{})",
                    placedGrass, placedFlowers, placedMushrooms, (x1 - x0 + 1), (z1 - z0 + 1));
        }
    }

    // =========================================================================
    // POOLS DE FLEURS / CHAMPIGNONS -- ponderees par rarete, compatibles mods
    // =========================================================================
    //
    // FIX (demande utilisateur) :
    //  - TOUTES les fleurs vanilla 1.21.1 dans la pool, avec une pondperation de
    //    rarete réaliste (dandelion/poppy tres communes, torchflower tres rare
    //    -- le torchflower ne pousse meme pas naturellement en 1.21.1, donc son
    //    poids est volontairement minuscule ici : simple clin d'oeil de rarete).
    //  - Pool de champignons avec un taux de "champignon pousse" (=huge
    //    mushroom, cap+stem) d'environ 1/30 (voir placeGrownMushroom + le
    //    random.nextInt(30) ci-dessus).
    //  - Compatible mods : toute fleur/champignon appartenant aux tags
    //    #minecraft:flowers / #minecraft:small_flowers ou dont le block
    //    registre est un MushroomBlock, provenant de N'IMPORTE QUEL namespace
    //    (pas seulement "minecraft"), est automatiquement integree -- un autre
    //    mod qui enregistre ses propres fleurs/champignons avec ces tags
    //    apparait donc dans la pool sans code specifique.
    //  - Jamais d'eau : ni les fleurs ni les champignons ne sont des blocs de
    //    fluide, et scanFlowers()/scanMushrooms() filtrent explicitement tout
    //    bloc dont le FluidState par defaut n'est pas vide (garde-fou meme si
    //    un mod exotique venait a taguer un bloc "flowers" de façon absurde).

    private record WeightedBlock(Block block, int weight) {}

    private static List<WeightedBlock> FLOWER_POOL;
    private static List<WeightedBlock> MUSHROOM_POOL;

    /** Poids de rarete vanilla (plus haut = plus commun). Absent de la map = poids par defaut (mods). */
    private static final Map<ResourceLocation, Integer> VANILLA_FLOWER_WEIGHTS = Map.ofEntries(
            Map.entry(ResourceLocation.withDefaultNamespace("dandelion"), 100),
            Map.entry(ResourceLocation.withDefaultNamespace("poppy"), 100),
            Map.entry(ResourceLocation.withDefaultNamespace("azure_bluet"), 40),
            Map.entry(ResourceLocation.withDefaultNamespace("oxeye_daisy"), 40),
            Map.entry(ResourceLocation.withDefaultNamespace("cornflower"), 35),
            Map.entry(ResourceLocation.withDefaultNamespace("blue_orchid"), 20),
            Map.entry(ResourceLocation.withDefaultNamespace("allium"), 20),
            Map.entry(ResourceLocation.withDefaultNamespace("lily_of_the_valley"), 18),
            Map.entry(ResourceLocation.withDefaultNamespace("red_tulip"), 25),
            Map.entry(ResourceLocation.withDefaultNamespace("orange_tulip"), 25),
            Map.entry(ResourceLocation.withDefaultNamespace("white_tulip"), 25),
            Map.entry(ResourceLocation.withDefaultNamespace("pink_tulip"), 25),
            Map.entry(ResourceLocation.withDefaultNamespace("wither_rose"), 1),
            Map.entry(ResourceLocation.withDefaultNamespace("torchflower"), 1),
            Map.entry(ResourceLocation.withDefaultNamespace("closed_eyeblossom"), 3),
            Map.entry(ResourceLocation.withDefaultNamespace("open_eyeblossom"), 3)
    );
    /** Poids par defaut pour toute fleur non listee ci-dessus (mods, ou vanilla oubliee) : rarete moyenne. */
    private static final int DEFAULT_MOD_FLOWER_WEIGHT = 15;
    private static final int DEFAULT_MOD_MUSHROOM_WEIGHT = 20;

    private static List<WeightedBlock> flowerPool() {
        if (FLOWER_POOL == null) FLOWER_POOL = scanFlowers();
        return FLOWER_POOL;
    }

    private static List<WeightedBlock> mushroomPool() {
        if (MUSHROOM_POOL == null) MUSHROOM_POOL = scanMushrooms();
        return MUSHROOM_POOL;
    }

    private static List<WeightedBlock> scanFlowers() {
        List<WeightedBlock> out = new ArrayList<>();
        for (Block block : net.minecraft.core.registries.BuiltInRegistries.BLOCK) {
            BlockState def = block.defaultBlockState();
            // #flowers couvre small + tall + torchflower/wither_rose/eyeblossoms,
            // et est automatiquement etendu par tout mod qui y ajoute ses blocs.
            if (!def.is(net.minecraft.tags.BlockTags.FLOWERS)) continue;
            if (!def.getFluidState().isEmpty()) continue; // garde-fou "jamais d'eau"
            // On ecarte les variantes "haute" (2 blocs, DoublePlantBlock) pour
            // rester coherent avec le reste de naturalize() qui ne pose QUE
            // des plantes 1-bloc sur l'herbe (sunflower/lilac/rose_bush/peony
            // necessiteraient une gestion HALF dediee, hors scope de ce fix).
            if (def.getBlock() instanceof net.minecraft.world.level.block.DoublePlantBlock) continue;
            ResourceLocation id = net.minecraft.core.registries.BuiltInRegistries.BLOCK.getKey(block);
            if (id == null) continue;
            // FIX (demande utilisateur) : spore_blossom fait partie du tag vanilla
            // #minecraft:flowers (depuis 1.20.2) mais n'est PAS une plante de sol -
            // c'est le seul membre du tag qui doit obligatoirement etre accroche
            // SOUS un bloc plafond (comme une stalactite vegetale). Pose au sol
            // (aucun plafond au-dessus dans naturalize()), il est visuellement/
            // logiquement invalide et genere en plus des particules constantes
            // (spores) non voulues pour du simple decor au sol. Exclu explicitement.
            if (id.equals(ResourceLocation.withDefaultNamespace("spore_blossom"))) continue;
            int weight = VANILLA_FLOWER_WEIGHTS.getOrDefault(id,
                    id.getNamespace().equals("minecraft") ? 10 : DEFAULT_MOD_FLOWER_WEIGHT);
            out.add(new WeightedBlock(block, weight));
        }
        if (out.isEmpty()) out.add(new WeightedBlock(Blocks.DANDELION, 1)); // filet de securite
        return out;
    }

    private static List<WeightedBlock> scanMushrooms() {
        List<WeightedBlock> out = new ArrayList<>();
        for (Block block : net.minecraft.core.registries.BuiltInRegistries.BLOCK) {
            BlockState def = block.defaultBlockState();
            if (!(block instanceof net.minecraft.world.level.block.MushroomBlock)) continue;
            if (!def.getFluidState().isEmpty()) continue; // garde-fou "jamais d'eau"
            ResourceLocation id = net.minecraft.core.registries.BuiltInRegistries.BLOCK.getKey(block);
            if (id == null) continue;
            int weight = id.getNamespace().equals("minecraft") ? 50 : DEFAULT_MOD_MUSHROOM_WEIGHT;
            out.add(new WeightedBlock(block, weight));
        }
        if (out.isEmpty()) out.add(new WeightedBlock(Blocks.BROWN_MUSHROOM, 1)); // filet de securite
        return out;
    }

    private static Block pickWeighted(List<WeightedBlock> pool, RandomSource random) {
        if (pool.isEmpty()) return null;
        int total = 0;
        for (WeightedBlock wb : pool) total += Math.max(1, wb.weight());
        if (total <= 0) return pool.get(0).block();
        int roll = random.nextInt(total);
        int acc = 0;
        for (WeightedBlock wb : pool) {
            acc += Math.max(1, wb.weight());
            if (roll < acc) return wb.block();
        }
        return pool.get(pool.size() - 1).block();
    }

    /**
     * Place un "champignon pousse" (huge mushroom simplifie : dome de blocs
     * champignon + stem central) sans dependre du systeme de feature de
     * worldgen complet (qui exige un WorldGenLevel/ChunkGenerator non
     * disponibles ici) -- reproduit une silhouette geante compacte et
     * toujours valide, quel que soit le champignon (vanilla ou mod).
     */
    private static void placeGrownMushroom(ServerLevel level, BlockPos.MutableBlockPos mut, int x, int y, int z, Block smallMushroom, RandomSource random) {
        Block cap = smallMushroom == Blocks.RED_MUSHROOM ? Blocks.RED_MUSHROOM_BLOCK
                : smallMushroom == Blocks.BROWN_MUSHROOM ? Blocks.BROWN_MUSHROOM_BLOCK
                : null;
        if (cap == null) {
            // Champignon d'un autre mod sans equivalent "geant" connu : on se
            // contente du petit champignon (comportement sur, jamais d'echec).
            level.setBlock(mut.set(x, y, z), smallMushroom.defaultBlockState(), 2);
            return;
        }
        int height = 4 + random.nextInt(3); // 4-6 blocs de tige
        for (int dy = 0; dy < height; dy++) {
            level.setBlock(mut.set(x, y + dy, z), Blocks.MUSHROOM_STEM.defaultBlockState(), 2);
        }
        int topY = y + height;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                BlockState above = level.getBlockState(mut.set(x + dx, topY, z + dz));
                if (!above.isAir()) continue;
                level.setBlock(mut, cap.defaultBlockState(), 2);
            }
        }
    }

    // =========================================================================
    // HELPERS : types de blocs
    // =========================================================================

    private static final Set<Block> FALLBACK_LOG_BLOCKS = new HashSet<>();
    private static final Set<Block> FALLBACK_LEAF_BLOCKS = new HashSet<>();
    private static boolean FALLBACK_BLOCKS_READY = false;

    /** Initialise une seule fois les blocs moddes mal tagues. */
    private static void initFallbackTreeBlocks() {
        if (FALLBACK_BLOCKS_READY) return;
        for (Block block : net.minecraft.core.registries.BuiltInRegistries.BLOCK) {
            ResourceLocation id = net.minecraft.core.registries.BuiltInRegistries.BLOCK.getKey(block);
            if (id == null) continue;
            String path = id.getPath().toLowerCase(Locale.ROOT);
            if (path.equals("log") || path.equals("wood") || path.endsWith("_log")
                    || path.endsWith("_wood") || path.endsWith("_stem") || path.endsWith("_hyphae")) {
                FALLBACK_LOG_BLOCKS.add(block);
            }
            if (path.equals("leaves") || path.equals("leaf") || path.endsWith("_leaves")
                    || path.endsWith("_leaf")) {
                FALLBACK_LEAF_BLOCKS.add(block);
            }
        }
        FALLBACK_BLOCKS_READY = true;
    }

    private static boolean isLog(BlockState s) {
        if (s.is(net.minecraft.tags.BlockTags.LOGS)) return true;
        initFallbackTreeBlocks();
        return FALLBACK_LOG_BLOCKS.contains(s.getBlock());
    }

    private static boolean isLeaf(BlockState s) {
        if (s.is(net.minecraft.tags.BlockTags.LEAVES)) return true;
        initFallbackTreeBlocks();
        return FALLBACK_LEAF_BLOCKS.contains(s.getBlock());
    }

    // Decors de surface (potentiellement volants apres le smooth) : feuilles,
    // neige, herbe, fougeres, vignes, etc.
    // FIX (rapporte en jeu : "je vois des grass qui volent parfois, des
    // petites grass et des grandes, quelques fleurs -- je parle pas de grass
    // block, mais bien de l'herbe la plante") : isDecoration() -- utilisee
    // par cleanupZone()/isFloatingFoliage() pour repartir la vegetation
    // laissee en l'air par le smooth -- listait Blocks.TALL_GRASS (l'ancien
    // nom 1.20.x du double-bloc "grande herbe") mais PAS
    // Blocks.SHORT_GRASS (le nom 1.20.3+ de la PETITE touffe d'herbe posee
    // par naturalize(), voir commentaire "grassH==0" plus haut), ni AUCUNE
    // fleur (Blocks.DANDELION, POPPY, etc., posees via flowerPool()/
    // BlockTags.FLOWERS), ni les champignons (mushroomPool()) : ces types de
    // blocs precis pouvaient donc flotter indefiniment apres un smooth qui
    // retire le support sous eux, jamais nettoyes -- exactement les 3
    // symptomes rapportes (petite herbe, grande herbe, fleurs qui flottent).
    // Detection desormais generique via les TAGS vanilla (couvre aussi les
    // ajouts de mods) plutot qu'une liste figee de blocs.
    private static boolean isDecoration(BlockState s) {
        return isLeaf(s) || s.is(Blocks.SNOW) || s.is(Blocks.GRASS_BLOCK)
            || s.is(Blocks.SHORT_GRASS) || s.is(Blocks.TALL_GRASS)
            || s.is(Blocks.FERN) || s.is(Blocks.LARGE_FERN) || s.is(Blocks.DEAD_BUSH)
            || s.is(Blocks.VINE) || s.is(Blocks.SEAGRASS) || s.is(Blocks.TALL_SEAGRASS)
            || s.is(net.minecraft.tags.BlockTags.FLOWERS)
            || s.getBlock() instanceof net.minecraft.world.level.block.MushroomBlock
            || s.getBlock() instanceof net.minecraft.world.level.block.BushBlock;
    }

    // Decors de surface a retirer AVANT le smooth. BushBlock couvre herbe, fleurs,
    // fougeres, pousses, etc. On ajoute feuilles, neige, vignes, ET les logs
    // (troncs d'arbres) sinon il reste des piliers de wood.
    private static boolean isSurfaceDecor(BlockState s) {
        return s.getBlock() instanceof net.minecraft.world.level.block.BushBlock
            || isLog(s) || isLeaf(s) || s.is(Blocks.SNOW) || s.is(Blocks.VINE)
            || s.is(Blocks.SEAGRASS) || s.is(Blocks.TALL_SEAGRASS)
            || s.is(Blocks.SUGAR_CANE) || s.is(Blocks.BAMBOO) || s.is(Blocks.CACTUS)
            || s.is(Blocks.SWEET_BERRY_BUSH) || s.is(Blocks.LILY_PAD);
    }

    private static String treeTypeOf(BlockState logState) {
        Block b = logState.getBlock();
        if (b == Blocks.OAK_LOG) return "oak";
        if (b == Blocks.BIRCH_LOG) return "birch";
        if (b == Blocks.SPRUCE_LOG) return "spruce";
        if (b == Blocks.JUNGLE_LOG) return "jungle";
        if (b == Blocks.ACACIA_LOG) return "acacia";
        if (b == Blocks.DARK_OAK_LOG) return "dark_oak";
        if (b == Blocks.MANGROVE_LOG) return "mangrove";
        if (b == Blocks.CHERRY_LOG) return "cherry";
        var key = net.minecraft.core.registries.BuiltInRegistries.BLOCK.getKey(b);
        // Pour un arbre modde, conserver l'ID exact du tronc. Il servira a
        // retrouver automatiquement le sapling de la meme famille.
        return key != null ? key.toString() : "unknown";
    }
}
