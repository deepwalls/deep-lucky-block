package deepluckyblock.procedures;

import deepluckyblock.advancements.DeepLuckyBlockAdvancements;

import com.mojang.logging.LogUtils;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Vec3i;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplateManager;
import net.minecraft.world.level.levelgen.structure.templatesystem.BlockIgnoreProcessor;
import net.minecraft.world.phys.AABB;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.Mod;
import org.slf4j.Logger;

import java.lang.reflect.Field;
import java.util.*;

import net.neoforged.fml.common.EventBusSubscriber;

@EventBusSubscriber(modid = "deep_lucky_block")
public class Structures5Procedure {

    private static final Logger LOGGER = LogUtils.getLogger();
    private static final int FAST_FLAG = 2 | 16 | 64;
    // Distance minimum absolue (en blocs) entre le build et le joueur. Aucune
    // structure ne spawn plus pres, quelle que soit sa taille. Modifiable ici en
    // haut pour eviter les problemes de terrain (build qui ecrase le joueur ou qui
    // modifie le terrain sous ses pieds).
    public static int MIN_PLAYER_DISTANCE = 65;
    private static final int BLOCKS_PER_TICK = 25000;
    private static final int FLAT_SIZE = 10;
    private static final int MAX_HDIFF = 3;
    // Filet de securite : le sol a ete detecte PLAT par findFlat() AVANT le
    // smooth, donc la re-mesure APRES smooth ne devrait quasiment jamais bouger.
    // Si malgre l'ancrage de smoothPass() un ecart anormal subsiste (bug futur,
    // cas limite non prevu, chunk pas encore genere, etc.), on borne le
    // deltaY applique au paste pour ne JAMAIS reproduire le bug "montagne
    // inutile / structure a +300". Le lissage de la couronne autour n'est PAS
    // touche par cette limite : seul le repositionnement du paste l'est.
    private static final int MAX_POST_SMOOTH_DELTA_Y = 4;
    private static final int SEARCH_R = 80;
    // FIX (freeze silencieux au paste, voir Javadoc dans findFlat) : budget de
    // temps maximum pour la verification "chunks reels" des candidats de zone
    // plate. Au-dela, on arrete d'essayer de nouveaux candidats et on retombe
    // sur le meilleur deja verifie / le fallback pente minimale.
    private static final long FIND_FLAT_TIME_BUDGET_MS = 3000;
    private static final int SEARCH_S = 5;
    private static final double VIEW_CONE = Math.PI / 2.0;
    private static final int SAFETY_CHECK_RADIUS = 6;
    private static final int SAFETY_CHECK_DEPTH = 2;
    private static final double WATER_MAX_RATIO = 0.15;
    private static final double LAVA_MAX_RATIO = 0.05;
    private static final int MAX_CLIFF_HEIGHT_DIFF = 10;
    private static final int ALT_SEARCH_RADIUS = 60;
    private static final int ALT_SEARCH_STEP = 10;
    private static final int CARVE_COLS_PER_TICK = 600;
    private static final int CARVE_CANOPY = 8;
    private static final int RING_PER_TICK = 6000;
    private static final int GROUND_MAX_DEPTH = 64;
    private static final int GROUND_COLS_PER_TICK = 200;

    // ==================== EVEREST POST-PROCESSING ====================
    // 1) Ne garder que quelques coffres dans l'Everest (structure de Laink) :
    //    les coffres inclus dans la structure sont retires, sauf un nombre
    //    ALÉATOIRE entre EVEREST_CHEST_MIN et EVEREST_CHEST_MAX, tiré parmi
    //    TOUS les coffres (jamais les "plus riches").
    private static final int EVEREST_CHEST_MIN = 2;
    private static final int EVEREST_CHEST_MAX = 3;
    private static final int EVEREST_CHEST_KEEP = EVEREST_CHEST_MAX; // max conserve (compat)
    // 2) Spawn de mobs sur la SURFACE de la montagne (pas dedans, elle est creuse).
    private static final int EVEREST_MOB_MIN = 10;
    private static final int EVEREST_MOB_MAX = 20;
    // Bande (en blocs) au sommet de laquelle on ne spawn JAMAIS : les PNJ y vivent.
    private static final int EVEREST_TOP_MARGIN = 8;
    // Pas d'echantillonnage de la surface (perf sur une grosse structure).
    private static final int EVEREST_SURFACE_STEP = 4;
    private static final EntityType<?>[] EVEREST_MOB_TYPES = {
        EntityType.ZOMBIE, EntityType.SKELETON, EntityType.SPIDER,
        EntityType.CREEPER, EntityType.HUSK, EntityType.STRAY
    };

    // Taille de l'anneau de terrain par structure.
    // 100 = taille normale, 40 = anneau reduit de 60 %, 120 = +20 %.
    public static int CITADEL_RING_SCALE_PERCENT = 100;
    public static int OBSERVATORY_RING_SCALE_PERCENT = 100;
    public static int DRAGON_RING_SCALE_PERCENT = 100;
    public static int CIRCUS_RING_SCALE_PERCENT = 100;
    public static int SHIP_RING_SCALE_PERCENT = 100;
    public static int EVEREST_RING_SCALE_PERCENT = 100;

    private static int ringScaleFor(String nbt) {
        return switch (nbt.toLowerCase(Locale.ROOT)) {
            case "citadel" -> CITADEL_RING_SCALE_PERCENT;
            case "observatory" -> OBSERVATORY_RING_SCALE_PERCENT;
            case "dragon" -> DRAGON_RING_SCALE_PERCENT;
            case "circus" -> CIRCUS_RING_SCALE_PERCENT;
            case "shipdead" -> SHIP_RING_SCALE_PERCENT;
            case "everest" -> EVEREST_RING_SCALE_PERCENT;
            default -> 100;
        };
    }
    // Tolerance : on ne rebouche (motte) QUE les colonnes dont lo est pres du
    // niveau de base reel (median des lo). Les colonnes de toit/auvent (lo tres
    // haut) sont IGNOREES, sinon on cree des piliers de dirt qui pendant des
    // bords du toit. Rien n'est jamais place au-dessus du dernier bloc structure.
    private static final int FLOOR_TOLERANCE = 4;
    private static final String CITADEL_NBT = "citadel";
    public static int CITADEL_OFFSET_X = 20;
    public static int CITADEL_OFFSET_Y = -35;
    public static int CITADEL_OFFSET_Z = 20;
    public static int CITADEL_DISTANCE = 0;
    public static Direction CITADEL_FACING = Direction.SOUTH;
    public static boolean CITADEL_FOLLOW_SURFACE = true;
    public static boolean CITADEL_USE_FLAT = true;
    public static boolean CITADEL_KEEP_INT = true;
    private static final String OBS_NBT = "observatory";
    public static int OBS_OFFSET_X = 0;
    public static int OBS_OFFSET_Y = -5;
    public static int OBS_OFFSET_Z = 0;
    public static int OBS_DISTANCE = 0;
    public static Direction OBS_FACING = Direction.NORTH;
    public static boolean OBS_FOLLOW_SURFACE = true;
    public static boolean OBS_USE_FLAT = true;
    public static boolean OBS_KEEP_INT = true;
    private static final String DRAGON_NBT = "dragon";
    public static int DRAGON_OFFSET_X = 10;
    public static int DRAGON_OFFSET_Y = -34;
    public static int DRAGON_OFFSET_Z = 10;
    public static int DRAGON_DISTANCE = 0;
    public static Direction DRAGON_FACING = Direction.WEST;
    public static boolean DRAGON_FOLLOW_SURFACE = true;
    public static boolean DRAGON_USE_FLAT = true;
    public static boolean DRAGON_KEEP_INT = true;
    private static final int MIN_CHUNKS_NORMAL = 4;
    private static final int MIN_CHUNKS_EVEREST = 6;

    private static long colKey(int x, int z) { return (Integer.toUnsignedLong(x) << 32) | Integer.toUnsignedLong(z); }
    private static int keyX(long k) { return (int) (k >>> 32); }
    private static int keyZ(long k) { return (int) k; }

    // Verre standard sans couleur uniquement (les command blocks sont deja filtres par isLaggy/isLaggyBlock).
    /** Supprime uniquement les blocs techniques LIGHT et les vignes vanilla
     * situes aux couches 1, 0 et negatives de la structure. Les LIGHT au-dessus
     * et les vrais blocs lumineux sont conserves. */
    private static boolean isTechnicalLightOrVine(BlockState state) {
        ResourceLocation id = net.minecraft.core.registries.BuiltInRegistries.BLOCK.getKey(state.getBlock());
        if (id == null) return false;
        String path = id.getPath().toLowerCase(Locale.ROOT);
        return path.equals("light") || id.toString().equalsIgnoreCase("minecraft:vine");
    }

    private static boolean isUndergroundTechnicalBlock(BlockState state, int relativeY) {
        if (relativeY > 1) return false;
        ResourceLocation id = net.minecraft.core.registries.BuiltInRegistries.BLOCK.getKey(state.getBlock());
        if (id == null) return false;
        String fullId = id.toString().toLowerCase(Locale.ROOT);
        String path = id.getPath().toLowerCase(Locale.ROOT);
        return path.equals("light") || fullId.equals("minecraft:vine");
    }

    private static boolean isGlassBlock(BlockState s) {
        return s.is(Blocks.GLASS);
    }

    private static boolean isEverestNbt(String nbt) { return "everest".equalsIgnoreCase(nbt); }

    private static boolean isChunkAreaLoaded(ServerLevel level, BlockPos center, int minChunks, Player nearest) {
        int cx = center.getX() >> 4, cz = center.getZ() >> 4, loaded = 0;
        int radius = (int) Math.ceil(Math.sqrt(minChunks));
        for (int dx = -radius; dx <= radius; dx++)
            for (int dz = -radius; dz <= radius; dz++)
                if (level.getChunkSource().getChunk(cx + dx, cz + dz, net.minecraft.world.level.chunk.status.ChunkStatus.FULL, false) != null) loaded++;
        return loaded >= minChunks;
    }

    private static BlockPos findFarthestLoadedPos(ServerLevel level, BlockPos origin, int dist, int minChunksReq) {
        Player pl = level.getNearestPlayer(origin.getX() + .5, origin.getY() + .5, origin.getZ() + .5, 128, false);
        RandomSource r = level.getRandom();
        BlockPos best = null;
        int bestDistSq = -1, attempts = 0;
        while (attempts < 60) {
            double a = r.nextDouble() * Math.PI * 2;
            int dx = (int) Math.round(Math.cos(a) * dist), dz = (int) Math.round(Math.sin(a) * dist);
            int cx = origin.getX() + dx, cz = origin.getZ() + dz;
            int cy = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, cx, cz) - 1;
            BlockPos candidate = new BlockPos(cx, cy, cz);
            if (isChunkAreaLoaded(level, candidate, minChunksReq, pl)) {
                int dSq = dx * dx + dz * dz;
                if (dSq > bestDistSq) { bestDistSq = dSq; best = candidate; }
            }
            attempts++;
        }
        return best;
    }

    private static boolean isLaggy(BlockState s) {
        return s.is(Blocks.WHITE_CARPET) || s.is(Blocks.ORANGE_CARPET) || s.is(Blocks.MAGENTA_CARPET)
            || s.is(Blocks.LIGHT_BLUE_CARPET) || s.is(Blocks.YELLOW_CARPET) || s.is(Blocks.LIME_CARPET)
            || s.is(Blocks.PINK_CARPET) || s.is(Blocks.GRAY_CARPET) || s.is(Blocks.LIGHT_GRAY_CARPET)
            || s.is(Blocks.CYAN_CARPET) || s.is(Blocks.PURPLE_CARPET) || s.is(Blocks.BLUE_CARPET)
            || s.is(Blocks.BROWN_CARPET) || s.is(Blocks.GREEN_CARPET) || s.is(Blocks.RED_CARPET)
            || s.is(Blocks.BLACK_CARPET) || s.is(Blocks.MOSS_CARPET)
            || s.is(Blocks.TRIPWIRE) || s.is(Blocks.COMMAND_BLOCK)
            || s.is(Blocks.REPEATING_COMMAND_BLOCK) || s.is(Blocks.CHAIN_COMMAND_BLOCK);
    }

    private static boolean isTreePart(BlockState s) { return s.is(BlockTags.LOGS) || s.is(BlockTags.LEAVES); }
    private static boolean isNaturalTerrain(BlockState s) {
        if (isTreePart(s)) return true;
        return s.is(Blocks.DIRT) || s.is(Blocks.GRASS_BLOCK) || s.is(Blocks.STONE)
            || s.is(Blocks.SAND) || s.is(Blocks.RED_SAND) || s.is(Blocks.GRAVEL) || s.is(Blocks.COARSE_DIRT)
            || s.is(Blocks.PODZOL) || s.is(Blocks.MYCELIUM) || s.is(Blocks.SANDSTONE) || s.is(Blocks.RED_SANDSTONE)
            || s.is(Blocks.GRANITE) || s.is(Blocks.DIORITE) || s.is(Blocks.ANDESITE)
            || s.is(Blocks.DEEPSLATE) || s.is(Blocks.TUFF) || s.is(Blocks.CALCITE)
            || s.is(Blocks.CLAY) || s.is(Blocks.MOSS_BLOCK) || s.is(Blocks.MUD)
            || s.is(Blocks.SNOW_BLOCK) || s.is(Blocks.ICE) || s.is(Blocks.PACKED_ICE) || s.is(Blocks.BLUE_ICE)
            || s.is(Blocks.GRASS_BLOCK) || s.is(Blocks.TALL_GRASS) || s.is(Blocks.FERN) || s.is(Blocks.LARGE_FERN)
            || s.is(Blocks.DEAD_BUSH) || s.is(Blocks.VINE)
            || s.is(Blocks.COAL_ORE) || s.is(Blocks.IRON_ORE) || s.is(Blocks.COPPER_ORE) || s.is(Blocks.GOLD_ORE)
            || s.is(Blocks.REDSTONE_ORE) || s.is(Blocks.LAPIS_ORE) || s.is(Blocks.DIAMOND_ORE) || s.is(Blocks.EMERALD_ORE)
            || s.is(Blocks.DEEPSLATE_COAL_ORE) || s.is(Blocks.DEEPSLATE_IRON_ORE) || s.is(Blocks.DEEPSLATE_COPPER_ORE)
            || s.is(Blocks.DEEPSLATE_GOLD_ORE) || s.is(Blocks.DEEPSLATE_REDSTONE_ORE) || s.is(Blocks.DEEPSLATE_LAPIS_ORE)
            || s.is(Blocks.DEEPSLATE_DIAMOND_ORE) || s.is(Blocks.DEEPSLATE_EMERALD_ORE)
            || s.is(Blocks.NETHER_QUARTZ_ORE) || s.is(Blocks.NETHER_GOLD_ORE);
    }

    private static void killLaggyItems(ServerLevel lvl, BlockPos min, BlockPos max) {
        AABB box = new AABB(min.getX() - 2, min.getY() - 2, min.getZ() - 2, max.getX() + 2, max.getY() + 2, max.getZ() + 2);
        int k = 0;
        for (ItemEntity ie : lvl.getEntitiesOfClass(ItemEntity.class, box)) {
            ItemStack s = ie.getItem();
            if (s.is(Items.STRING) || s.is(Items.SNOW) || s.is(Items.SNOWBALL) || s.is(Items.DIRT)
                || s.is(Items.SAND) || s.is(Items.RED_SAND) || s.is(Items.GRAVEL) || s.is(Items.COARSE_DIRT)
                || s.getItem().getDescriptionId().contains("carpet")) { ie.discard(); k++; }
        }
        if (k > 0) LOGGER.info("[STRUCT5] {} items laggy nettoyes", k);
    }

    private static class ZoneAnalysis {
        double waterRatio, lavaRatio; int heightDiff;
        boolean hasTooMuchWater() { return waterRatio > WATER_MAX_RATIO; }
        boolean hasTooMuchLava() { return lavaRatio > LAVA_MAX_RATIO; }
        boolean hasCliff() { return heightDiff > MAX_CLIFF_HEIGHT_DIFF; }
        boolean isUnsafe() { return hasTooMuchWater() || hasTooMuchLava() || hasCliff(); }
        String getReason() {
            List<String> r = new ArrayList<>();
            if (hasTooMuchWater()) r.add("eau=" + (int)(waterRatio * 100) + "%");
            if (hasTooMuchLava()) r.add("lave=" + (int)(lavaRatio * 100) + "%");
            if (hasCliff()) r.add("falaise=" + heightDiff);
            return String.join(", ", r);
        }
    }

    private static ZoneAnalysis analyzeZone(ServerLevel level, BlockPos center) {
        ZoneAnalysis result = new ZoneAnalysis();
        BlockPos.MutableBlockPos check = new BlockPos.MutableBlockPos();
        int waterCount = 0, lavaCount = 0, totalFluid = 0, minY = Integer.MAX_VALUE, maxY = Integer.MIN_VALUE;
        for (int dx = -SAFETY_CHECK_RADIUS; dx <= SAFETY_CHECK_RADIUS; dx += 3) {
            for (int dz = -SAFETY_CHECK_RADIUS; dz <= SAFETY_CHECK_RADIUS; dz += 3) {
                int px = center.getX() + dx, pz = center.getZ() + dz;
                int surfY = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, px, pz) - 1;
                if (surfY < minY) minY = surfY;
                if (surfY > maxY) maxY = surfY;
                for (int dy = 0; dy >= -SAFETY_CHECK_DEPTH; dy--) {
                    check.set(px, surfY + dy, pz);
                    BlockState state = level.getBlockState(check);
                    totalFluid++;
                    if (state.is(Blocks.WATER) || (!state.getFluidState().isEmpty() && state.getFluidState().is(FluidTags.WATER))) waterCount++;
                    else if (state.is(Blocks.LAVA) || (!state.getFluidState().isEmpty() && state.getFluidState().is(FluidTags.LAVA))) lavaCount++;
                }
            }
        }
        result.waterRatio = (double) waterCount / totalFluid;
        result.lavaRatio = (double) lavaCount / totalFluid;
        result.heightDiff = maxY - minY;
        return result;
    }

    private static BlockPos findSafeAlternative(ServerLevel level, BlockPos origin) {
        long t0 = System.currentTimeMillis();
        BlockPos bestWaterOnly = null;
        for (int radius = ALT_SEARCH_STEP; radius <= ALT_SEARCH_RADIUS; radius += ALT_SEARCH_STEP) {
            for (int dx = -radius; dx <= radius; dx += ALT_SEARCH_STEP) {
                for (int dz = -radius; dz <= radius; dz += ALT_SEARCH_STEP) {
                    if (Math.abs(dx) != radius && Math.abs(dz) != radius) continue;
                    int cx = origin.getX() + dx, cz = origin.getZ() + dz;
                    int cy = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, cx, cz) - 1;
                    BlockPos candidate = new BlockPos(cx, cy, cz);
                    ZoneAnalysis a = analyzeZone(level, candidate);
                    if (!a.isUnsafe()) {
                        LOGGER.info("[STRUCT5-SAFETY] Zone sure a {} (r={}, {}ms)", candidate.toShortString(), radius, System.currentTimeMillis() - t0);
                        return candidate;
                    }
                    if (bestWaterOnly == null && !a.hasTooMuchLava() && !a.hasCliff()) bestWaterOnly = candidate;
                }
            }
        }
        return bestWaterOnly;
    }

    private static int findFluidSurfaceY(ServerLevel level, int x, int z) {
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        int surfaceY = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
        for (int y = surfaceY + 2; y > level.getMinBuildHeight(); y--) {
            p.set(x, y, z);
            if (!level.getBlockState(p).getFluidState().isEmpty()) return y + 1;
        }
        return surfaceY;
    }

    private static BlockPos resolveSafePosition(ServerLevel level, BlockPos targetXZ, String nbtName) {
        int surfaceY = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, targetXZ.getX(), targetXZ.getZ()) - 1;
        BlockPos surfPos = new BlockPos(targetXZ.getX(), surfaceY, targetXZ.getZ());
        ZoneAnalysis analysis = analyzeZone(level, surfPos);
        if (!analysis.isUnsafe()) return targetXZ;
        LOGGER.warn("[STRUCT5-SAFETY] {} : {} -> recherche alt...", nbtName, analysis.getReason());
        BlockPos safeAlt = findSafeAlternative(level, surfPos);
        if (safeAlt != null && !analyzeZone(level, safeAlt).hasTooMuchLava()) return safeAlt;
        if (analysis.hasTooMuchLava()) return null;
        if (analysis.hasTooMuchWater() && !analysis.hasCliff())
            return new BlockPos(targetXZ.getX(), findFluidSurfaceY(level, targetXZ.getX(), targetXZ.getZ()), targetXZ.getZ());
        return targetXZ;
    }

    private static final Queue<PasteJob> PASTE_Q = new ArrayDeque<>();
    private static final Queue<CarveJob> CARVE_Q = new ArrayDeque<>();
    private static final Queue<PostJob> POST_Q = new ArrayDeque<>();

    private static class PasteJob {
        final ServerLevel level; final List<StructureTemplate.StructureBlockInfo> blocks;
        final BlockPos origin; final Rotation rot; final Mirror mir;
        final String name; final long t0; final Player player;
        final BlockPos min, max; int idx;
        final List<BlockPos> chests;   // positions des coffres poses (Everest)
        PasteJob(ServerLevel l, List<StructureTemplate.StructureBlockInfo> b, BlockPos o, Rotation r, Mirror m, String n, long t, Player p, BlockPos mn, BlockPos mx) {
            level = l; blocks = b; origin = o; rot = r; mir = m; name = n; t0 = t; player = p; min = mn; max = mx; idx = 0; chests = new ArrayList<>();
        }
    }

    private static class CarveJob {
        final ServerLevel level;
        final List<int[]> columns;  // colonnes occupees : { x, z, loY, hiY }
        final List<Long> occList;   // positions occupees (marge +1)
        final Set<Long> occupied;
        final Set<Long> baseCols;   // empreinte pour la motte
        final BlockPos min, max;
        final String name;
        final int bottomY;          // y le plus bas (global)
        final int baseLevel;        // median des lo = niveau de sol reel (anti toit/auvent)
        int idx, ringIdx, groundIdx;
        boolean groundDone;
        int carved, grounded;
        CarveJob(ServerLevel l, List<int[]> cols, List<Long> occ, Set<Long> occSet, Set<Long> base, BlockPos mn, BlockPos mx, String n, int by, int bl) {
            level = l; columns = cols; occList = occ; occupied = occSet; baseCols = base; min = mn; max = mx; name = n; bottomY = by; baseLevel = bl;
            idx = 0; ringIdx = occ.size(); groundIdx = 0; groundDone = false; carved = 0; grounded = 0;
        }
    }

    private static class PostJob {
        final ServerLevel level; final BlockPos min, max; final String name; int y;
        PostJob(ServerLevel l, BlockPos mn, BlockPos mx, String n) { level = l; min = mn; max = mx; name = n; y = mn.getY(); }
    }

    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post e) {
        if (!PASTE_Q.isEmpty()) {
            PasteJob j = PASTE_Q.peek();
            int end = Math.min(j.idx + BLOCKS_PER_TICK, j.blocks.size());
            StructurePlaceSettings rs = new StructurePlaceSettings().setRotation(j.rot).setMirror(j.mir);
            BlockPos.MutableBlockPos bp = new BlockPos.MutableBlockPos();
            for (int i = j.idx; i < end; i++) {
                StructureTemplate.StructureBlockInfo info = j.blocks.get(i);
                BlockState ts = info.state().mirror(j.mir).rotate(j.rot);
                if (isLaggy(ts)) continue;
                BlockPos rel = StructureTemplate.calculateRelativePosition(rs, info.pos());
                bp.set(j.origin.getX() + rel.getX(), j.origin.getY() + rel.getY(), j.origin.getZ() + rel.getZ());
                j.level.getChunkSource().getChunk(bp.getX() >> 4, bp.getZ() >> 4, true);
                j.level.setBlock(bp, ts, FAST_FLAG);
                if (info.nbt() != null) {
                    var be = j.level.getBlockEntity(bp);
                    if (be != null) { CompoundTag tag = info.nbt().copy(); tag.putInt("x", bp.getX()); tag.putInt("y", bp.getY()); tag.putInt("z", bp.getZ()); be.loadWithComponents(tag, j.level.registryAccess()); }
                }

                // Les coffres vanilla vides deviennent des coffres automatiques.
                // Les coffres ayant deja nos donnees NBT sont preserves.
                if (isEverestNbt(j.name) && ts.getBlock() instanceof net.minecraft.world.level.block.ChestBlock) {
                    j.chests.add(bp.immutable());
                }
                prepareAutomaticChest(j.level, bp, ts, info.nbt(), info.pos().getY(), j.blocks);
            }
            j.idx = end;
            if (j.idx >= j.blocks.size()) {
                PASTE_Q.poll();
                long el = System.currentTimeMillis() - j.t0;
                int technicalRemoved = removeUndergroundTechnicalBlocks(j.level, j.min, j.max);
                if (technicalRemoved > 0) {
                    LOGGER.info("[STRUCT5] {} LIGHT/vines techniques souterrains supprimes apres paste", technicalRemoved);
                }
                if (isEverestNbt(j.name)) {
                    cleanupEverestChests(j.level, j.chests);
                }
                LOGGER.info("[STRUCT5] {} en {}ms ({} blocs)", j.name, el, j.blocks.size());
                if (j.player != null) {
                    j.player.sendSystemMessage(Component.literal("\u00a7a\u2713 \u00a7e" + j.name + "\u00a7a en " + el + "ms"));
                    announceStructureSpawn(j.player, j.name, j.min, j.max);
                }
                CarveJob carve = buildCarveJob(j);
                CARVE_Q.offer(carve);
                LOGGER.info("[STRUCT5] carve {} programmee ({} colonnes, {} blocs occupes, bottomY={})", j.name, carve.columns.size(), carve.occupied.size(), carve.bottomY);
            }
        }
        if (!CARVE_Q.isEmpty()) {
            CarveJob cj = CARVE_Q.peek();
            BlockPos.MutableBlockPos mut = new BlockPos.MutableBlockPos();
            int minBuild = cj.level.getMinBuildHeight();
            if (cj.idx < cj.columns.size()) {
                int end = Math.min(cj.idx + CARVE_COLS_PER_TICK, cj.columns.size());
                for (int i = cj.idx; i < end; i++) {
                    int[] c = cj.columns.get(i);
                    int x = c[0], z = c[1], lo = c[2], hi = c[3];
                    for (int y = lo + 1; y <= hi; y++) {
                        if (cj.occupied.contains(BlockPos.asLong(x, y, z))) continue;
                        BlockState s = cj.level.getBlockState(mut.set(x, y, z));
                        if (!s.isAir() && isNaturalTerrain(s)) { cj.level.setBlock(mut, Blocks.AIR.defaultBlockState(), FAST_FLAG); cj.carved++; }
                    }
                    for (int y = hi + 1; y <= hi + CARVE_CANOPY; y++) {
                        if (cj.occupied.contains(BlockPos.asLong(x, y, z))) continue;
                        BlockState s = cj.level.getBlockState(mut.set(x, y, z));
                        if (!s.isAir() && isTreePart(s)) { cj.level.setBlock(mut, Blocks.AIR.defaultBlockState(), FAST_FLAG); cj.carved++; }
                    }
                }
                cj.idx = end;
            } else if (cj.ringIdx < cj.occList.size()) {
                int end = Math.min(cj.ringIdx + RING_PER_TICK, cj.occList.size());
                for (int i = cj.ringIdx; i < end; i++) {
                    long pos = cj.occList.get(i);
                    int px = BlockPos.getX(pos), py = BlockPos.getY(pos), pz = BlockPos.getZ(pos);
                    clearRing(cj, mut, px + 1, py, pz);
                    clearRing(cj, mut, px - 1, py, pz);
                    clearRing(cj, mut, px, py, pz + 1);
                    clearRing(cj, mut, px, py, pz - 1);
                }
                cj.ringIdx = end;
            } else if (!cj.groundDone) {
                // Par colonne : on rebouche UNIQUEMENT les colonnes de sol (lo pres
                // de baseLevel) ET uniquement les positions CACHEES. Une position
                // dont un voisin horizontal est exposed (air/non-solide) est sautee :
                // sinon on colle des blocs de dirt visibles sur les facades.
                int end = Math.min(cj.groundIdx + GROUND_COLS_PER_TICK, cj.columns.size());
                BlockPos.MutableBlockPos side = new BlockPos.MutableBlockPos();
                for (int i = cj.groundIdx; i < end; i++) {
                    int[] c = cj.columns.get(i);
                    int x = c[0], z = c[1], lo = c[2];
                    if (lo > cj.baseLevel + FLOOR_TOLERANCE) continue; // colonne de toit/auvent -> RIEN
                    BlockState below = cj.level.getBlockState(mut.set(x, lo - 1, z));
                    if (!below.isAir() && below.blocksMotion()) continue; // sol solide -> RIEN
                    int y = lo - 1;
                    int depth = 0;
                    while (y >= minBuild && depth < GROUND_MAX_DEPTH) {
                        BlockState cur = cj.level.getBlockState(mut.set(x, y, z));
                        if (!cur.isAir() && cur.blocksMotion()) break; // sol trouve -> stop
                        if (!isHorizontallyExposed(cj.level, side, x, y, z)) {
                            cj.level.setBlock(mut, Blocks.DIRT.defaultBlockState(), 2);
                            cj.grounded++;
                        }
                        y--; depth++;
                    }
                }
                cj.groundIdx = end;
                if (cj.groundIdx >= cj.columns.size()) cj.groundDone = true;
            }
            if (cj.idx >= cj.columns.size() && cj.ringIdx >= cj.occList.size() && cj.groundDone) {
                CARVE_Q.poll();
                LOGGER.info("[STRUCT5] {} termine : {} blocs supprimes, {} blocs de motte (bottomY={})", cj.name, cj.carved, cj.grounded, cj.bottomY);
                StructureTerrainPrep.decorate(cj.level, cj.min, cj.max);
                POST_Q.offer(new PostJob(cj.level, cj.min, cj.max, cj.name));
                LOGGER.info("[STRUCT5] decorate + post de {} termine", cj.name);
            }
        }
        if (!POST_Q.isEmpty()) {
            PostJob pj = POST_Q.peek();
            for (int s = 0; s < 4 && pj.y <= pj.max.getY(); s++) { postLayer(pj.level, pj.min, pj.max, pj.y); pj.y++; }
            if (pj.y > pj.max.getY()) {
                killLaggyItems(pj.level, pj.min, pj.max);
                if (isEverestNbt(pj.name)) {
                    spawnEverestMobs(pj.level, pj.min, pj.max);
                }
                POST_Q.poll();
                LOGGER.info("[STRUCT5] Post-process de {} termine", pj.name);
            }
        }
    }

    private static void clearRing(CarveJob cj, BlockPos.MutableBlockPos mut, int x, int y, int z) {
        if (cj.occupied.contains(BlockPos.asLong(x, y, z))) return;
        BlockState s = cj.level.getBlockState(mut.set(x, y, z));
        if (!s.isAir() && isNaturalTerrain(s)) { cj.level.setBlock(mut, Blocks.AIR.defaultBlockState(), FAST_FLAG); cj.carved++; }
    }

    // Une position est "exposed" si un voisin horizontal est air ou non-solide.
    // Sert a ne JAMAIS placer de dirt visible sur les facades exterieures.
    private static boolean isHorizontallyExposed(ServerLevel level, BlockPos.MutableBlockPos m, int x, int y, int z) {
        BlockState n = level.getBlockState(m.set(x + 1, y, z));
        if (n.isAir() || !n.blocksMotion()) return true;
        n = level.getBlockState(m.set(x - 1, y, z));
        if (n.isAir() || !n.blocksMotion()) return true;
        n = level.getBlockState(m.set(x, y, z + 1));
        if (n.isAir() || !n.blocksMotion()) return true;
        n = level.getBlockState(m.set(x, y, z - 1));
        if (n.isAir() || !n.blocksMotion()) return true;
        return false;
    }

    // bottomY = le DERNIER bloc reel de la structure (le y le plus bas, hors verre).
    // La motte se construit EN DESSOUS de ce bloc (a partir de bottomY-1).
    private static CarveJob buildCarveJob(PasteJob j) {
        StructurePlaceSettings rs = new StructurePlaceSettings().setRotation(j.rot).setMirror(j.mir);
        Set<Long> occupied = new HashSet<>(j.blocks.size());
        Map<Long, int[]> cols = new HashMap<>();
        for (StructureTemplate.StructureBlockInfo info : j.blocks) {
            BlockPos rel = StructureTemplate.calculateRelativePosition(rs, info.pos());
            int x = j.origin.getX() + rel.getX(), y = j.origin.getY() + rel.getY(), z = j.origin.getZ() + rel.getZ();
            occupied.add(BlockPos.asLong(x, y, z));
            long ck = colKey(x, z);
            int[] e = cols.get(ck);
            if (e == null) cols.put(ck, new int[]{x, z, y, y});
            else { if (y < e[2]) e[2] = y; if (y > e[3]) e[3] = y; }
        }
        Set<Long> baseCols = new HashSet<>(cols.size());
        int bottomY = Integer.MAX_VALUE;
        List<Integer> los = new ArrayList<>(cols.size());
        for (int[] col : cols.values()) { baseCols.add(colKey(col[0], col[1])); if (col[2] < bottomY) bottomY = col[2]; los.add(col[2]); }
        // baseLevel = mediane des lo. Robuste : les quelques fondations profondes
        // et les colonnes de toit (minoritaires) ne faussent pas la mediane.
        // On ne rebouchera que les colonnes dont lo est pres de ce niveau de sol.
        Collections.sort(los);
        int baseLevel = los.isEmpty() ? bottomY : los.get(los.size() / 2);
        return new CarveJob(j.level, new ArrayList<>(cols.values()), new ArrayList<>(occupied), occupied, baseCols, j.min, j.max, j.name, bottomY, baseLevel);
    }

    public static void generate(ServerLevel level, BlockPos origin, int id, RandomSource random) {
        if (level == null || origin == null) return;
        switch (id) {
            case 0, 16 -> doPaste(level, origin, CITADEL_NBT, CITADEL_OFFSET_X, CITADEL_OFFSET_Y, CITADEL_OFFSET_Z, CITADEL_DISTANCE, CITADEL_FACING, CITADEL_FOLLOW_SURFACE, CITADEL_USE_FLAT, CITADEL_KEEP_INT);
            case 1, 17 -> doPaste(level, origin, OBS_NBT, OBS_OFFSET_X, OBS_OFFSET_Y, OBS_OFFSET_Z, OBS_DISTANCE, OBS_FACING, OBS_FOLLOW_SURFACE, OBS_USE_FLAT, OBS_KEEP_INT);
            case 2, 18 -> doPaste(level, origin, DRAGON_NBT, DRAGON_OFFSET_X, DRAGON_OFFSET_Y, DRAGON_OFFSET_Z, DRAGON_DISTANCE, DRAGON_FACING, DRAGON_FOLLOW_SURFACE, DRAGON_USE_FLAT, DRAGON_KEEP_INT);
            default -> LOGGER.warn("[STRUCT5] ID inconnu : {}", id);
        }
    }

    public static void execute(ServerLevel level, Player player, int id) {
        if (level == null) return;
        BlockPos origin = player != null ? player.blockPosition() : new BlockPos(0, 64, 0);
        LOGGER.info("[STRUCT5] execute() ID={}, origin={}", id, origin.toShortString());
        // 🏆 Achievement "structure spawnée" : chaque structure a le sien + 2 blocs.
        grantStructureSpawnAchievement(level, origin, player, id);
        switch (id) {
            case 0, 1, 2, 16, 17, 18 -> generate(level, origin, id, level.getRandom());
            case 3 -> Structures4Procedure.spawnCircus(level, origin);
            case 4 -> Structures4Procedure.spawnShipdead(level, origin);
            case 5 -> Structures4Procedure.spawnEverest(level, origin);
            default -> LOGGER.warn("[STRUCT5] ID inconnu dans execute : {}", id);
        }
    }

    /** Mappe l'id de structure vers la cle d'achievement et accorde l'achievement + 2 blocs. */
    private static void grantStructureSpawnAchievement(ServerLevel level, BlockPos origin, Player player, int id) {
        String key = switch (id) {
            case 0, 16 -> "citadel";
            case 1, 17 -> "observatory";
            case 2, 18 -> "dragon";
            case 3 -> "circus";
            case 4 -> "ship";
            case 5 -> "everest";
            default -> null;
        };
        if (key == null) return;
        ServerPlayer target = player instanceof ServerPlayer sp ? sp : null;
        if (target == null) {
            Player near = level.getNearestPlayer(origin.getX() + 0.5, origin.getY() + 0.5, origin.getZ() + 0.5, 128.0, false);
            if (near instanceof ServerPlayer sp2) target = sp2;
        }
        if (target != null) {
            DeepLuckyBlockAdvancements.grantStructureSpawned(target, key);
        }
    }

    public static void buildSylvanCitadel(ServerLevel l, BlockPos o, RandomSource r) { generate(l, o, 0, r); }
    public static void buildFaeObservatory(ServerLevel l, BlockPos o, RandomSource r) { generate(l, o, 1, r); }
    public static void buildVerdantDragonSanctum(ServerLevel l, BlockPos o, RandomSource r) { generate(l, o, 2, r); }

    private static Rotation facePlayer(BlockPos sp, Player p, Direction nf) {
        if (p == null) return Rotation.NONE;
        double dx = p.getX() - sp.getX(), dz = p.getZ() - sp.getZ();
        Direction toP = Math.abs(dx) > Math.abs(dz) ? (dx > 0 ? Direction.EAST : Direction.WEST) : (dz > 0 ? Direction.SOUTH : Direction.NORTH);
        int steps = (dSteps(toP) - dSteps(nf) + 4) % 4;
        return switch (steps) { case 1 -> Rotation.CLOCKWISE_90; case 2 -> Rotation.CLOCKWISE_180; case 3 -> Rotation.COUNTERCLOCKWISE_90; default -> Rotation.NONE; };
    }
    private static int dSteps(Direction d) { return switch (d) { case SOUTH -> 0; case WEST -> 1; case NORTH -> 2; case EAST -> 3; default -> 0; }; }

    private static Set<Long> detectIntAir(List<StructureTemplate.StructureBlockInfo> blocks, Vec3i size) {
        int sx = size.getX(), sy = size.getY(), sz = size.getZ();
        boolean[][][] solid = new boolean[sx][sy][sz];
        for (var i : blocks) { BlockPos p = i.pos(); int x = p.getX(), y = p.getY(), z = p.getZ();
            if (x >= 0 && x < sx && y >= 0 && y < sy && z >= 0 && z < sz) solid[x][y][z] = !i.state().isAir(); }
        boolean[][][] ext = new boolean[sx][sy][sz]; ArrayDeque<int[]> q = new ArrayDeque<>();
        for (int x = 0; x < sx; x++) for (int y = 0; y < sy; y++) for (int z = 0; z < sz; z++)
            if ((x == 0 || x == sx - 1 || y == 0 || y == sy - 1 || z == 0 || z == sz - 1) && !solid[x][y][z]) { ext[x][y][z] = true; q.add(new int[]{x, y, z}); }
        int[][] dirs = {{1,0,0},{-1,0,0},{0,1,0},{0,-1,0},{0,0,1},{0,0,-1}};
        while (!q.isEmpty()) { int[] c = q.poll(); for (int[] d : dirs) { int nx = c[0]+d[0], ny = c[1]+d[1], nz = c[2]+d[2];
            if (nx < 0 || nx >= sx || ny < 0 || ny >= sy || nz < 0 || nz >= sz) continue; if (ext[nx][ny][nz] || solid[nx][ny][nz]) continue;
            ext[nx][ny][nz] = true; q.add(new int[]{nx, ny, nz}); } }
        Set<Long> r = new HashSet<>();
        for (int x = 0; x < sx; x++) for (int y = 0; y < sy; y++) for (int z = 0; z < sz; z++) if (!solid[x][y][z] && !ext[x][y][z]) r.add(enc(x, y, z));
        return r;
    }
    private static long enc(int x, int y, int z) { return ((long)(x & 0x7FF) << 22) | ((long)(y & 0x7FF) << 11) | (long)(z & 0x7FF); }

    public static boolean isPlayerChunk(BlockPos candidate, Player player, BlockPos origin) {
        int cx = candidate.getX() >> 4, cz = candidate.getZ() >> 4, ox = origin.getX() >> 4, oz = origin.getZ() >> 4;
        if (cx == ox && cz == oz) return true;
        if (player != null && cx == (player.blockPosition().getX() >> 4) && cz == (player.blockPosition().getZ() >> 4)) return true;
        return false;
    }

    public static BlockPos findSafeOutsideChunkPos(ServerLevel level, BlockPos origin) {
        int[][] offsets = {{32,0},{-32,0},{0,32},{0,-32},{32,32},{-32,-32},{32,-32},{-32,32}};
        for (int[] off : offsets) {
            int cx = origin.getX() + off[0], cz = origin.getZ() + off[1];
            int cy = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, cx, cz) - 1;
            BlockPos cand = new BlockPos(cx, cy, cz);
            if (!isPlayerChunk(cand, null, origin)) return cand;
        }
        return origin.offset(32, 0, 32);
    }

    private static BlockPos findFlat(ServerLevel lvl, BlockPos origin, int structW, int structD, int minEdgeDist) {
        Player p = lvl.getNearestPlayer(origin.getX() + .5, origin.getY() + .5, origin.getZ() + .5, 128, false);
        double lx = 0, lz = 0; BlockPos pp = origin;
        if (p != null) { float yaw = p.getYRot(); lx = -Math.sin(Math.toRadians(yaw)); lz = Math.cos(Math.toRadians(yaw)); pp = p.blockPosition(); }
        int checkR = Math.max(8, Math.max(structW, structD) / 2);
        // minEdgeDist = distance minimum entre le BORD du build (footprint) et le joueur.
        // Le centre du candidat doit etre a minEdgeDist + checkR (demi-footprint) du
        // joueur pour que le bord du build respecte minEdgeDist. Sinon le build (et son
        // terrain modifie) se retrouve sur le joueur meme en montant la distance, parce
        // que le footprint est enorme et revient vers le joueur.
        int minCenterDist = minEdgeDist + checkR;
        // Cap large (300) : la plupart des candidats sont skippes par le check de
        // distance (pas de generation de chunk), donc chercher loin coute peu. Comme
        // ca findFlat trouve direct une zone plate assez loin du joueur, meme pour un
        // gros dist, sans tomber sur le findFarthestLoadedPos (fragile, demande des
        // chunks deja charges).
        int searchR = Math.min(Math.max(SEARCH_R, minCenterDist + 16), 300);

        // On scan TOUTE la zone large (radius SEARCH_R) et on score CHAQUE candidat
        // valide, au lieu de prendre la 1re zone assez plate. Score combine :
        //   - flatExtent : quelle fraction de la zone est plate (la PLUS GRANDE zone
        //     plate gagne). Evite les petites poches plates sur un flanc de montagne.
        //   - slope : ecart max de hauteur (la MOINS pentue gagne).
        // La direction du regard casse l'egalite (prefere devant le joueur a qualite
        // de terrain egale). On compare TOUT et on garde les MEILLEURS candidats
        // (liste triee, pas seulement le n°1 -- voir FIX CHUNKS FANTOMES ci-dessous).
        //
        // FIX CHUNKS FANTOMES (bug "giga montagne"/citadelle rapporte en jeu,
        // logs a l'appui : "flat=100%, pente=0" AU CHOIX, puis "deltaY anormal
        // apres smooth (-61 -> -6, brut=55)" au moment du paste reel) :
        // measureFlatQuality() n'interroge QUE getHeight() SANS jamais forcer la
        // generation des chunks du candidat. Sur un chunk pas encore genere a cet
        // instant, getHeight() peut renvoyer une estimation par defaut TOTALEMENT
        // fausse (souvent "plat"), alors que le terrain REEL, une fois genere par
        // smoothPass() (qui, lui, force la generation), s'avere etre une montagne
        // entiere. Le garde-fou existant (MAX_POST_SMOOTH_DELTA_Y) ne fait que
        // brider le repositionnement DE LA STRUCTURE, mais ne corrige pas le
        // terrain autour, qui lui suit la VRAIE hauteur -> un pilier/montagne
        // se reconstruit litteralement autour du batiment reste a l'ancienne
        // fausse hauteur plate.
        //
        // Correctif : on garde les N meilleurs candidats (mesure rapide, chunks
        // PAS forces), puis on force reellement la generation des chunks du
        // MEILLEUR candidat et on re-mesure avec le terrain REEL. Si l'ecart
        // avec la mesure initiale est trop important (mesure fantome demasquee),
        // on rejette ce candidat et on essaie le suivant de la liste, jusqu'a
        // en trouver un dont le terrain reel est bien plat.
        record FlatCandidate(int cx, int cz, double total, double extent, int slope) {}
        List<FlatCandidate> candidates = new ArrayList<>();
        for (int dx = -searchR; dx <= searchR; dx += SEARCH_S) {
            for (int dz = -searchR; dz <= searchR; dz += SEARCH_S) {
                int cx = origin.getX() + dx, cz = origin.getZ() + dz;
                // BUG CRITIQUE CORRIGE : closerThan() sur des BlockPos calcule une
                // distance 3D (X/Y/Z). L'ancien code comparait le VRAI Y du joueur
                // (ex. 150 en haut d'une montagne) a un Y FICTIF de 64 sur le
                // candidat -> l'ecart vertical inutile (86 blocs ici) suffisait a
                // lui seul a "faire semblant" d'etre loin, alors que le candidat
                // pouvait etre juste a cote du joueur en horizontal. Resultat :
                // en altitude, le filtre "pas trop pres du joueur" ne filtrait
                // presque plus rien, et la structure pouvait se retrouver juste
                // sous les pieds du joueur / au sommet de sa montagne au lieu
                // d'aller chercher une vraie zone plate ailleurs. On compare
                // maintenant uniquement la distance HORIZONTALE (X/Z), le Y du
                // joueur ou du candidat n'a plus aucune influence ici.
                if (p != null) {
                    double dpx = cx - p.blockPosition().getX(), dpz = cz - p.blockPosition().getZ();
                    if ((dpx * dpx + dpz * dpz) < (double) minCenterDist * minCenterDist) continue;
                }
                if (isPlayerChunk(new BlockPos(cx, 64, cz), p, origin)) continue;
                FlatQuality fq = measureFlatQuality(lvl, cx, cz, checkR);
                if (fq == null) continue;
                double terrainScore = Math.max(0, fq.flatExtent() * 1000.0 - fq.slope() * 8.0);
                double loc = Math.max(0, Math.min(100, sc(cx, cz, pp, lx, lz)));
                double total = terrainScore + loc;
                candidates.add(new FlatCandidate(cx, cz, total, fq.flatExtent(), fq.slope()));
            }
        }
        candidates.sort((a, b) -> Double.compare(b.total(), a.total()));
        int maxVerified = Math.min(candidates.size(), 12); // essaie jusqu'a 12 candidats avant d'abandonner
        // FIX (rapporte en jeu : "je casse un bloc, giga freeze infini ou plus
        // rien ne s'update mais moi je peux me deplacer, rien de visible dans
        // les logs" -- freeze SILENCIEUX, sans exception ni ligne de log
        // pendant le blocage) : CAUSE PROBABLE -- pour CHAQUE candidat verifie
        // (jusqu'a 12), la boucle ci-dessous appelle getChunk(..., FULL, true)
        // en SYNCHRONE sur TOUS les chunks d'un carre de checkR*2 autour du
        // candidat (jusqu'a ~150 chunks pour shipdead, 12 candidats -> jusqu'a
        // ~1700 generations de chunk COMPLETES sur le thread principal) AVANT
        // qu'aucune ligne "[STRUCT5-FLAT] Zone choisie"/"REJETE" ne soit
        // loggee -- un monde avec un chunk generator lent (mods de biomes/
        // structures tiers, terrain tres complexe) peut donc bloquer le
        // serveur plusieurs dizaines de secondes SANS que rien n'apparaisse
        // dans les logs avant que le budget de 12 candidats soit epuise
        // (aucun log intermediaire existait). Fix : (1) log AVANT de forcer
        // la generation de chaque candidat, pour que le prochain freeze soit
        // enfin visible dans les logs meme s'il ne se termine jamais ; (2)
        // budget de temps global (FIND_FLAT_TIME_BUDGET_MS) qui interrompt la
        // verification des candidats restants des que depasse, retombant sur
        // le meilleur candidat deja verifie (ou sur le fallback pente
        // minimale) plutot que d'insister indefiniment sur des candidats de
        // moins en moins bons.
        long verifyStart = System.currentTimeMillis();
        for (int i = 0; i < maxVerified; i++) {
            if (i > 0 && System.currentTimeMillis() - verifyStart > FIND_FLAT_TIME_BUDGET_MS) {
                LOGGER.warn("[STRUCT5-FLAT] Budget de temps ({}ms) depasse apres {} candidat(s) verifie(s) -- abandon des {} candidats restants",
                        FIND_FLAT_TIME_BUDGET_MS, i, maxVerified - i);
                break;
            }
            FlatCandidate c = candidates.get(i);
            LOGGER.info("[STRUCT5-FLAT] Verification candidat #{}/{} a {},{} (force generation de la zone, checkR={})...",
                    i + 1, maxVerified, c.cx(), c.cz(), checkR);

            // Force la generation reelle des chunks couverts par checkR autour du
            // candidat (memes limites que measureFlatQuality) avant de re-mesurer :
            // sans ce forçage, getHeight() peut rester fantome et le probleme ne
            // serait jamais detecte avant le paste reel.
            int ccx0 = (c.cx() - checkR) >> 4, ccx1 = (c.cx() + checkR) >> 4;
            int ccz0 = (c.cz() - checkR) >> 4, ccz1 = (c.cz() + checkR) >> 4;
            for (int ccx = ccx0; ccx <= ccx1; ccx++)
                for (int ccz = ccz0; ccz <= ccz1; ccz++)
                    lvl.getChunkSource().getChunk(ccx, ccz, net.minecraft.world.level.chunk.status.ChunkStatus.FULL, true);
            FlatQuality realFq = measureFlatQuality(lvl, c.cx(), c.cz(), checkR);
            if (realFq == null) continue; // devenu invalide une fois genere (ex: fond marin)
            // Un ecart de pente important entre la mesure "avant generation" et la
            // mesure "apres generation forcee" signale un chunk fantome demasque.
            // Tolerance large (2x FLAT_TOLERANCE) pour ne pas rejeter un terrain
            // legitimement a la limite -- seuls les VRAIS ecarts (montagnes
            // cachees) declenchent le rejet.
            boolean phantomDetected = Math.abs(realFq.slope() - c.slope()) > (FLAT_TOLERANCE * 2)
                    || realFq.flatExtent() < 0.5;
            if (phantomDetected) {
                LOGGER.warn("[STRUCT5-FLAT] Candidat {},{} REJETE : terrain fantome demasque apres generation reelle des chunks (pente avant={}, apres={}, flat avant={}%, apres={}%)",
                        c.cx(), c.cz(), c.slope(), realFq.slope(), (int)(c.extent()*100), (int)(realFq.flatExtent()*100));
                continue;
            }
            int realY = lvl.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, c.cx(), c.cz()) - 1;
            LOGGER.info("[STRUCT5-FLAT] Zone choisie a {},{} (candidat #{}/{}) : flat={}%, pente={} (score={}, terrain reel verifie)",
                    c.cx(), c.cz(), i + 1, maxVerified, (int)(realFq.flatExtent() * 100), realFq.slope(), (int) c.total());
            return new BlockPos(c.cx(), realY, c.cz());
        }
        if (!candidates.isEmpty()) {
            LOGGER.warn("[STRUCT5-FLAT] {} candidats testes, tous rejetes comme terrain fantome -- fallback pente minimale", maxVerified);
        }
        // Aucun candidat solide (tout air/eau, ex: ocean). On retombe sur la pente
        // minimale (mesure tolerante). findFlat ne retourne JAMAIS null, sinon la
        // structure tombe sur un flanc et une partie part dans le vide.
        // Meme correctif "chunk fantome" que ci-dessus : on garde les meilleurs
        // candidats et on force la generation reelle avant de valider le premier.
        record SlopeCandidate(int cx, int cz, int slope) {}
        List<SlopeCandidate> slopeCandidates = new ArrayList<>();
        for (int dx = -searchR; dx <= searchR; dx += SEARCH_S) {
            for (int dz = -searchR; dz <= searchR; dz += SEARCH_S) {
                int cx = origin.getX() + dx, cz = origin.getZ() + dz;
                // Meme correctif que ci-dessus : distance HORIZONTALE uniquement.
                if (p != null) {
                    double dpx = cx - p.blockPosition().getX(), dpz = cz - p.blockPosition().getZ();
                    if ((dpx * dpx + dpz * dpz) < (double) minCenterDist * minCenterDist) continue;
                }
                if (isPlayerChunk(new BlockPos(cx, 64, cz), p, origin)) continue;
                int slope = measureSlope(lvl, cx, cz, checkR);
                slopeCandidates.add(new SlopeCandidate(cx, cz, slope));
            }
        }
        slopeCandidates.sort(Comparator.comparingInt(SlopeCandidate::slope));
        int maxSlopeVerified = Math.min(slopeCandidates.size(), 12);
        // FIX (meme freeze silencieux que ci-dessus, voir Javadoc en tete de
        // findFlat) : ce fallback pente-minimale force EXACTEMENT le meme
        // genre de generation de chunks lourde -- il a besoin du meme budget.
        long verifySlopeStart = System.currentTimeMillis();
        for (int i = 0; i < maxSlopeVerified; i++) {
            if (i > 0 && System.currentTimeMillis() - verifySlopeStart > FIND_FLAT_TIME_BUDGET_MS) {
                LOGGER.warn("[STRUCT5-FLAT] Budget de temps ({}ms) depasse (fallback pente-minimale) apres {} candidat(s) -- abandon des {} candidats restants",
                        FIND_FLAT_TIME_BUDGET_MS, i, maxSlopeVerified - i);
                break;
            }
            SlopeCandidate c = slopeCandidates.get(i);
            int ccx0 = (c.cx() - checkR) >> 4, ccx1 = (c.cx() + checkR) >> 4;
            int ccz0 = (c.cz() - checkR) >> 4, ccz1 = (c.cz() + checkR) >> 4;
            for (int ccx = ccx0; ccx <= ccx1; ccx++)
                for (int ccz = ccz0; ccz <= ccz1; ccz++)
                    lvl.getChunkSource().getChunk(ccx, ccz, net.minecraft.world.level.chunk.status.ChunkStatus.FULL, true);
            int realSlope = measureSlope(lvl, c.cx(), c.cz(), checkR);
            if (Math.abs(realSlope - c.slope()) > (FLAT_TOLERANCE * 2)) {
                LOGGER.warn("[STRUCT5-FLAT] Candidat pente-minimale {},{} REJETE : terrain fantome (pente avant={}, apres={})",
                        c.cx(), c.cz(), c.slope(), realSlope);
                continue;
            }
            int slY = lvl.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, c.cx(), c.cz()) - 1;
            LOGGER.warn("[STRUCT5-FLAT] Aucune zone solide plate valide, utilise la pente minimale verifiee (diff={}) a {},{}", realSlope, c.cx(), c.cz());
            return new BlockPos(c.cx(), slY, c.cz());
        }
        LOGGER.warn("[STRUCT5-FLAT] Aucune zone valide trouvee");
        return null;
    }

    // Ecart max (en blocs) pour qu'une colonne compte comme "plate" par rapport au
    // centre du candidat. Sert a mesurer la TAILLE de la zone plate (flatExtent).
    private static final int FLAT_TOLERANCE = 4;

    // Qualite d'une zone candidate : slope (ecart max de hauteur) + flatExtent
    // (fraction des echantillons dans la tolerance = a quel point la zone plate est
    // GRANDE). null si le centre est air/eau/non-solide (candidat invalide).
    private record FlatQuality(int slope, double flatExtent) {}

    private static FlatQuality measureFlatQuality(ServerLevel l, int cx, int cz, int radius) {
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        int step = Math.max(1, radius / 4);
        int centerY = l.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, cx, cz) - 1;
        BlockState centerState = l.getBlockState(p.set(cx, centerY, cz));
        if (centerState.isAir() || !centerState.getFluidState().isEmpty() || !centerState.blocksMotion()) return null;
        int minY = Integer.MAX_VALUE, maxY = Integer.MIN_VALUE, total = 0, flat = 0;
        for (int dx = -radius; dx <= radius; dx += step) {
            for (int dz = -radius; dz <= radius; dz += step) {
                int y = l.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, cx + dx, cz + dz) - 1;
                total++;
                if (Math.abs(y - centerY) <= FLAT_TOLERANCE) flat++;
                if (y < minY) minY = y; if (y > maxY) maxY = y;
            }
        }
        return new FlatQuality(maxY - minY, total > 0 ? (double) flat / total : 0);
    }

    // Mesure de pente TOLERANTE : juste l'ecart max de hauteur, sans rejeter l'air
    // ni l'eau. Utilisee en tout dernier recours par findFlat quand aucun candidat
    // solide n'a ete trouve (tout air/eau, ex: ocean). On prend la pente minimale.
    private static int measureSlope(ServerLevel l, int cx, int cz, int radius) {
        int step = Math.max(1, radius / 3);
        int minY = Integer.MAX_VALUE, maxY = Integer.MIN_VALUE;
        for (int dx = -radius; dx <= radius; dx += step) {
            for (int dz = -radius; dz <= radius; dz += step) {
                int y = l.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, cx + dx, cz + dz) - 1;
                if (y < minY) minY = y;
                if (y > maxY) maxY = y;
            }
        }
        return maxY - minY;
    }

    private static int sc(int cx, int cz, BlockPos pp, double lx, double lz) {
        int sc = 0; double dx = cx - pp.getX(), dz = cz - pp.getZ(), dist = Math.sqrt(dx * dx + dz * dz);
        if (dist < 1) return 100;
        sc += Math.max(0, 50 - (int)(Math.abs(dist - 25) * 2));
        if (lx != 0 || lz != 0) { double dot = (dx * lx + dz * lz) / dist;
            if (dot > Math.cos(VIEW_CONE / 2)) sc += 100 + (int)(dot * 50); else if (dot > 0) sc += 30; else sc -= 20; }
        return sc;
    }

    private static boolean doPaste(ServerLevel level, BlockPos origin, String nbt, int ox, int oy, int oz,
                                   int dist, Direction nf, boolean followSurf, boolean useFlat, boolean keepInt) {
        long tGlobal = System.currentTimeMillis();
        LOGGER.info("[STRUCT5] === PASTE {} === off=[{},{},{}] dist={} facing={}", nbt, ox, oy, oz, dist, nf);
        int minChunksReq = isEverestNbt(nbt) ? MIN_CHUNKS_EVEREST : MIN_CHUNKS_NORMAL;
        // FIX (freeze serveur au chargement à froid d'un gros NBT, ex :
        // citadel.nbt ~6 Mo) : cache mod-wide partagé (StructureTemplateCache,
        // aussi préchargé au démarrage serveur) au lieu d'un appel direct au
        // StructureTemplateManager.
        StructureTemplate tmpl = deepluckyblock.util.StructureTemplateCache.get(level, nbt);
        if (tmpl == null) return false;
        Vec3i size = tmpl.getSize();
        Player pl = level.getNearestPlayer(origin.getX() + .5, origin.getY() + .5, origin.getZ() + .5, 128, false);

        // Distance minimum entre le BORD du build et le joueur : max du global
        // (MIN_PLAYER_DISTANCE) et du parametre par structure (dist). findFlat l'utilise
        // pour que le footprint (pas seulement le centre) respecte la distance, sinon
        // un gros build revient jusqu'au joueur meme en montant la distance.
        int minEdgeDist = Math.max(MIN_PLAYER_DISTANCE, dist > 0 ? dist : 0);
        BlockPos txz;
        if (useFlat) {
            BlockPos f = findFlat(level, origin, Math.abs(size.getX()), Math.abs(size.getZ()), minEdgeDist);
            if (f != null) txz = f;
            else if (dist > 0) { txz = findFarthestLoadedPos(level, origin, dist, minChunksReq); if (txz == null) return false; }
            else txz = findSafeOutsideChunkPos(level, origin);
        } else if (dist > 0) {
            txz = findFarthestLoadedPos(level, origin, dist, minChunksReq); if (txz == null) return false;
        } else txz = findSafeOutsideChunkPos(level, origin);

        BlockPos safePos = resolveSafePosition(level, txz, nbt);
        if (safePos == null) return false;
        txz = safePos;
        if (isPlayerChunk(txz, pl, origin)) txz = findSafeOutsideChunkPos(level, origin);
        // Meme famille de bug que dans findFlat() : distSqr() sur des BlockPos est
        // une distance 3D. Ici txz.getY() vient de resolveSafePosition() (le vrai
        // terrain a la zone plate choisie), qui peut etre tres different du Y reel
        // du joueur (ex. joueur en haut d'une montagne, zone plate en contrebas) :
        // l'ecart vertical, legitime, ne doit pas fausser ce garde-fou "pas trop
        // pres du joueur horizontalement". On ne compare que X/Z.
        if (pl != null && dist > 0) {
            double ddx = pl.blockPosition().getX() - txz.getX(), ddz = pl.blockPosition().getZ() - txz.getZ();
            if (ddx * ddx + ddz * ddz < 100) return false;
        }

        int baseY = followSurf ? level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, txz.getX(), txz.getZ()) - 1 : origin.getY();
        List<StructureTemplate.StructureBlockInfo> raw = exBlocks(tmpl);
        if (raw.isEmpty()) {
            BlockPos fp0 = new BlockPos(txz.getX() + ox, baseY + oy, txz.getZ() + oz);
            Rotation rot0 = facePlayer(fp0, pl, nf);
            BlockPos rp0 = adjRot(fp0, tmpl, rot0);
            BlockPos min0 = new BlockPos(Math.min(rp0.getX(), rp0.getX() + size.getX()), rp0.getY(), Math.min(rp0.getZ(), rp0.getZ() + size.getZ()));
            BlockPos max0 = min0.offset(Math.abs(size.getX()), size.getY(), Math.abs(size.getZ()));
            StructurePlaceSettings fb = new StructurePlaceSettings().setRotation(rot0).setMirror(Mirror.NONE).setIgnoreEntities(true).addProcessor(BlockIgnoreProcessor.AIR);
            tmpl.placeInWorld(level, rp0, rp0, fb, level.getRandom(), FAST_FLAG);
            POST_Q.offer(new PostJob(level, min0, max0, nbt));
            return true;
        }
        // Filtrer d'abord (verre/laggy supprimes), PUIS minRelY sur la liste filtree.
        // Sinon le verre en bas du NBT fausse minRelY et fait flotter la structure.
        Set<Long> intAir = isEverestNbt(nbt) ? Collections.emptySet() : detectIntAir(raw, size);
        // Niveau reel du sol du template, hors LIGHT et vignes techniques.
        // Le Y brut du template peut etre positif tout en etant enterre apres
        // l'application de minRelY : c'est pourquoi on compare a floorRelY.
        int floorRelY = Integer.MAX_VALUE;
        for (var info : raw) {
            BlockState candidate = info.state();
            if (candidate.isAir() || isTechnicalLightOrVine(candidate)) continue;
            floorRelY = Math.min(floorRelY, info.pos().getY());
        }
        if (floorRelY == Integer.MAX_VALUE) floorRelY = 0;

        List<StructureTemplate.StructureBlockInfo> filt = new ArrayList<>(raw.size());
        int glassSkipped = 0;
        for (var info : raw) {
            BlockState s = info.state();
            if (isLaggy(s)) continue;
            // Y relatif 1, 0 et negatif = sol et blocs enterres de la structure.
            // On retire seulement l'id light technique et les vignes vanilla.
            // Les LIGHT en positif restent intacts.
            if (isUndergroundTechnicalBlock(s, info.pos().getY() - floorRelY)) continue;
            if (isGlassBlock(s)) { glassSkipped++; continue; }
            if (s.isAir()) { if (!isEverestNbt(nbt) && intAir.contains(enc(info.pos().getX(), info.pos().getY(), info.pos().getZ()))) filt.add(info); }
            else filt.add(info);
        }
        // minRelY calcule sur la liste FILTREE (hors verre) pour que la base arrive
        // exactement a baseY+offset. Si le verre etait en bas, il n'est plus la et
        // ne fausse plus le calcul.
        int minRelY = 0;
        if (!filt.isEmpty()) { minRelY = Integer.MAX_VALUE; for (var b : filt) { int by = b.pos().getY(); if (by < minRelY) minRelY = by; } }
        BlockPos fp = new BlockPos(txz.getX() + ox, baseY + oy - minRelY, txz.getZ() + oz);
        Rotation rot = facePlayer(fp, pl, nf);
        BlockPos rp = adjRot(fp, tmpl, rot);
        LOGGER.info("[STRUCT5] {} -> {} (baseY={}, minRelY={}, rot={}, {}ms)", nbt, rp.toShortString(), baseY, minRelY, rot, System.currentTimeMillis() - tGlobal);
        // Bounding box EXACTE de la structure (positions réellement rotées) : le smooth
        // et le paste seront parfaitement alignés. Corrige le décalage (~1 bloc) ET le
        // swap X/Z des rotations 90/270 (rp+size était approximatif).
        StructurePlaceSettings bboxRs = new StructurePlaceSettings().setRotation(rot).setMirror(Mirror.NONE);
        int bMinX=Integer.MAX_VALUE, bMinY=Integer.MAX_VALUE, bMinZ=Integer.MAX_VALUE;
        int bMaxX=Integer.MIN_VALUE, bMaxY=Integer.MIN_VALUE, bMaxZ=Integer.MIN_VALUE;
        for (StructureTemplate.StructureBlockInfo info : filt) {
            BlockPos rel = StructureTemplate.calculateRelativePosition(bboxRs, info.pos());
            int bx=rp.getX()+rel.getX(), by=rp.getY()+rel.getY(), bz=rp.getZ()+rel.getZ();
            if (bx<bMinX)bMinX=bx; if(bx>bMaxX)bMaxX=bx;
            if (by<bMinY)bMinY=by; if(by>bMaxY)bMaxY=by;
            if (bz<bMinZ)bMinZ=bz; if(bz>bMaxZ)bMaxZ=bz;
        }
        BlockPos min = new BlockPos(bMinX, bMinY, bMinZ);
        BlockPos max = new BlockPos(bMaxX, bMaxY, bMaxZ);
        filt = orderByY(filt);
        LOGGER.info("[STRUCT5] {} : {} blocs ({} verre supprime)", nbt, filt.size(), glassSkipped);
        final List<StructureTemplate.StructureBlockInfo> fFilt = filt;
        final BlockPos fTxz = txz;   // XZ ou baseY a ete mesure (AVANT smooth)
        final int fBaseY = baseY;    // surface AVANT smooth
        final BlockPos fRp = rp, fMin = min, fMax = max;
        StructureTerrainPrep.setTerrainRingScalePercent(ringScaleFor(nbt));
        StructureTerrainPrep.prepZone(level, min, max, fBaseY + oy, () -> {
            // RE-mesurer la surface APRES le smooth : la structure doit rentrer dans
            // le sol du terrain LISSE (pas l'ancien). On ne touche que Y (X/Z = idem,
            // donc l'alignement smooth/structure reste parfait).
            int newBaseY = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, fTxz.getX(), fTxz.getZ()) - 1;
            int rawDeltaY = newBaseY - fBaseY;
            // Le sol a ete choisi PLAT avant le smooth : un ecart enorme post-smooth
            // (ex : montagne, +300) est TOUJOURS un bug de mesure/anchoring, jamais
            // une intention voulue. On borne pour ne jamais reproduire ce bug.
            int deltaY = Math.max(-MAX_POST_SMOOTH_DELTA_Y, Math.min(MAX_POST_SMOOTH_DELTA_Y, rawDeltaY));
            BlockPos pasteRp = fRp.offset(0, deltaY, 0);
            BlockPos pasteMin = fMin.offset(0, deltaY, 0);
            BlockPos pasteMax = fMax.offset(0, deltaY, 0);
            if (rawDeltaY != deltaY)
                LOGGER.warn("[STRUCT5] {} : deltaY anormal apres smooth ({} -> {}, brut={}) BORNE a {} - possible bug d'ancrage", nbt, fBaseY, newBaseY, rawDeltaY, deltaY);
            else if (deltaY != 0)
                LOGGER.info("[STRUCT5] {} : re-ancrage Y apres smooth (baseY {} -> {}, deltaY={})", nbt, fBaseY, newBaseY, deltaY);
            // FIX CRITIQUE (rapporte en jeu : "Sylvan Citadel" apparue a moitie
            // dans le vide -- log correspondant : "citadel : deltaY anormal
            // apres smooth (90 -> 74, brut=-16) BORNE a -4") : quand le sol
            // REEL post-smooth s'effondre plus bas que ce que MAX_POST_SMOOTH_DELTA_Y
            // autorise a suivre (ex : ravin/grotte/falaise demasque par le
            // smooth), on borne deltaY pour ne pas faire re-sombrer TOUTE la
            // structure vers ce trou (comportement voulu, voir commentaire
            // ci-dessus) -- MAIS cela laisse alors un ECART VIDE non comble
            // entre le bas reel du terrain (newBaseY) et le bas ou la
            // structure est effectivement posee (pasteMin.getY()-1) : sur les
            // colonnes du footprint qui tombent dans ce trou, la structure se
            // retrouve donc a moitie en suspension au-dessus du vide, exactement
            // le bug rapporte.
            //
            // CORRECTIF DEMANDE (retour utilisateur suite au premier fix jugé
            // insuffisant) : on ne se contente plus de boucher le trou EXACT
            // avec de la pierre brute -- backfillVoidGap() construit desormais
            // une VRAIE plateforme (plateau plat sous l'emprise + rampe de
            // raccord en pente douce vers newBaseY, la hauteur REELLE du
            // terrain naturel deja mesuree juste au-dessus) et recouvre tout
            // de grass_block (jamais de pierre/terre visible en surface). On
            // lui passe newBaseY (avant bornage) comme cible de raccord.
            if (rawDeltaY < -MAX_POST_SMOOTH_DELTA_Y) {
                StructureTerrainPrep.backfillVoidGap(level, pasteMin, pasteMax, newBaseY);
            }
            PASTE_Q.offer(new PasteJob(level, fFilt, pasteRp, rot, Mirror.NONE, nbt, tGlobal, pl, pasteMin, pasteMax));

        });
        return true;
    }

    private static List<StructureTemplate.StructureBlockInfo> orderByY(List<StructureTemplate.StructureBlockInfo> blocks) {
        List<StructureTemplate.StructureBlockInfo> sorted = new ArrayList<>(blocks);
        sorted.sort((a, b) -> { int ya = a.pos().getY(), yb = b.pos().getY(); if (ya != yb) return Integer.compare(ya, yb);
            int xa = a.pos().getX(), xb = b.pos().getX(); if (xa != xb) return Integer.compare(xa, xb); return Integer.compare(a.pos().getZ(), b.pos().getZ()); });
        return sorted;
    }

    @SuppressWarnings("unchecked")
    private static List<StructureTemplate.StructureBlockInfo> exBlocks(StructureTemplate t) {
        try { for (Field f : StructureTemplate.class.getDeclaredFields()) { f.setAccessible(true); Object val = f.get(t);
            if (val instanceof List<?> list && !list.isEmpty() && list.get(0) instanceof StructureTemplate.Palette)
                return ((StructureTemplate.Palette) list.get(0)).blocks(); }
        } catch (Exception e) { LOGGER.warn("[STRUCT5] Reflection echouee: {}", e.getMessage()); }
        return Collections.emptyList();
    }

    private static BlockPos adjRot(BlockPos p, StructureTemplate t, Rotation r) {
        Vec3i s = t.getSize();
        return switch (r) { case NONE -> p; case CLOCKWISE_90 -> p.offset(s.getZ() - 1, 0, 0);
            case CLOCKWISE_180 -> p.offset(s.getX() - 1, 0, s.getZ() - 1); case COUNTERCLOCKWISE_90 -> p.offset(0, 0, s.getX() - 1); };
    }

    /** Message vendeur affiche au joueur lorsque la structure est entierement posee. */
    private static int removeUndergroundTechnicalBlocks(ServerLevel level, BlockPos min, BlockPos max) {
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        int removed = 0;
        int thresholdY = min.getY() + 1;

        for (int x = min.getX(); x <= max.getX(); x++) {
            for (int z = min.getZ(); z <= max.getZ(); z++) {
                for (int y = level.getMinBuildHeight(); y <= Math.min(max.getY(), thresholdY); y++) {
                    pos.set(x, y, z);
                    BlockState state = level.getBlockState(pos);
                    if (isTechnicalLightOrVine(state)) {
                        level.setBlock(pos, Blocks.AIR.defaultBlockState(), FAST_FLAG);
                        removed++;
                    }
                }
            }
        }
        return removed;
    }

    // FIX (rapporte en jeu : "les coffres relies a notre systeme de coffre
    // common a ultimate ne fonctionnent plus" + "l'Everest est sense
    // supprimer les coffres et n'en laisser que 3 max, la ils sont tous
    // la") : {@link #prepareAutomaticChest} et {@link #cleanupEverestChests}
    // etaient private static, utilisables UNIQUEMENT depuis la boucle de
    // paste (PasteJob) de CETTE classe -- or le VRAI pipeline de placement
    // de l'Everest vit entierement dans {@link Structures4Procedure}
    // (EverestJob/EVEREST_QUEUE, jamais PasteJob), qui n'appelait donc
    // JAMAIS ni l'une ni l'autre : aucun coffre d'Everest ne recevait les
    // drapeaux slb_auto_chest/slb_chest_rank (donc jamais rempli par
    // LuckyChestAutofillProcedure -- "coffres qui ne fonctionnent plus"),
    // et cleanupEverestChests n'etait jamais invoque pour Everest (donc
    // TOUS les coffres restaient en place). Passage a package-private pour
    // que Structures4Procedure puisse les appeler directement lors du
    // placement bloc-par-bloc de l'EverestJob, exactement comme le fait
    // deja PasteJob pour citadel/observatory/dragon.
    static void prepareAutomaticChest(ServerLevel level, BlockPos pos, BlockState state,
                                               CompoundTag originalNbt, int relativeY,
                                               List<StructureTemplate.StructureBlockInfo> blocks) {
        if (!(state.getBlock() instanceof net.minecraft.world.level.block.ChestBlock)) return;
        var be = level.getBlockEntity(pos);
        if (!(be instanceof net.minecraft.world.level.block.entity.ChestBlockEntity chest)) return;

        CompoundTag data = chest.getPersistentData();
        if (data.getBoolean("slb_auto_chest")) return;

        // FIX CRITIQUE (rapporte en jeu : "tous les coffres sont vides !") :
        // ChestBlockEntity#saveAdditional ecrit TOUJOURS une liste "Items"
        // dans le NBT sauvegarde -- meme quand le coffre est totalement vide,
        // "Items" est present mais avec une ListTag de longueur 0. L'ancien
        // test originalNbt.contains("Items") est donc VRAI pour absolument
        // TOUS les coffres exportes dans un template de structure (verifie
        // via inspection directe de citadel.nbt/everest.nbt : 100% des
        // coffres portent une cle "Items", y compris ceux dont la liste est
        // vide) -> hasDefinedContent etait presque toujours vrai, et
        // prepareAutomaticChest() rendait la main AVANT de poser le moindre
        // drapeau slb_auto_chest, quel que soit le contenu reel du coffre.
        // Resultat : plus un seul coffre de citadel/observatoire/dragon/
        // everest ne recevait jamais les drapeaux exiges par
        // LuckyChestAutofillProcedure -> ils restaient vides pour toujours,
        // exactement le symptome rapporte. Correction : ne considerer le
        // contenu comme "deja defini" que si la liste Items existe ET
        // contient reellement au moins un item (ou si une LootTable est
        // presente) -- un coffre au NBT vide (le cas normal/voulu pour tous
        // les coffres a remplir automatiquement) reçoit desormais bien ses
        // drapeaux.
        boolean hasItems = originalNbt != null && originalNbt.contains("Items")
                && !originalNbt.getList("Items", net.minecraft.nbt.Tag.TAG_COMPOUND).isEmpty();
        boolean hasDefinedContent = originalNbt != null
                && (hasItems || originalNbt.contains("LootTable"));
        if (hasDefinedContent) return;

        // FIX (politique de correspondance exacte demandee : "coffre avec
        // NBT/titre correspondant a un rang -> meme rang de coffre modde ;
        // coffre sans NBT/titre special -> coffre aleatoire parmi le TOP 3
        // des rangs (Ultimate, Ultimate-1, Ultimate-2) UNIQUEMENT, jamais
        // parmi tout le pool de rangs") :
        //
        // A ce stade de la methode, le coffre n'a NI drapeau slb_auto_chest
        // pre-existant (deja gere par le retour anticipe ci-dessus -- ce
        // cas correspond au coffre "matched-rank NBT/titre", dont le rang
        // baked dans la structure (NeoForgeData -> slb_chest_rank) a deja
        // ete recharge tel quel par loadWithComponents et est donc deja
        // conserve), NI contenu vanilla reel deja defini (Items/LootTable,
        // cas ci-dessus). Il s'agit donc forcement d'un coffre "vierge" --
        // sans titre special ni contenu -- pour lequel l'ancienne logique
        // choisissait un rang par interpolation de hauteur relative sur
        // TOUTE la plage 1-5 (Chest a Ultimate). Remplace par un tirage
        // ALEATOIRE STRICTEMENT parmi les 3 rangs superieurs uniquement :
        // Ultimate (5), Ultimate-1 = Epic (4), Ultimate-2 = Rare (3).
        int[] topThreeRanks = {5, 4, 3};
        int rank = topThreeRanks[level.getRandom().nextInt(topThreeRanks.length)];

        data.putBoolean("slb_auto_chest", true);
        data.putBoolean("slb_filled", false);
        data.putInt("slb_chest_rank", rank);
        chest.setChanged();
    }

    // ==================== EVEREST: NETTOYAGE DES COFFRES ====================
    /** Rang auto du coffre (slb_chest_rank) ; 0 s'il n'est pas un coffre auto. */
    private static int chestRank(ServerLevel level, BlockPos p) {
        var be = level.getBlockEntity(p);
        if (be != null) return be.getPersistentData().getInt("slb_chest_rank");
        return 0;
    }

    /**
     * Retire la majorite des coffres de l'Everest, en ne conservant qu'un
     * nombre ALÉATOIRE entre EVEREST_CHEST_MIN et EVEREST_CHEST_MAX, tiré
     * parmi TOUS les coffres (aucune priorité "plus riche"). Appele juste apres
     * la pose, sur la liste des coffres releves pendant le paste (cheap -> pas
     * de rescan complet de la structure).
     */
    public static void cleanupEverestChests(ServerLevel level, List<BlockPos> chests) {
        if (level == null || chests == null || chests.isEmpty()) return;
        int keep = EVEREST_CHEST_MIN + level.getRandom().nextInt(EVEREST_CHEST_MAX - EVEREST_CHEST_MIN + 1);
        // Mélange complet -> on garde keep coffres STRICTEMENT au hasard.
        Collections.shuffle(chests, new java.util.Random(level.getRandom().nextLong()));

        int kept = Math.min(keep, chests.size());
        int removed = chests.size() - kept;
        for (int i = kept; i < chests.size(); i++) {
            BlockPos c = chests.get(i);
            level.setBlock(c, Blocks.AIR.defaultBlockState(), FAST_FLAG);
            LOGGER.info("[STRUCT5-EVEREST] Coffre retire: {}", c.toShortString());
        }
        // Sur les coffres conserves : retirer tout item Shadow Essence du contenu.
        for (int i = 0; i < kept; i++) {
            removeShadowEssence(level, chests.get(i));
        }
        LOGGER.info("[STRUCT5-EVEREST] {} coffres retires, {} conserves (au hasard, sans Shadow Essence)", removed, kept);
    }

    /**
     * Retire TOUS les items "Shadow Essence" du contenu d'un coffre (celui deja
     * rempli via son NBT). Compatible avec les items dont le registry name est
     * "deep_lucky_block:shadow_essence" (ou toute variante de paquet finissant
     * par ":shadow_essence"). Ne fait rien si aucun n'est present.
     */
    private static void removeShadowEssence(ServerLevel level, BlockPos pos) {
        try {
            var be = level.getBlockEntity(pos);
            if (!(be instanceof net.minecraft.world.level.block.entity.ChestBlockEntity chest)) return;
            int size = chest.getContainerSize();
            boolean any = false;
            for (int i = 0; i < size; i++) {
                ItemStack stack = chest.getItem(i);
                if (stack == null || stack.isEmpty()) continue;
                if (isShadowEssence(stack)) {
                    chest.setItem(i, ItemStack.EMPTY);
                    any = true;
                    LOGGER.info("[STRUCT5-EVEREST] Shadow Essence retire de {}", pos.toShortString());
                }
            }
            if (any) chest.setChanged();
        } catch (Throwable t) {
            LOGGER.warn("[STRUCT5-EVEREST] Impossible de nettoyer {} : {}", pos.toShortString(), t.getMessage());
        }
    }

    /** True si l'item est une Shadow Essence (registry path == "shadow_essence"). */
    private static boolean isShadowEssence(ItemStack stack) {
        try {
            var key = net.minecraft.core.registries.BuiltInRegistries.ITEM.getKey(stack.getItem());
            if (key == null) return false;
            String path = key.getPath().toLowerCase(Locale.ROOT);
            return path.equals("shadow_essence") || path.endsWith(":shadow_essence") || path.contains("shadow_essence");
        } catch (Throwable t) {
            return false;
        }
    }

    // ==================== EVEREST: SPAWN DES MOBS SUR LA MONTAGNE ====================
    /**
     * Fait spawn 10-20 mobs SUR la surface de la montagne (le bloc le plus haut de
     * chaque colonne echantillonnee) et AUTOUR, mais JAMAIS au sommet : une bande
     * EVEREST_TOP_MARGIN au-dessus du sommet est exclue (les PNJ y vivent, on ne
     * veut pas que les mobs les tuent). La montagne etant creuse, on pose les mobs
     * sur la surface exterieure (pas dedans), via le Heightmap.
     */
    public static void spawnEverestMobs(ServerLevel level, BlockPos min, BlockPos max) {
        if (level == null || min == null || max == null) return;
        RandomSource r = level.getRandom();
        int count = EVEREST_MOB_MIN + r.nextInt(EVEREST_MOB_MAX - EVEREST_MOB_MIN + 1);
        int step = Math.max(1, EVEREST_SURFACE_STEP);

        Map<Long, Integer> surface = new HashMap<>();
        int maxSurf = Integer.MIN_VALUE;
        for (int x = min.getX(); x <= max.getX(); x += step) {
            for (int z = min.getZ(); z <= max.getZ(); z += step) {
                int surfY = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z) - 1;
                if (surfY <= level.getMinBuildHeight()) continue;
                surface.put(colKey(x, z), surfY);
                if (surfY > maxSurf) maxSurf = surfY;
            }
        }
        if (surface.isEmpty()) return;

        // On exclut la bande au-dessus du sommet (PNJ) : ne pas y spawner.
        int summitThreshold = maxSurf - EVEREST_TOP_MARGIN;
        List<Map.Entry<Long, Integer>> valid = new ArrayList<>();
        for (Map.Entry<Long, Integer> e : surface.entrySet()) {
            if (e.getValue() <= summitThreshold) valid.add(e);
        }
        if (valid.isEmpty()) {
            LOGGER.warn("[STRUCT5-EVEREST] Aucune surface hors sommet -> pas de mobs");
            return;
        }
        Collections.shuffle(valid, new java.util.Random(r.nextLong()));

        int spawned = 0;
        for (Map.Entry<Long, Integer> e : valid) {
            if (spawned >= count) break;
            int x = keyX(e.getKey()), z = keyZ(e.getKey()), y = e.getValue() + 1;
            EntityType<?> type = EVEREST_MOB_TYPES[r.nextInt(EVEREST_MOB_TYPES.length)];
            Mob mob = (Mob) type.create(level);
            if (mob == null) continue;
            mob.moveTo(x + 0.5, y, z + 0.5, r.nextFloat() * 360.0f, 0);
            mob.setPersistenceRequired();
            mob.setCanPickUpLoot(true);
            level.addFreshEntity(mob);
            spawned++;
        }
        LOGGER.info("[STRUCT5-EVEREST] {} mobs spawnes sur la montagne (centre env. {},{})", spawned,
                Math.floorDiv(min.getX() + max.getX(), 2), Math.floorDiv(min.getZ() + max.getZ(), 2));
    }

    private static void announceStructureSpawn(Player player, String rawName, BlockPos min, BlockPos max) {
        if (player == null) return;

        String structureName = switch (rawName.toLowerCase(Locale.ROOT)) {
            case "citadel" -> "Sylvan Citadel";
            case "observatory" -> "Fae Observatory";
            case "dragon" -> "Dragon Sanctuary";
            case "circus" -> "Cursed Circus";
            case "shipdead" -> "Ghost Ship";
            case "everest" -> "Inoxtag Everest";
            default -> rawName;
        };

        int centerX = Math.floorDiv(min.getX() + max.getX(), 2);
        int centerY = Math.floorDiv(min.getY() + max.getY(), 2);
        int centerZ = Math.floorDiv(min.getZ() + max.getZ(), 2);

        Component message = Component.literal(
                "\u00a76\u00a7l✦ STRUCTURE DISCOVERED ✦ \u00a7r"
                        + "\u00a7e\u00a7l" + structureName
                        + " \u00a7f\u00a7lhas spawned! \u00a77Center coordinates: "
                        + "\u00a7b[" + centerX + ", " + centerY + ", " + centerZ + "]"
                        + " \u00a76✦");

        player.sendSystemMessage(message);
    }

    private static void postLayer(ServerLevel lvl, BlockPos min, BlockPos max, int y) {
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        BlockPos.MutableBlockPos chk = new BlockPos.MutableBlockPos();
        for (int x = min.getX(); x < max.getX(); x++) for (int z = min.getZ(); z < max.getZ(); z++) {
            pos.set(x, y, z); BlockState s = lvl.getBlockState(pos); if (s.isAir()) continue;
            if (isGlassBlock(s) && isFloat(lvl, pos, chk)) lvl.setBlock(pos, Blocks.AIR.defaultBlockState(), FAST_FLAG);
            else if (s.is(Blocks.VINE) && removeVine(lvl, pos, chk)) lvl.setBlock(pos, Blocks.AIR.defaultBlockState(), FAST_FLAG);
            else if (s.is(Blocks.CRIMSON_HYPHAE) || s.is(Blocks.STRIPPED_CRIMSON_HYPHAE) || s.is(Blocks.CRIMSON_STEM) || s.is(Blocks.STRIPPED_CRIMSON_STEM) || s.is(Blocks.CRIMSON_PLANKS)) {
                lvl.setBlock(pos, Blocks.AIR.defaultBlockState(), FAST_FLAG); spawnGlow(lvl, pos, mkItem(lvl, lvl.getRandom()));
            }
        }
    }

    private static boolean isFloat(ServerLevel l, BlockPos p, BlockPos.MutableBlockPos c) {
        for (Direction d : Direction.values()) { c.set(p.getX() + d.getStepX(), p.getY() + d.getStepY(), p.getZ() + d.getStepZ());
            BlockState n = l.getBlockState(c); if (!n.isAir() && !n.blocksMotion()) return false; }
        return true;
    }

    private static boolean removeVine(ServerLevel l, BlockPos p, BlockPos.MutableBlockPos c) {
        int solid = 0;
        for (Direction d : Direction.values()) { c.set(p.getX() + d.getStepX(), p.getY() + d.getStepY(), p.getZ() + d.getStepZ());
            BlockState n = l.getBlockState(c); if (!n.isAir() && !n.is(Blocks.VINE) && n.blocksMotion()) solid++; }
        return solid >= 4;
    }

    private static ItemStack mkItem(ServerLevel l, RandomSource r) {
        try { int luck = 60 + r.nextInt(31); ItemStack res = GenerateLuckyItemProcedure.generate(l, luck, TestProcedure.QualityTier.getQualityTier(luck), r);
            if (res != null && !res.isEmpty()) return res; } catch (Exception ignored) {}
        ItemStack a = new ItemStack(Items.GOLDEN_APPLE); a.set(net.minecraft.core.component.DataComponents.CUSTOM_NAME, Component.literal("\u00a76\u00a7l\u2726 Tresor \u2726")); return a;
    }

    private static void spawnGlow(ServerLevel lvl, BlockPos pos, ItemStack item) {
        if (!item.has(net.minecraft.core.component.DataComponents.CUSTOM_NAME)) item.set(net.minecraft.core.component.DataComponents.CUSTOM_NAME, Component.literal("\u00a76\u00a7l\u2726 Recompense \u2726"));
        ItemEntity e = new ItemEntity(lvl, pos.getX() + .5, pos.getY() + 1, pos.getZ() + .5, item);
        e.setGlowingTag(true); e.setNoGravity(true); e.setInvulnerable(true); e.setDeltaMovement(0, 0, 0); e.setPickUpDelay(40);
        CompoundTag nbt = new CompoundTag(); e.save(nbt); nbt.putShort("Age", (short) -32768); nbt.putShort("Health", (short) 32767);
        nbt.putBoolean("Invulnerable", true); nbt.putBoolean("PersistenceRequired", true);
        nbt.putShort("PickupDelay", (short) 40); nbt.putInt("Lifespan", Integer.MAX_VALUE);
        e.load(nbt); e.setCustomName(Component.literal("\u00a76\u00a7l\u2726 Recompense \u2726")); e.setCustomNameVisible(false);
        lvl.addFreshEntity(e);
    }
}
