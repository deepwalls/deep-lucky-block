package deepluckyblock.procedures;

import deepluckyblock.advancements.DeepLuckyBlockAdvancements;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;

import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.Mod;

import deepluckyblock.entity.CrimsonButterflyEntity;
import deepluckyblock.init.DeepLuckyBlockModEntities;

import java.lang.reflect.Field;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import net.neoforged.fml.common.EventBusSubscriber;

@EventBusSubscriber(modid = "deep_lucky_block")
public class CrimsonLakeStructureSpawnProcedure {

    // ACTIVE/DESACTIVE les logs de debug [SLB-DEBUG]. Mettre a false avant publication.
    private static final boolean DEBUG_LOGS = false;

    private static final int BLOCKS_PER_TICK        = 25000;
    private static final int FAST_FLAG              = 2 | 16 | 64;
    private static final int TEMPLATE_Y_OFFSET       = -22;
    private static final long BUILD_DELAY_TICKS     = 400;
    private static final long BUILD_START_DELAY_TICKS = 1200;
    private static final int BUTTERFLY_DELAY_TICKS  = 600;
    private static final int BUTTERFLY_INTERVAL     = 40;
    private static final int BUTTERFLY_MIN          = 150;
    private static final int BUTTERFLY_MAX          = 400;
    private static final int INITIAL_BUTTERFLIES    = 20;
    private static final int INITIAL_BFLY_SPACING   = 60; // 1 papillon toutes les 60 ticks (3s) pendant les 60s

    @SuppressWarnings("removal")
    private static final ResourceLocation TEMPLATE_ID  = ResourceLocation.fromNamespaceAndPath("deep_lucky_block", "crimsonlake");

    private static final Set<Long> TRIGGERED = ConcurrentHashMap.newKeySet();
    private static final List<PendingBuild> PENDING = new ArrayList<>();
    private static final Map<Long, SpawnTask> ACTIVE = new ConcurrentHashMap<>();
    private static final Queue<PasteJob> PASTE_Q = new ArrayDeque<>();
    private static final Random RNG = new Random();

    private static volatile MinecraftServer theServer;
    private static volatile long loginTick = Long.MIN_VALUE;
    private static int tickCounter = 0;

    private static boolean buildAllowed() {
        if (theServer == null || loginTick == Long.MIN_VALUE) return false;
        return theServer.getTickCount() - loginTick >= BUILD_DELAY_TICKS;
    }

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(
                Commands.literal("crimsonlake")
                        .executes(ctx -> { handleCommand(ctx.getSource().getPlayerOrException()); return 1; })
                        .then(Commands.literal("reset")
                                .executes(ctx -> { handleReset(ctx.getSource().getPlayerOrException()); return 1; }))
        );
    }

    private static void handleCommand(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        triggerAt(level, player, positionInFront(level, player), "commande /crimsonlake");
    }

    private static void handleReset(ServerPlayer player) {
        ServerLevel overworld = player.getServer().overworld();
        try {
            stateOf(overworld).clear();
            TRIGGERED.clear();
            PENDING.clear();
            player.sendSystemMessage(Component.literal("Crimson Lake state reset -> can trigger again (testing).")
                    .withStyle(ChatFormatting.YELLOW));
        } catch (Exception e) {
            player.sendSystemMessage(Component.literal("Reset failed: " + e.getMessage()).withStyle(ChatFormatting.RED));
        }
    }

    private static BlockPos positionInFront(ServerLevel level, ServerPlayer player) {
        double px = player.getX(), py = player.getY(), pz = player.getZ();
        double yaw = Math.toRadians(player.getYRot());
        double fdx = -Math.sin(yaw), fdz = Math.cos(yaw);
        int sx = 243, sz = 292;
        // FIX (freeze serveur au chargement à froid d'un gros NBT) : cache
        // mod-wide partagé (StructureTemplateCache) au lieu d'un appel direct
        // au StructureTemplateManager.
        var tmpl = deepluckyblock.util.StructureTemplateCache.get(level, "crimsonlake");
        if (tmpl != null) { sx = tmpl.getSize().getX(); sz = tmpl.getSize().getZ(); }
        double halfDepth = Math.abs(fdx) * (sx / 2.0) + Math.abs(fdz) * (sz / 2.0);
        int ox = (int) Math.round(px + fdx * halfDepth);
        int oz = (int) Math.round(pz + fdz * halfDepth);
        return new BlockPos(ox, (int) py, oz);
    }

    private static void triggerAt(ServerLevel level, ServerPlayer player, BlockPos pos, String source) {
        ServerLevel overworld = level.getServer().overworld();
        if (isWorldTriggered(overworld)) return;
        long key = pos.asLong();
        if (!TRIGGERED.add(key)) return;
        markWorldTriggered(overworld);
        if (DEBUG_LOGS) System.out.println("[SLB-DEBUG] CrimsonLake TRIGGER from " + source);

        // 🏆 Achievement : le Crimson Lake (événement ultra rare) a été trouvé.
        if (player != null) {
            DeepLuckyBlockAdvancements.grantCrimsonLake(player);
        }

        // Papillons initiaux : spawns progressifs (1 toutes les 3s) pendant les 60s d'attente.
        BlockPos center = player.blockPosition();
        int serverTick = level.getServer().getTickCount();
        for (int b = 0; b < INITIAL_BUTTERFLIES; b++) {
            final int tickOffset = b * INITIAL_BFLY_SPACING;
            TestProcedure.schedule(level, serverTick + tickOffset, () -> {
                spawnInitialButterflies(level, center, 1);
            });
        }

        long startTick = level.getServer().getTickCount() + BUILD_START_DELAY_TICKS;
        PENDING.add(new PendingBuild(level, pos.getX(), pos.getY(), pos.getZ(), startTick));

        Component msg = Component.literal(
                "Congratulations! You found the secret event: Crimson Lake. Please step back! (building starts in 60s)")
                .withStyle(ChatFormatting.GOLD);
        for (var p : level.players()) p.sendSystemMessage(msg);
    }

    private static int diceTick;
    private static final int DICE_SIDES = 500;
    private static final int DICE_HIT = 99;

    private static void rollDice() {
        if (theServer == null) return;
        if (isWorldTriggered(theServer.overworld())) return;
        int roll = RNG.nextInt(DICE_SIDES);
        if (roll != DICE_HIT) return;
        for (ServerLevel sl : theServer.getAllLevels()) {
            for (ServerPlayer p : sl.players()) {
                triggerAt(sl, p, positionInFront(sl, p), "dice " + DICE_HIT + "/" + DICE_SIDES);
                return;
            }
        }
    }

    @SubscribeEvent
    public static void onPlayerLogin(PlayerEvent.PlayerLoggedInEvent event) {
        theServer = event.getEntity().getServer();
        loginTick = theServer != null ? theServer.getTickCount() : Long.MIN_VALUE;
    }

    @SubscribeEvent
    public static void onPlayerLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        loginTick = Long.MIN_VALUE;
    }

    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post event) {
        if (!buildAllowed()) return;

        if (diceTick++ % 1200 == 0 && PASTE_Q.isEmpty() && PENDING.isEmpty()) {
            rollDice();
        }

        if (PASTE_Q.isEmpty() && PENDING.isEmpty() && ACTIVE.isEmpty()) return;

        tickCounter++;
        if (DEBUG_LOGS && (tickCounter % 200 == 0 || !PASTE_Q.isEmpty()))
            System.out.println("[SLB-DEBUG] CrimsonLake TICK: PASTE=" + PASTE_Q.size() + " PENDING=" + PENDING.size() + " ACTIVE=" + ACTIVE.size());

        long now = theServer.getTickCount();

        if (!PENDING.isEmpty()) {
            Iterator<PendingBuild> it = PENDING.iterator();
            while (it.hasNext()) {
                PendingBuild pb = it.next();
                if (now >= pb.startTick) {
                    queueBuild(pb.level, pb.px, pb.py, pb.pz);
                    it.remove();
                }
            }
        }

        if (!PASTE_Q.isEmpty()) {
            PasteJob j = PASTE_Q.peek();
            int end = Math.min(j.idx + BLOCKS_PER_TICK, j.blocks.size());
            StructurePlaceSettings rs = new StructurePlaceSettings();
            BlockPos.MutableBlockPos bp = new BlockPos.MutableBlockPos();
            for (int i = j.idx; i < end; i++) {
                var info = j.blocks.get(i);
                BlockState ts = info.state();
                BlockPos rel = StructureTemplate.calculateRelativePosition(rs, info.pos());
                bp.set(j.origin.getX() + rel.getX(), j.origin.getY() + rel.getY(), j.origin.getZ() + rel.getZ());
                j.level.getChunkSource().getChunk(bp.getX() >> 4, bp.getZ() >> 4, true);
                j.level.setBlock(bp, ts, FAST_FLAG);
                if (info.nbt() != null) {
                    var be = j.level.getBlockEntity(bp);
                    if (be != null) {
                        CompoundTag tag = info.nbt().copy();
                        tag.putInt("x", bp.getX()); tag.putInt("y", bp.getY()); tag.putInt("z", bp.getZ());
                        be.loadWithComponents(tag, j.level.registryAccess());
                    }
                }
            }
            j.idx = end;
            if (j.idx >= j.blocks.size()) {
                PASTE_Q.poll();
                if (DEBUG_LOGS) System.out.println("[SLB-DEBUG] CrimsonLake PASTE COMPLETE");
                int cap = BUTTERFLY_MIN + RNG.nextInt(BUTTERFLY_MAX - BUTTERFLY_MIN + 1);
                long bflyStart = j.level.getServer().getTickCount() + BUTTERFLY_DELAY_TICKS;
                ACTIVE.put(System.nanoTime(), new SpawnTask(j.level, j.bfly, bflyStart, cap, j.sx, j.sz));
            }
        }

        if (!ACTIVE.isEmpty()) {
            Iterator<Map.Entry<Long, SpawnTask>> it = ACTIVE.entrySet().iterator();
            while (it.hasNext()) {
                SpawnTask task = it.next().getValue();
                long t = task.level.getServer().getTickCount();
                if (t < task.nextTick) continue;
                if (task.spawned >= task.cap) { it.remove(); continue; }
                spawnPack(task);
                task.nextTick = t + BUTTERFLY_INTERVAL;
                if (task.spawned >= task.cap) it.remove();
            }
        }
    }

    private static void spawnInitialButterflies(ServerLevel level, BlockPos center, int count) {
        for (int i = 0; i < count; i++) {
            double angle = RNG.nextDouble() * Math.PI * 2.0;
            double dist = 4.0 + RNG.nextDouble() * 16.0;
            int x = center.getX() + (int) Math.round(Math.cos(angle) * dist);
            int z = center.getZ() + (int) Math.round(Math.sin(angle) * dist);
            // FIX papillons invisibles (rapport en jeu) : chercher un sol PRES
            // du point de déclenchement (center.getY()), pas la surface absolue
            // du monde. Si le joueur trouve l'event en sous-sol/grotte (ex.
            // y=-60), l'ancien findSurfaceY(level,x,z) scannait depuis le
            // TOIT du monde et renvoyait la vraie surface extérieure (souvent
            // y=70-100+), à 100+ blocs au-dessus/à l'écart du joueur : les
            // papillons apparaissaient bien, mais totalement hors de vue.
            int sy = findSurfaceYNear(level, x, z, center.getY());
            if (sy < 0) sy = center.getY();
            CrimsonButterflyEntity b = new CrimsonButterflyEntity(DeepLuckyBlockModEntities.CRIMSON_BUTTERFLY.get(), level);
            b.moveTo(x + 0.5, sy + 10.0, z + 0.5, RNG.nextFloat() * 360F, 0F);
            level.addFreshEntity(b);
        }
    }

    private static void spawnPack(SpawnTask task) {
        ServerLevel level = task.level;
        int cx = task.center.getX(), cz = task.center.getZ();
        int halfX = task.sx / 2 + 50;
        int halfZ = task.sz / 2 + 50;
        int pack = Math.min(3 + RNG.nextInt(4), task.cap - task.spawned);
        for (int i = 0; i < pack; i++) {
            double ux = RNG.nextDouble() * 2 - 1;
            double bx = Math.signum(ux) * ux * ux;
            double uz = RNG.nextDouble() * 2 - 1;
            double bz = Math.signum(uz) * uz * uz;
            int x = cx + (int) Math.round(bx * halfX);
            int z = cz + (int) Math.round(bz * halfZ);
            // FIX papillons invisibles : idem spawnInitialButterflies, on
            // cherche un sol proche de l'altitude du déclenchement, pas la
            // surface absolue du monde.
            int sy = findSurfaceYNear(level, x, z, task.center.getY());
            if (sy < 0) sy = task.center.getY();
            CrimsonButterflyEntity b = new CrimsonButterflyEntity(DeepLuckyBlockModEntities.CRIMSON_BUTTERFLY.get(), level);
            b.moveTo(x + 0.5, sy + 10.0, z + 0.5, RNG.nextFloat() * 360F, 0F);
            level.addFreshEntity(b);
        }
        task.spawned += pack;
    }

    /**
     * FIX papillons invisibles : cherche le sol le plus proche de refY (position
     * du joueur au moment du déclenchement de l'event), en scannant d'abord
     * VERS LE HAUT puis VERS LE BAS depuis refY, au lieu de toujours partir du
     * plafond du monde (qui renvoie la surface extérieure même si l'event a
     * été déclenché en sous-sol/grotte/mine, faisant apparaître les papillons
     * à 100+ blocs du joueur, donc invisibles).
     */
    private static int findSurfaceYNear(ServerLevel level, int x, int z, int refY) {
        int minY = level.getMinBuildHeight();
        int maxY = level.getMaxBuildHeight() - 1;
        int range = 40; // suffisant pour sortir d'une grotte/mine sans remonter jusqu'à la surface
        for (int dy = 0; dy <= range; dy++) {
            int yUp = refY + dy;
            if (yUp <= maxY && yUp > minY) {
                BlockState above = level.getBlockState(new BlockPos(x, yUp, z));
                BlockState below = level.getBlockState(new BlockPos(x, yUp - 1, z));
                if (above.isAir() && above.getFluidState().isEmpty()
                        && !below.isAir() && below.getFluidState().isEmpty()) return yUp;
            }
            if (dy == 0) continue;
            int yDown = refY - dy;
            if (yDown <= maxY && yDown > minY) {
                BlockState above = level.getBlockState(new BlockPos(x, yDown, z));
                BlockState below = level.getBlockState(new BlockPos(x, yDown - 1, z));
                if (above.isAir() && above.getFluidState().isEmpty()
                        && !below.isAir() && below.getFluidState().isEmpty()) return yDown;
            }
        }
        // Repli : ancien comportement (surface absolue du monde) si rien de
        // praticable n'a été trouvé près du joueur.
        return findSurfaceY(level, x, z);
    }

    private static int findSurfaceY(ServerLevel level, int x, int z) {
        for (int y = level.getMaxBuildHeight() - 1; y > level.getMinBuildHeight(); y--) {
            BlockState s = level.getBlockState(new BlockPos(x, y, z));
            if (!s.isAir() && s.getFluidState().isEmpty()) return y + 1;
        }
        return -1;
    }

    private static void queueBuild(ServerLevel level, int px, int py, int pz) {
        if (DEBUG_LOGS) System.out.println("[SLB-DEBUG] CrimsonLake QUEUE BUILD at " + px + "," + py + "," + pz);
        // FIX (freeze serveur au chargement à froid d'un gros NBT) : cache
        // mod-wide partagé (StructureTemplateCache) au lieu d'un appel direct
        // au StructureTemplateManager.
        StructureTemplate tmpl = deepluckyblock.util.StructureTemplateCache.get(level, "crimsonlake");
        if (tmpl == null) return;
        List<StructureTemplate.StructureBlockInfo> raw = exBlocks(tmpl);
        if (raw.isEmpty()) return;

        int sx = tmpl.getSize().getX();
        int sy = tmpl.getSize().getY();
        int sz = tmpl.getSize().getZ();

        BlockPos origin = new BlockPos(px - sx / 2, py + TEMPLATE_Y_OFFSET, pz - sz / 2);
        BlockPos bfly = new BlockPos(px, py + 10, pz);

        List<StructureTemplate.StructureBlockInfo> filt = new ArrayList<>(raw.size());
        for (var info : raw) if (!isLaggy(info.state())) filt.add(info);
        filt = orderByY(filt);

        Component msg2 = Component.literal(
                "Crimson Lake: loading surrounding chunks and building layer by layer...")
                .withStyle(ChatFormatting.AQUA);
        for (var pl : level.players()) pl.sendSystemMessage(msg2);

        PASTE_Q.offer(new PasteJob(level, filt, origin, bfly, System.currentTimeMillis(), sx, sz));
    }

    private static List<StructureTemplate.StructureBlockInfo> orderByY(List<StructureTemplate.StructureBlockInfo> blocks) {
        List<StructureTemplate.StructureBlockInfo> sorted = new ArrayList<>(blocks);
        sorted.sort((a, b) -> {
            int ya = a.pos().getY(), yb = b.pos().getY();
            if (ya != yb) return Integer.compare(ya, yb);
            int xa = a.pos().getX(), xb = b.pos().getX();
            if (xa != xb) return Integer.compare(xa, xb);
            return Integer.compare(a.pos().getZ(), b.pos().getZ());
        });
        return sorted;
    }

    @SuppressWarnings("unchecked")
    private static List<StructureTemplate.StructureBlockInfo> exBlocks(StructureTemplate t) {
        try {
            for (Field f : StructureTemplate.class.getDeclaredFields()) {
                f.setAccessible(true);
                Object val = f.get(t);
                if (val instanceof List<?> list && !list.isEmpty() && list.get(0) instanceof StructureTemplate.Palette) {
                    return ((StructureTemplate.Palette) list.get(0)).blocks();
                }
            }
        } catch (Exception ignored) {}
        return Collections.emptyList();
    }

    private static boolean isLaggy(BlockState s) {
        return s.is(Blocks.TRIPWIRE)
            || s.is(Blocks.MOSS_CARPET) || s.is(Blocks.WHITE_CARPET) || s.is(Blocks.ORANGE_CARPET)
            || s.is(Blocks.MAGENTA_CARPET) || s.is(Blocks.LIGHT_BLUE_CARPET) || s.is(Blocks.YELLOW_CARPET)
            || s.is(Blocks.LIME_CARPET) || s.is(Blocks.PINK_CARPET) || s.is(Blocks.GRAY_CARPET)
            || s.is(Blocks.LIGHT_GRAY_CARPET) || s.is(Blocks.CYAN_CARPET) || s.is(Blocks.PURPLE_CARPET)
            || s.is(Blocks.BLUE_CARPET) || s.is(Blocks.BROWN_CARPET) || s.is(Blocks.GREEN_CARPET)
            || s.is(Blocks.RED_CARPET) || s.is(Blocks.BLACK_CARPET);
    }

    private static boolean isWorldTriggered(ServerLevel overworld) {
        try {
            return stateOf(overworld).triggered;
        } catch (Exception e) { return false; }
    }

    private static void markWorldTriggered(ServerLevel overworld) {
        try { stateOf(overworld).mark(); } catch (Exception ignored) {}
    }

    private static CrimsonLakeState stateOf(ServerLevel overworld) {
        return overworld.getDataStorage().computeIfAbsent(new SavedData.Factory<>(CrimsonLakeState::new, CrimsonLakeState::load), "crimson_lake_state");
    }

    public static class CrimsonLakeState extends SavedData {
        public boolean triggered = false;
        public void mark() { triggered = true; setDirty(); }
        public void clear() { triggered = false; setDirty(); }
        public static CrimsonLakeState load(CompoundTag tag, HolderLookup.Provider registries) {
            CrimsonLakeState s = new CrimsonLakeState();
            s.triggered = tag.getBoolean("triggered");
            return s;
        }
        @Override
        public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
            tag.putBoolean("triggered", triggered);
            return tag;
        }
    }

    private static final class PendingBuild {
        final ServerLevel level;
        final int px, py, pz;
        final long startTick;
        PendingBuild(ServerLevel l, int x, int y, int z, long t) { level = l; px = x; py = y; pz = z; startTick = t; }
    }

    private static final class PasteJob {
        final ServerLevel level;
        final List<StructureTemplate.StructureBlockInfo> blocks;
        final BlockPos origin;
        final BlockPos bfly;
        final long t0;
        final int total;
        final int sx, sz;
        int idx;
        PasteJob(ServerLevel l, List<StructureTemplate.StructureBlockInfo> b, BlockPos o, BlockPos bf, long t, int sx, int sz) {
            level = l; blocks = b; origin = o; bfly = bf; t0 = t; total = b.size(); this.sx = sx; this.sz = sz; idx = 0;
        }
    }

    private static final class SpawnTask {
        final ServerLevel level;
        final BlockPos center;
        final int sx, sz;
        long nextTick;
        int spawned;
        final int cap;
        SpawnTask(ServerLevel l, BlockPos c, long firstTick, int cap, int sx, int sz) {
            level = l; center = c; nextTick = firstTick; spawned = 0; this.cap = cap; this.sx = sx; this.sz = sz;
        }
    }
}
